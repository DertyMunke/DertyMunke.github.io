﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;
using System.Collections.Generic;
using System;
using System.Net;
using System.Net.Mail;
using System.Net.Security;
using System.Security.Cryptography.X509Certificates;
using ImageVideoContactPicker;

public class OutputManager : MonoBehaviour 
{
    #region Public Variables
    public static OutputManager manager;
    public GameObject[] leftBtns;
    public GameObject[] rightBtnsTop;
    public GameObject[] profiles;
    public GameObject[] popupPnl;  // Popup panel and output popup panel
    public GameObject[] confirmPnls;
    public GameObject[] confirmIms;
    public GameObject selectContact;
    public GameObject saveWarning;
    public GameObject saveCorrectDay;
    public GameObject overridePnl;
    public GameObject inputPnl;
    public GameObject ytdPnl;
    public Button[] rightBtns;
    public Button sendConfirmation;
    public Dropdown contactInfo;
    public Toggle[] days;
    public Image month;
    public Image year;
    public Sprite[] months;
    public Sprite[] years;  //2013 - 2020
    public Sprite[] confirmSpts;
    public Text contactCurrent;
	public Text barTips;
	public Text runTips;
	public Text	assistTips;
	public Text otherTips;
	public Text sales;
    public Text tips;
	public Text expenses;
	public Text dayAndShift;
    public Text dayAndShiftPopup;
    public Text dayAndShiftOverride;
    #endregion

    #region Private Variables
    private Day myDay;
    DateTime dateTime = DateTime.Now;
    private List<string> barSentNames;
    private List<string> runSentNames;
    private List<string> assSentNames;
    private List<string> othSentNames;
    private string clickedBtn;
	private string contactName;
    private float contactTips = 0;
    private int thisConfirmation = 0;
    #endregion

    #region Properties
    public int SetPrevDays {
        set
        {
            dateTime = DateTime.Now;
            dateTime = dateTime.AddDays(value);
        }
    }
    #endregion

    #region Unity Methods
    private void Awake()
    {
        manager = this;
    }
    #endregion

    #region Public Methods
    /// <summary>
    /// Handles the back button pressed
    /// </summary>
    public void BackBtn()
    {
        StopAllCoroutines();
        inputPnl.SetActive(true);
        InputManager.manager.InputActive();
        gameObject.SetActive(false);
    }

    /// <summary>
    /// Handles routines that need to start each time we visit output panel. 
    /// The parameter "changed" is true if changes in output panel will effect tipout confirmations
    /// </summary>
    public void OutputActive(bool changed)
    {
        GameManager.manager.myDay.SetOutput();
        myDay = GameManager.manager.myDay;

        SetCalendar(dateTime);
        dayAndShiftPopup.text = myDay.dateTime;
        dayAndShiftOverride.text = myDay.dateTime;
        dayAndShift.text = myDay.dateTime;
        sales.text = string.Format("{0:F2}", myDay.grossSales);
        tips.text = string.Format("{0:F2}", myDay.netTips);
        expenses.text = string.Format("{0:F2}", myDay.expenses);

        if(changed)
        {
            barSentNames = new List<string>();
            runSentNames = new List<string>();
            assSentNames = new List<string>();
            othSentNames = new List<string>();

            // Bar tipouts setup
            if (myDay.GrpsActive[0] == true && myDay.barPercent > 0 && myDay.barNum > 0)
            {
                barTips.text = string.Format("{0:F2} per", myDay.barTotal / myDay.barNum);
                confirmIms[0].SetActive(true);
                confirmIms[0].GetComponent<Image>().sprite = confirmSpts[1];
                rightBtns[0].interactable = true;
            }
            else
            {
                rightBtnsTop[0].SetActive(false);
                rightBtns[0].interactable = false;
            }

            // Runner tipouts setup
            if (myDay.GrpsActive[1] == true && myDay.runPercent > 0 && myDay.runNum > 0)
            {
                runTips.text = string.Format("{0:F2} per", myDay.runTotal / myDay.runNum);
                confirmIms[1].SetActive(true);
                confirmIms[1].GetComponent<Image>().sprite = confirmSpts[1];
                rightBtns[1].interactable = true;
            }
            else
            {
                rightBtnsTop[1].SetActive(false);
                rightBtns[1].interactable = false;
            }

            // Assistant tipouts setup
            if (myDay.GrpsActive[2] == true && myDay.assistPercent > 0 && myDay.assistNum > 0)
            {
                assistTips.text = string.Format("{0:F2} per", myDay.assistTotal / myDay.assistNum);
                confirmIms[2].SetActive(true);
                confirmIms[2].GetComponent<Image>().sprite = confirmSpts[1];
                rightBtns[2].interactable = true;
            }
            else
            {
                rightBtnsTop[2].SetActive(false);
                rightBtns[2].interactable = false;
            }

            // Other tipouts setup
            if (myDay.GrpsActive[3] == true && myDay.otherPercent > 0 && myDay.somNum > 0)
            {
                otherTips.text = string.Format("{0:F2} per", myDay.otherTotal / myDay.somNum);
                confirmIms[3].SetActive(true);
                confirmIms[3].GetComponent<Image>().sprite = confirmSpts[1];
                rightBtns[3].interactable = true;
            }
            else
            {
                rightBtnsTop[3].SetActive(false);
                rightBtns[3].interactable = false;
            }               
        }       

        StartCoroutine(BtnBlink());
    }

    /// <summary>
    /// Sets all of the date time strings in the output scene
    /// </summary>
    public void SetDateTimeStrings()
    {
        if (myDay.GetPM)
        {
            dayAndShiftPopup.text = dateTime.ToString("MM/dd/yyyy") + " PM";
            dayAndShiftOverride.text = dateTime.ToString("MM/dd/yyyy") + " PM";
        }
        else
        {
            dayAndShiftPopup.text = dateTime.ToString("MM/dd/yyyy") + " AM";
            dayAndShiftOverride.text = dateTime.ToString("MM/dd/yyyy") + " AM";
        }
    }

    /// <summary>
    /// Changes the save date to the previous day
    /// </summary>
    public void PreviousDay()
    {
        if ((dateTime.Year > 2013 || !(dateTime.Year == 2013 && dateTime.Month == 1 && dateTime.Day == 1)))
        {
            dateTime = dateTime.AddDays(-1);
            SetDateTimeStrings();
        }
    }

    /// <summary>
    /// Sets the day from the calendar buttons
    /// </summary>
    public void SetDay(int dayNum)
    {
        if(dayNum <= DateTime.DaysInMonth(dateTime.Year, dateTime.Month))
            dateTime = new DateTime(dateTime.Year, dateTime.Month, dayNum);
    }

    /// <summary>
    /// Changes the month by + or - an integer
    /// </summary>
    public void MonthDelta(int delta)
    {
        DateTime min = new DateTime(2013, 01, 01);
        if (dateTime.AddMonths(delta).Date <= DateTime.Now.Date && dateTime.AddMonths(delta).Date >= min.Date)
        {
            dateTime = dateTime.AddMonths(delta);
            SetDateTimeStrings();
            SetCalendar(dateTime);
        }
    }

    /// <summary>
    /// Changes the year by + or - an integer
    /// </summary>
    public void YearDelta(int delta)
    {
        if ((dateTime.Year + delta) >= 2013 && (dateTime.Year + delta) <= DateTime.Now.Year)
        {
            dateTime = dateTime.AddYears(delta);
            SetDateTimeStrings();
            SetCalendar(dateTime);
        }
    }

    /// <summary>
    /// Set the date on the ouput panel calendar
    /// </summary>
    public void SetCalendar(DateTime newDate)
    {
        month.sprite = months[newDate.Month - 1];
        year.sprite = years[newDate.Year - 2013];
        days[newDate.Day - 1].isOn = true;

        int numDays = DateTime.DaysInMonth(newDate.Year, newDate.Month);
        for (int i = 0; i < days.Length; ++i)
        {
            if(i < numDays)
            {
                days[i].interactable = true;
            }
            else
            {
                days[i].interactable = false;
            }                
        }
    }

    /// <summary>
    /// Either exits the application or opens the year to date panel
    /// </summary>
    public void Exit()
	{
        if (clickedBtn == "Exit") 
            Application.Quit();
        else if(clickedBtn == "YTD")
        {
            ytdPnl.SetActive(true);
            Popups.popupsScript.ClosePopups();
            gameObject.SetActive(false);
        }
	}

    /// <summary>
    /// The user has chosen to save input to profile
    /// </summary>
	public void SaveToProfile()
	{
		string monthlyNotes = "";

        if (GameManager.manager.currProfileName != "")
		{
            GameManager.manager.myDay = myDay;

            if(dateTime.ToString("MM/dd/yyyy") != myDay.date)
            {
                myDay.SetDay = dateTime;
                Debug.Log("set dateTime");
            }

			if(GameManager.manager.monthlyNotes.ContainsKey(myDay.myYear))
			{
				if(!GameManager.manager.monthlyNotes[myDay.myYear].ContainsKey(myDay.myMonth))
				{
					GameManager.manager.monthlyNotes[myDay.myYear].Add(myDay.myMonth, monthlyNotes);
				}
			}
			else
			{
				Dictionary<int, string> month = new Dictionary<int, string>();
				month.Add(myDay.myMonth, monthlyNotes);
				GameManager.manager.monthlyNotes.Add(myDay.myYear, month);
			}

			if(!GameManager.manager.yearlyNotes.ContainsKey(myDay.myYear))
			{
				string yearlyNotes = "";
				GameManager.manager.yearlyNotes.Add(myDay.myYear, yearlyNotes);
			}

            // Save data if not overriding
			if(GameManager.manager.AddDayToDict(GameManager.manager.myDay))
            {
                GameManager.manager.Save(GameManager.manager.currProfileName);
                Exit();
            }
            // Open override confirmation
			else
            {
                overridePnl.SetActive(true);
            }          
        }
        else
        {
            Debug.Log("Error: No profile is selected.");
        }
	}

    /// <summary>
    /// Override the previously saved day with the new values
    /// </summary>
    public void OverrideData()
    {
        GameManager.manager.SetOveride = true;
        SaveToProfile();
    }

    /// <summary>
    /// Do not override and reset day to current day
    /// </summary>
    public void DontOverrideData()
    {
        myDay.SetDay = DateTime.Now;
        overridePnl.SetActive(false);
    }

    /// <summary>
    /// When they try to leave the page it prompts them to save the data
    /// </summary>
    public void CheckSave(Button clicked)
    {
        clickedBtn = clicked.name;
        popupPnl[0].SetActive(true);
        popupPnl[1].SetActive(true);

        if (GameManager.manager.currProfileName != "")
        {
            saveCorrectDay.SetActive(true);
        }
        else
        {           
            saveWarning.SetActive(true);
        }
    }

    /// <summary>
    /// Opens the profile options panel
    /// </summary>
    public void OpenProfileOptions()
    {
        //ProfileManager.manager.EnableAllProfileBtns();
        saveWarning.SetActive(false);
        profiles[0].SetActive(true);
        profiles[1].SetActive(true);
    }

    /// <summary>
    /// Sets the amount you will tipout in the confirmation text
    /// </summary>
    public void SetContactTips(int option)
    {
        thisConfirmation = option;
        contactInfo.ClearOptions();

        contactTips = option == 1 ? myDay.barTotal/myDay.barNum :   // Bar 
            option == 2 ? myDay.runTotal / myDay.runNum :           // Runner
            option == 3 ? myDay.assistTotal / myDay.assistNum :     // Assistant
            myDay.otherTotal / myDay.somNum;                        // Other

        for (int i = 0; i < confirmPnls.Length; ++i)
            confirmPnls[i].SetActive(true);
    }

    /// <summary>
    /// Opens the text in the phones text API
    /// </summary>
    public void SendConfirmation()
    {

		#if UNITY_ANDROID
        	string url = String.Format("sms:{0}?body=Tipout%20Confirmation%20%24{1:F2}", contactInfo.captionText.text, contactTips);
#elif UNITY_IPHONE
		    string url = String.Format("sms:{0}&body=Tipout%20Confirmation%20For%20{1}", contactCurrent.text, contactName);
#endif

        // Check if all of the required confirmations where sent for bartenders
        if (thisConfirmation == 1)
        {
            barSentNames.Add(contactName);
            if(!barSentNames.Contains(contactName))
            {
                barSentNames.Add(contactName);
                if (barSentNames.Count >= myDay.barNum)
                    confirmIms[0].GetComponent<Image>().sprite = confirmSpts[0];
            }

        }
        // Check if all of the required confirmations where sent for runners
        else if (thisConfirmation == 2)
        {
            runSentNames.Add(contactName);
            if (!runSentNames.Contains(contactName))
            {
                runSentNames.Add(contactName);
                if (runSentNames.Count >= myDay.runNum)
                    confirmIms[1].GetComponent<Image>().sprite = confirmSpts[0];
            }
        }
        // Check if all of the required confirmations where sent for assistants
        else if (thisConfirmation == 3)
        {
            assSentNames.Add(contactName);
            if (!assSentNames.Contains(contactName))
            {
                assSentNames.Add(contactName);
                if (assSentNames.Count >= myDay.assistNum)
                    confirmIms[2].GetComponent<Image>().sprite = confirmSpts[0];
            }
        }
        // Check if all of the required confirmations where sent for other
        else if (thisConfirmation == 4)
        {
            othSentNames.Add(contactName);
            if (!othSentNames.Contains(contactName))
            {
                othSentNames.Add(contactName);
                if (othSentNames.Count >= myDay.somNum)
                    confirmIms[3].GetComponent<Image>().sprite = confirmSpts[0];
            }
        }

        Application.OpenURL(url);
    }

    /// <summary>
    /// Allows you to browse the contacts in the phone.
    /// </summary>
    public void BrowseContacts()
    {
        PickerEventListener.onContactSelect += OnContactSelect;

        #if UNITY_ANDROID
            AndroidPicker.BrowseContact();
        #elif UNITY_IPHONE
			IOSPicker.BrowseContact();
        #endif
    }
    #endregion

    #region Private Methods
    /// <summary>
    /// Called when a contact is picked
    /// </summary>
    private void OnContactSelect(string name, List<string> numbers, List<string> emails)
    {
        PickerEventListener.onContactSelect -= OnContactSelect;

        contactInfo.ClearOptions();
        contactInfo.interactable = true;
        contactName = name;

        if (numbers.Count > 0)
        {
            contactCurrent.text = numbers[0];
            contactInfo.AddOptions(numbers);
            sendConfirmation.interactable = true;
        }
        else
        {
            contactCurrent.text = "No number found";
            sendConfirmation.interactable = false;
        }

    }

    /// <summary>
    /// Makes all of the input buttons blink with the input value and button title
    /// </summary>
    private IEnumerator BtnBlink()
    {
        bool onoff = false;
        bool blink = true;
        while (blink)
        {
            onoff = !onoff;

            // Make left side buttons blink
            for(int i = 0; i < leftBtns.Length; ++i)
                leftBtns[i].SetActive(onoff);

            // Make bar blink if used
            if (myDay != null && myDay.GrpsActive[0])
                rightBtnsTop[0].SetActive(onoff);

            // Make runner blink if used
            if (myDay != null && myDay.GrpsActive[1])
                rightBtnsTop[1].SetActive(onoff);

            // Make assistant blink if used
            if (myDay != null && myDay.GrpsActive[2])
                rightBtnsTop[2].SetActive(onoff);

            // Make other blink if used
            if (myDay != null && myDay.GrpsActive[3])
                rightBtnsTop[3].SetActive(onoff);

            //// Show selected contact number
            //if (contactCurrent.text != "")
            //    selectContact.SetActive(onoff);

            yield return new WaitForSeconds(1f);
        }

        yield return null;
    }
    #endregion
}
