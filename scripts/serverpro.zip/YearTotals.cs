﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class YearTotals 
{
    #region Public Variables
    public Dictionary<int, MonthTotals> monthDict = new Dictionary<int, MonthTotals> ();
	public float sales = 0;  
	public float wine = 0;
	public float expenses = 0;
	public float grossTips = 0;
	public float netTips = 0;
	public float grossPercent = 0;
	public float netPercent = 0;
	public float bar = 0;
	public float other = 0;
	public float runner = 0;
	public float assistant = 0;
	public float totalTipouts = 0;
    #endregion

    /// <summary>
    /// Creates a zeroed YearTotals
    /// </summary>
    public YearTotals(){}

    /// <summary>
    /// Initializes a new YearTotals with a dictionary of MonthTotals
    /// </summary>
	public YearTotals(Dictionary<int, MonthTotals> newMonth)
	{
		monthDict = newMonth;
		foreach(MonthTotals month in monthDict.Values)
		{
			sales = sales + month.sales;  
			wine = wine + month.wineSales;
			expenses = expenses + month.expenses;
			grossTips = grossTips + month.tipsGross;
			netTips = netTips + month.tipsNet;
			bar = bar + month.bar;
			other = other + month.other;
			runner = runner + month.runner;
			assistant = assistant + month.assistant;
			totalTipouts = totalTipouts + month.totalTipout; 

		}
		if(sales == 0)
		{
			grossPercent = 0;
			netPercent =  0;
		}
		else
		{
			grossPercent = grossTips / sales * 100;
			netPercent =  netTips / sales * 100;
		}
	}
}
