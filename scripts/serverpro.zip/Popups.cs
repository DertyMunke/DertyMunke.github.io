﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;

public class Popups : MonoBehaviour {

    public static Popups popupsScript;
    public GameObject inputPnl;
    public GameObject outputPnl;
    public GameObject[] bgs;
    public GameObject[] warnings;
    public GameObject[] profilePopups;
    public Button[] profiles;
    public Button sendConfirmBtn;
    public Dropdown contactInfo;

    private void Awake()
    {
        popupsScript = this;
    }

    /// <summary>
    /// Closes all of the popups
    /// </summary>
    public void ClosePopups()
    {
        if(inputPnl.activeInHierarchy)
        {
            inputPnl.GetComponent<InputManager>().ResetPopups();
        }

       if(outputPnl.activeInHierarchy)
        {
            OutputManager.manager.SetPrevDays = 0;
        }

        for (int i = 0; i < profiles.Length; ++i)
            profiles[i].interactable = false;

        for (int i = 0; i < profilePopups.Length; ++i)
            profilePopups[i].SetActive(false);

        for (int i = 0; i < warnings.Length; ++i)
            warnings[i].SetActive(false);

        for (int i = 0; i < bgs.Length; ++i)
            bgs[i].SetActive(false);

        sendConfirmBtn.interactable = false;
        contactInfo.interactable = false;
    }

}
