﻿using UnityEngine;
using System.Collections;

public class DayTotals
{
	public float sales = 0;  //Start Day Quick View
	public float tipsNet = 0;
	public float tipPercent = 0;
	public float expenses = 0;   //End Day Quick View
    public float wineSales = 0;
    public float grossTips = 0;
    public float bar = 0;
    public float other = 0;
    public float runner = 0;
    public float assistant = 0;
    public float totalTipout = 0;  //End Detailed Day View
    public int myDay = 0;
    public int myMonth = 0;
    public int myYear = 0;

    /// <summary>
    /// Creates a zeroed DayTotals 
    /// </summary>
	public DayTotals(){}

    /// <summary>
    /// Takes am and pm for each day and initializes the day totals 
    /// </summary>
	public DayTotals(Day[] day)
	{
        // AM + PM totals
        if (day[0] != null && day[1] != null)
        {
            myDay = day[0].myDay;
            myMonth = day[0].myMonth;
            myYear = day[0].myYear;

            sales = day[1].grossSales + day[0].grossSales;
            tipsNet = day[1].netTips + day[0].netTips;
            expenses = day[1].expenses + day[0].expenses;
            wineSales = day[1].wineSales + day[0].wineSales;
            grossTips = day[1].grossTips + day[0].grossTips;
            bar = day[1].barSales + day[0].barSales;
            other = day[1].wineSales + day[0].wineSales;
            runner = day[1].foodSales + day[0].foodSales;
            assistant = day[1].assistTotal + day[0].assistTotal;
            totalTipout = day[1].totalTipout + day[0].totalTipout;
            if (day[0].grossSales + day[1].grossSales == 0)
            {
                tipPercent = 0;
            }
            else
            {
                tipPercent = (day[0].netTips + day[1].netTips) / (day[0].grossSales + day[1].grossSales) * 100;
            }
        }
        // AM shift totals
        else if (day[0] != null)
		{
			myDay = day[0].myDay;
			myMonth = day[0].myMonth;
			myYear = day[0].myYear;

			sales = day[0].grossSales;
			tipsNet = day[0].netTips;
			expenses = day[0].expenses; 
			wineSales = day[0].wineSales;
			grossTips = day[0].grossTips;
			bar = day[0].barSales;
			other = day[0].wineSales;
			runner = day[0].foodSales;
			assistant = day[0].assistTotal;
			totalTipout = day[0].totalTipout;  

			tipPercent = day[0].netPercent;
		}
        // PM shift totals
		else if(day[1] != null)
		{
			myDay = day[1].myDay;
			myMonth = day[1].myMonth;
			myYear = day[1].myYear;

			sales = day[1].grossSales;
			tipsNet = day[1].netTips;
			expenses = day[1].expenses; 
			wineSales = day[1].wineSales;
			grossTips = day[1].grossTips;
			bar = day[1].barSales;
			other = day[1].wineSales;
			runner = day[1].foodSales;
			assistant = day[1].assistTotal;
			totalTipout = day[1].totalTipout;  

			tipPercent = day[1].netPercent;
		} 
	}
}
