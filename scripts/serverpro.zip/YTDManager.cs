﻿using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using System.Collections;
using System.Collections.Generic;
using System;

public class YTDManager : MonoBehaviour 
{
    #region Public Variables
    public static YTDManager manager;
    public GameObject[] offPanels; // tipout, months, days, scroll month, scroll l. year, scroll r. year
    public Image yearLeft;
    public Image yearRight;
    public Image month;
    public Sprite[] years;
    public Sprite[] months;
    public Toggle[] days;
    public Toggle[] monthBtns;
    public Toggle[] tabs;
    public Text[] details;      // Sales, tips, tip %, expenses
    public Text[] tipouts;      // Bar, runner, assistant, other, total
    public bool[] panelState;   // Saves the panel state so it can be put back
    #endregion

    #region Private Variables
    private Day myday;
    private Dictionary<int, YearTotals> yearDict = new Dictionary<int, YearTotals>(); //Keeps track of the day, month and year totals
    private DateTime dateTime;
    #endregion

    #region Unity Methods
    private void Awake()
    {
        // Initialize the YTDManager script access point
        manager = this;
    }

	private void Start()
	{
		//GameManager.manager.TestSave (); //Testing

		InitYTDManager ();
	}
    #endregion

    #region public Methods
    /// <summary>
    /// Handles the tipouts button panels
    /// </summary>
    public void TipoutsBtn()
    {
        offPanels[0].SetActive(!offPanels[0].activeInHierarchy); // Tipout panel

        if(offPanels[0].activeInHierarchy)
        {
            offPanels[1].SetActive(false); // Months panel
            offPanels[2].SetActive(false); // Days panel
            offPanels[5].SetActive(false); // Right year scroll
        }
        else if(tabs[1].isOn) // Monthly tab enabled
        {
            offPanels[1].SetActive(true); // Months panel
            offPanels[5].SetActive(true); // Right year scroll
        }
        else if (tabs[2].isOn) // Daily tab enable
        {
            offPanels[2].SetActive(true); // Days panel
            offPanels[5].SetActive(true); // Right year scroll
        }
    }

    /// <summary>
    /// Set the date on the YTD panel calendar
    /// </summary>
    public void SetCalendar(DateTime newDate)
    {
        month.sprite = months[newDate.Month - 1];
        yearLeft.sprite = years[newDate.Year - 2013];
        yearRight.sprite = years[newDate.Year - 2013];
        days[newDate.Day - 1].isOn = true;

        int numDays = DateTime.DaysInMonth(newDate.Year, newDate.Month);
        for (int i = 0; i < days.Length; ++i)
        {
            if (i < numDays)
            {
                days[i].interactable = true;
            }
            else
            {
                days[i].interactable = false;
            }
        }
    }

    /// <summary>
    /// Turns off all of the panels on tab press
    /// </summary>
    public void ResetPanels()
    {
        for (int i = 0; i < offPanels.Length; ++i)
            offPanels[i].SetActive(false);
    }

    /// <summary>
    /// Initializes the current year in the dictionary  
    /// </summary>
    private void SetYear()
	{
		if(!yearDict.ContainsKey(dateTime.Year))
		{
			if(GameManager.manager.savedDays.ContainsKey(dateTime.Year))
			{
				Dictionary<int, MonthTotals> monthDict = new Dictionary<int, MonthTotals> ();
				foreach(Dictionary<int, Day[]> month in GameManager.manager.savedDays[dateTime.Year].Values)
				{
					int thisMonth = 0;
					Dictionary<int, DayTotals> daysDict = new Dictionary<int, DayTotals> (); 
					foreach(Day[] day in month.Values)
					{
						DayTotals dayTotals = new DayTotals(day);
						daysDict.Add (dayTotals.myDay, dayTotals);
						thisMonth = dayTotals.myMonth;
					}
					MonthTotals monthTotals = new MonthTotals(daysDict);
					monthDict.Add(thisMonth, monthTotals);
				}
				YearTotals yearTotals = new YearTotals(monthDict);
				yearDict.Add(dateTime.Year, yearTotals);
			}
			else
			{
				//The following makes a dummy year to calculate figures
				Day[] day = new Day[2];
				Day newDay = new Day();
				day[0] = newDay;
				DayTotals dayTotals = new DayTotals(day);
				Dictionary<int, DayTotals> daysDict = new Dictionary<int, DayTotals> (); 
				daysDict.Add(dayTotals.myDay, dayTotals);
				
				Dictionary<int, MonthTotals> monthDict = new Dictionary<int, MonthTotals> ();
				MonthTotals monthTotals = new MonthTotals(daysDict);
				monthDict.Add(newDay.myMonth, monthTotals);
				
				YearTotals yearTotals = new YearTotals(monthDict);
				yearDict.Add(dateTime.Year, yearTotals);
			}
		}

        if (tabs[0].isOn)
            SetYearVals();
        else if (tabs[1].isOn)
            SetMonthVals();
        else
            SetDayVals();

        ActiveBtns();
	}
	
    /// <summary>
    /// Sets the day buttons active that have saved data
    /// </summary>
	private void ActiveBtns()
	{
		foreach(Toggle day in days)
		{
			day.interactable = false;
		}
		foreach(Toggle month in monthBtns)
		{
			month.interactable = false;
		}

		if(GameManager.manager.savedDays.ContainsKey(dateTime.Year))
		{
			foreach(int month in GameManager.manager.savedDays[dateTime.Year].Keys)
			{
				monthBtns[month - 1].interactable = true;
			}

			if(GameManager.manager.savedDays[dateTime.Year].ContainsKey(dateTime.Month))
			{
				foreach(Day[] day in GameManager.manager.savedDays[dateTime.Year][dateTime.Month].Values)
				{
					if(day[0] != null)
					{
						days[day[0].myDay -1].interactable = true;
					} 
					
					if(day[1] != null)
					{
						days[day[1].myDay -1].interactable = true;
					}
				}
			}
		}
	}

    /// <summary>
    /// Set the values for the current daily totals
    /// </summary>
    public void SetDayVals()
	{
		DayTotals dayTotals = new DayTotals();
		if(GameManager.manager.savedDays.ContainsKey(dateTime.Year) && GameManager.manager.savedDays[dateTime.Year].ContainsKey(dateTime.Month) &&
			GameManager.manager.savedDays[dateTime.Year][dateTime.Month].ContainsKey(dateTime.Day))
		{
			dayTotals = yearDict[dateTime.Year].monthDict[dateTime.Month].daysDict[dateTime.Day];
		}

        details[0].text = string.Format("${0:F2}", dayTotals.sales);        // Sales
        details[1].text = string.Format("${0:F2}", dayTotals.tipsNet);      // Tips
        details[2].text = string.Format("{0:F1}%", dayTotals.tipPercent);   // Tip %
        details[3].text = string.Format("${0:F2}", dayTotals.expenses);     // Expenses

        tipouts[0].text = string.Format("${0:F2}", dayTotals.bar);          // Bar
        tipouts[1].text = string.Format("${0:F2}", dayTotals.runner);       // Runner
        tipouts[2].text = string.Format("${0:F2}", dayTotals.assistant);    // Assistant
        tipouts[3].text = string.Format("${0:F2}", dayTotals.other);        // Other
        tipouts[4].text = string.Format("${0:F2}", dayTotals.totalTipout);
    }

    /// <summary>
    /// Set the values for the current monthly totals
    /// </summary>
	public void SetMonthVals()
	{
		MonthTotals monthTotals = new MonthTotals();
		if(GameManager.manager.savedDays.ContainsKey(dateTime.Year) && GameManager.manager.savedDays[dateTime.Year].ContainsKey(dateTime.Month))
		{
			monthTotals = yearDict[dateTime.Year].monthDict[dateTime.Month];
		}

        details[0].text = string.Format("${0:F2}", monthTotals.sales);        // Sales
        details[1].text = string.Format("${0:F2}", monthTotals.tipsNet);      // Tips
        details[2].text = string.Format("{0:F1}%", monthTotals.percent);      // Tip %
        details[3].text = string.Format("${0:F2}", monthTotals.expenses);     // Expenses

        tipouts[0].text = string.Format("${0:F2}", monthTotals.bar);          // Bar
        tipouts[1].text = string.Format("${0:F2}", monthTotals.runner);       // Runner
        tipouts[2].text = string.Format("${0:F2}", monthTotals.assistant);    // Assistant
        tipouts[3].text = string.Format("${0:F2}", monthTotals.other);        // Other
        tipouts[4].text = string.Format("${0:F2}", monthTotals.totalTipout);
    }

    /// <summary>
    /// Set the values for the current yearly totals
    /// </summary>
	public void SetYearVals()
	{
		YearTotals yearTotals = new YearTotals();
		if(GameManager.manager.savedDays.ContainsKey(dateTime.Year))
		{
			yearTotals = yearDict[dateTime.Year];
		}

        details[0].text = string.Format("${0:F2}", yearTotals.sales);        // Sales
        details[1].text = string.Format("${0:F2}", yearTotals.netTips);      // Tips
        details[2].text = string.Format("{0:F1}%", yearTotals.netPercent);   // Tip %
        details[3].text = string.Format("${0:F2}", yearTotals.expenses);     // Expenses

        tipouts[0].text = string.Format("${0:F2}", yearTotals.bar);          // Bar
        tipouts[1].text = string.Format("${0:F2}", yearTotals.runner);       // Runner
        tipouts[2].text = string.Format("${0:F2}", yearTotals.assistant);    // Assistant
        tipouts[3].text = string.Format("${0:F2}", yearTotals.other);        // Other
        tipouts[4].text = string.Format("${0:F2}", yearTotals.totalTipouts);
    }

    /// <summary>
    /// Select a new day from the calendar buttons
    /// </summary>
	public void DayBtn(int dayNum)
	{
        dateTime = new DateTime(dateTime.Year, dateTime.Month, dayNum);
        SetCalendar(dateTime);
		SetYear ();
	}

    /// <summary>
    /// Select a new month from the month buttons
    /// </summary>
    public void MonthBtn(int monthNum)
    {
        if(dateTime.Day <= DateTime.DaysInMonth(dateTime.Year, monthNum))
            dateTime = new DateTime(dateTime.Year, monthNum, dateTime.Day);
        else
            dateTime = new DateTime(dateTime.Year, monthNum, DateTime.DaysInMonth(dateTime.Year, monthNum));
        SetCalendar(dateTime);
        SetYear();
    }

    /// <summary>
    /// Scroll the months +/- 1 month
    /// </summary>
	public void MonthScroll(int delta)
	{
        DateTime min = new DateTime(2013, 01, 01);
        if (dateTime.AddMonths(delta).Date <= DateTime.Now.Date && dateTime.AddMonths(delta).Date >= min.Date)
        {
            dateTime = dateTime.AddMonths(delta);      
            SetCalendar(dateTime);
            SetYear();
        }		
	}

    /// <summary>
    /// Changes the year by + or - an integer
    /// </summary>
    public void YearScroll(int delta)
    {
        if ((dateTime.Year + delta) >= 2013 && (dateTime.Year + delta) <= DateTime.Now.Year)
        {
            dateTime = dateTime.AddYears(delta);
            SetCalendar(dateTime);
            SetYear();
        }
    }

    /// <summary>
    /// Exit button: Closes application
    /// </summary>
	public void Exit()
	{
        Application.Quit();
	}

    /// <summary>
    /// Opens the restarts the application
    /// </summary>
    public void Home()
    {
        SceneManager.LoadScene(SceneManager.GetActiveScene().name);
    }
    #endregion

    #region Private Methods
    /// <summary>
    /// Initialize the YTD panel
    /// </summary>
    private void InitYTDManager()
    {
        panelState = new bool[offPanels.Length];
        for (int i = 0; i < panelState.Length; ++i)
            panelState[i] = false;

        //myday = GameManager.manager.myDay;
        myday = new Day();
        dateTime = new DateTime(myday.myYear, myday.myMonth, myday.myDay);

        SetCalendar(dateTime);
        SetYear();
    }
    #endregion
}
