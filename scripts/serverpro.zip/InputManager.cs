﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;
using System;

public class InputManager : MonoBehaviour 
{
    #region Public Variables
    public static InputManager manager;
	public GameObject[] grpTopBtns;
	public Text[] grpPercents;          // 0-bar; 1-runner; 2-assistant; 3-other
    public GameObject[] barIms;         // 0-percent; 1-number
    public GameObject[] runIms;         // 0-percent; 1-number
    public GameObject[] assIms;         // 0-percent; 1-number
    public GameObject[] othIms;         // 0-percent; 1-number
    public GameObject[] valuesLeft;     // 0-ttl sales; 1-my tips; 2-expenses; 3-am/pm
    public GameObject[] tipsPopsIms;    // 0-cash; 1-credit cards
    public GameObject[] salesPopsIms; 
    public GameObject[] popupBGs;       // 0-1x1; 1-1x2; 2-1x3; 3-1x4
    public GameObject[] leftPopPnls;    // 0-ttl sales; 1-my tips; 2-expenses; 3-am/pm
    public GameObject[] rightPopPnls;   // 0-bar; 1-runner; 2-assistant; 3-other
    public GameObject popupPnl;         // Main popup
    public GameObject inputPopupPnl;    // Input popup
    public GameObject outputPnl;        // GoBtn allows you to open the next panel
	public GameObject inputPanel;
	public InputField grossSalesInput;
	public InputField ccTipsInput;
	public InputField cashTipsInput;
	public InputField btlWineSalesInput;
	public InputField expensesInput;
	public InputField[] grpPercentInputs;
	public InputField grp1Percent;
	public InputField grp2Percent;
	public InputField grp3Percent;
	public InputField grp4Percent;
	public InputField[] grpNumInputs;
	public InputField grp1Num;
	public InputField grp2Num;
	public InputField grp3Num;
	public InputField grp4Num;
	public InputField dayNotes;
    public Button goBtn;                // Triggers the output panel and calculates totals
	public Button editButton;
	public Button doneButton;
	public Text[] grpPercentText;
	public Text barPercentTxt;
	public Text runPercentTxt;
	public Text assistPercentTxt;
	public Text otherPercentTxt;
	public Text[] grpNumText;
	public Text day;
	public Text date;
	public bool pm = true;
    #endregion

    #region Private Methods
    private Day myDay;
    private Color disabledColor = new Color(0.78f, 0.78f, 0.78f, 0.5f);
    private Color enabledColor = new Color(1, 1, 1, 1);
    private bool[,] wrkgrps;

    // TTLSales popup
    // Checks wrkgrps for all sales cats used  
    private bool[] salesActive = { false, false, false, true };     // 0-foodsales; 1-bevsales; 2-winesales; 3-(totsales:true)
    private bool[] salesEntered = { false, false, false, false };   // 0-foodsales; 1-bevsales; 2-winesales; 3-totsales
    private bool[] grpsActive = { false, false, false, false };     // 0-bar; 1-runner; 2-assistant; 3-other
    private bool[] leftSideEntered = { false, false, false, false }; // 0-ttl sales; 1-my tips; 2-expenses; 3-am/pm
    private bool changed = false;
    private float[] salesValues = { 0, 0, 0, 0 };                   // 0-foodsales; 1-bevsales; 2-winesales; 3-totsales
    private float[] percents = { 10f, 10f, 10f, 10f };              // 0-bar; 1-runner; 2-assistant; 3-other
    private int[] number = { 1, 1, 1, 1 };                          // 0-bar; 1-runner; 2-assistant; 3-other

    // MyTips popup
    private bool[] tipsEntered = { false, false };  // 0-cash; 1-credit cards
    private float[] tips = { 0, 0 };                // 0-cash; 1-credit cards

    // Expenses popup
    private bool expenseEntered = false;
    private float expense = 0;

    // Right popups
    private bool[] barEntered = { false, false }; // 0-percent; 1-number
    private bool[] runEntered = { false, false }; // 0-percent; 1-number
    private bool[] assEntered = { false, false }; // 0-percent; 1-number
    private bool[] othEntered = { false, false }; // 0-percent; 1-number
    #endregion

    #region Unity Methods
    private void Awake()
    {
        if (manager == null)
        {
            DontDestroyOnLoad(gameObject);
            manager = this;
        }
        else if (manager != this)
        {
            Destroy(gameObject);
        }
    }

    private void Start()
	{
        myDay = new Day();
        InitBtns ();
        myDay.barPercent = GameManager.manager.Percents[0];
        myDay.runPercent = GameManager.manager.Percents[1];
        myDay.assistPercent = GameManager.manager.Percents[2];
        myDay.otherPercent = GameManager.manager.Percents[3];
    }
    #endregion

    #region Public Methods
    /// <summary>
    /// Resets all of the input panels popups
    /// </summary>
    public void ResetPopups()
    {
        // Resets sales popups
        for (int i = 0; i < 4; i++)
        {
            salesEntered[i] = false;
            salesPopsIms[i].SetActive(true);
        }

        // Resets tips popups
        for (int i = 0; i < tipsEntered.Length; i++)
        {
            tipsEntered[i] = false;
            tipsPopsIms[i].SetActive(true);
        }

        // Reset bar popups
        barIms[0].SetActive(true);
        barIms[1].SetActive(true);
        barEntered[0] = false;
        barEntered[1] = false;

        // Reset run popups
        runIms[0].SetActive(true);
        runIms[1].SetActive(true);
        runEntered[0] = false;
        runEntered[1] = false;

        // Reset assist popups
        assIms[0].SetActive(true);
        assIms[1].SetActive(true);
        assEntered[0] = false;
        assEntered[1] = false;

        // Reset other popups
        othIms[0].SetActive(true);
        othIms[1].SetActive(true);
        othEntered[0] = false;
        othEntered[1] = false;

        // Reset panels specific to the right side buttons
        for (int i = 0; i < rightPopPnls.Length; ++i)
        {
            rightPopPnls[i].SetActive(false);
        }

        // Reset panels specific to the left side buttons
        for (int i = 0; i < leftPopPnls.Length; ++i)
        {
            leftPopPnls[i].SetActive(false);
        }

        // Reset popup background panels
        for (int i = 0; i < popupBGs.Length; ++i)
        {
            popupBGs[i].SetActive(false);
        }

        popupPnl.SetActive(false);
    }

    /// <summary>
    /// Input sales amounts 
    /// </summary>
    public void SalesInput(InputField thisInput)
    {
        changed = true;

        // Food Sales
        if (thisInput.tag == "0")
        {
            salesPopsIms[0].SetActive(false);
            salesEntered[0] = true;
            float.TryParse(thisInput.text, out salesValues[0]);
            thisInput.text = String.Format("$  {0:F2}", salesValues[0]);
            myDay.foodSales = salesValues[0];             
        }
        // Beverage Sales
        else if (thisInput.tag == "1")
        {
            salesPopsIms[1].SetActive(false);
            salesEntered[1] = true;
            float.TryParse(thisInput.text, out salesValues[1]);
            thisInput.text = String.Format("$  {0:F2}", salesValues[1]);
            myDay.barSales = salesValues[1];
        }   
        // Wine Sales        
        else if (thisInput.tag == "2")
        {
            salesPopsIms[2].SetActive(false);
            salesEntered[2] = true;
            float.TryParse(thisInput.text, out salesValues[2]);
            thisInput.text = String.Format("$  {0:F2}", salesValues[2]);
            myDay.wineSales = salesValues[2];
        }
        // Total Sales
        else if (thisInput.tag == "3")
        {
            salesPopsIms[3].SetActive(false);
            salesEntered[3] = true;
            float.TryParse(thisInput.text, out salesValues[3]);
            thisInput.text = String.Format("$  {0:F2}", salesValues[3]);
            valuesLeft[0].GetComponent<Text>().text = String.Format("{0:F2}", salesValues[3]);
            myDay.grossSales = salesValues[3];
        }
           
        for(int i = 0; i < salesEntered.Length; i++)
        {
            if (!salesEntered[i] && salesActive[i])
                return;
        }

        // Shows new value on main panel without waiting for anim
        grpTopBtns[4].SetActive(false);

        // Reset all temp values when popup is complete
        ResetPopups();
        
        leftSideEntered[0] = true;
        leftPopPnls[0].SetActive(false);

        // If all the left side values are entered then enable the go button
        for(int i = 0; i < leftSideEntered.Length; i++)
        {
            if (!leftSideEntered[i])
                return;
        }
        goBtn.interactable = true;
    }
    
    /// <summary>
    /// Input tip amounts
    /// </summary>
    public void TipsInput(InputField thisInput)
    {
        changed = true;

        // Cash tips
        if (thisInput.tag == "0")
        {
            tipsPopsIms[0].SetActive(false);
            tipsEntered[0] = true;
            float.TryParse(thisInput.text, out tips[0]);
            thisInput.text = String.Format("$  {0:F2}", tips[0]);
            myDay.cashTips = tips[0];
        }
        // CC tips
        else if (thisInput.tag == "1")
        {
            tipsPopsIms[1].SetActive(false);
            tipsEntered[1] = true;
            float.TryParse(thisInput.text, out tips[1]);
            thisInput.text = String.Format("$  {0:F2}", tips[1]);
            myDay.ccTips = tips[1];
        }

        for (int i = 0; i < tipsEntered.Length; i++)
        {
            if (!tipsEntered[i])
                return;
        }

        // Shows new value on main panel without waiting for anim
        grpTopBtns[5].SetActive(false);

        // Reset all temp values whe popup is done
        ResetPopups();
           
        valuesLeft[1].GetComponent<Text>().text = String.Format("{0:F2}", (tips[0] + tips[1]));        
        leftSideEntered[1] = true;

        // If all the left side values are entered then enable the go button
        for (int i = 0; i < leftSideEntered.Length; i++)
        {
            if (!leftSideEntered[i])
                return;
        }
        goBtn.interactable = true;
    }

    /// <summary>
    /// Input expenses amount
    /// </summary>
    public void ExpenseInput(InputField thisInput)
    {
        expenseEntered = true;
        float.TryParse(thisInput.text, out expense);
        thisInput.text = String.Format("$  {0:F2}", expense);
        valuesLeft[2].GetComponent<Text>().text = String.Format("{0:F2}", expense);
        myDay.expenses = expense;

        // Reset all temp values when popup is done
        ResetPopups();

        leftSideEntered[2] = true;
        leftPopPnls[2].SetActive(false);

        // Shows new value on main panel without waiting for anim
        grpTopBtns[6].SetActive(false);

        // If all the left side values are entered then enable the go button
        for (int i = 0; i < leftSideEntered.Length; i++)
        {
            if (!leftSideEntered[i])
                return;
        }
        goBtn.interactable = true;
    }

    /// <summary>
    /// Sets am or pm for the shift
    /// </summary>
    public void PMButton(GameObject thisBtn)
    {
        if (!thisBtn.activeInHierarchy)
            thisBtn.SetActive(true);
        pm = !pm;
        //####################################################################################
        //GameManager.manager.myDay.SetDatePM(pm);
        myDay.SetDatePM (pm);

        if (pm)
        {
            thisBtn.GetComponentInChildren<Text>().text = "PM";
        }
        else
            thisBtn.GetComponentInChildren<Text>().text = "AM";

        leftSideEntered[3] = true;

        // If all the left side values are entered then enable the go button
        for (int i = 0; i < leftSideEntered.Length; i++)
        {
            if (!leftSideEntered[i])
                return;
        }
        goBtn.interactable = true;
    }

    /// <summary>
    /// Input bar percent and number of bartenders
    /// </summary>
    public void BarInput(InputField thisInput)
    {
        changed = true;

        // Bartenders %
        if (thisInput.tag == "0")
        {
            barIms[0].SetActive(false);
            barEntered[0] = true;
            float.TryParse(thisInput.text, out percents[0]);
            thisInput.text = String.Format("{0:F1}  %", percents[0]);
            myDay.barPercent = percents[0];
        }
        // Bartenders #
        else if (thisInput.tag == "1")
        {
            barIms[1].SetActive(false);
            barEntered[1] = true;
            int.TryParse(thisInput.text, out number[0]);
            thisInput.text = String.Format("{0}  #", number[0]);
            myDay.barNum = number[0];
        }

        if (myDay.barPercent > 0 && myDay.barNum > 0)
        {
            grpPercents[0].GetComponent<Text>().text = String.Format("{0:F1} %", percents[0]);
            myDay.GrpsActive[0] = true;
        }
        else
        {
            myDay.GrpsActive[0] = false;
            grpTopBtns[0].SetActive(false);
        }

        for (int i = 0; i < barEntered.Length; ++i)
        {
            if (!barEntered[i])
                return;
        }

        // Reset values when popup is done
        ResetPopups();
    }

    /// <summary>
    /// Input runners percent and number of bartenders
    /// </summary>
    public void RunnersInput(InputField thisInput)
    {
        changed = true;

        // Runners %
        if (thisInput.tag == "0")
        {
            runIms[0].SetActive(false);
            runEntered[0] = true;
            float.TryParse(thisInput.text, out percents[1]);
            thisInput.text = String.Format("{0:F1}  %", percents[1]);
            myDay.runPercent = percents[1];
        }
        // Runners #
        else if (thisInput.tag == "1")
        {
            runIms[1].SetActive(false);
            runEntered[1] = true;
            int.TryParse(thisInput.text, out number[1]);
            thisInput.text = String.Format("{0}  #", number[1]);
            myDay.runNum = number[1];

        }

        if (myDay.runNum > 0 && myDay.runPercent > 0)
        {
            grpPercents[1].GetComponent<Text>().text = String.Format("{0:F1} %", percents[1]);
            myDay.GrpsActive[1] = true;
        }
        else
        {
            myDay.GrpsActive[1] = false;
            grpTopBtns[1].SetActive(false);
        }

        for (int i = 0; i < runEntered.Length; i++)
        {
            if (!runEntered[i])
                return;
        }

        ResetPopups();
    }

    /// <summary>
    /// Input assistants percent and number of bartenders
    /// </summary>
    public void AssistantsInput(InputField thisInput)
    {
        changed = true;

        // Assistant %
        if (thisInput.tag == "0")
        {
            runIms[0].SetActive(false);
            assEntered[0] = true;
            float.TryParse(thisInput.text, out percents[2]);
            thisInput.text = String.Format("{0:F1}  %", percents[2]);
            myDay.assistPercent = percents[2];
        }
        // Assistant #
        else if (thisInput.tag == "1")
        {
            runIms[1].SetActive(false);
            assEntered[1] = true;
            int.TryParse(thisInput.text, out number[2]);
            thisInput.text = String.Format("{0}  #", number[2]);
            myDay.assistNum = number[2];
        }

        if (myDay.assistPercent > 0 && myDay.assistNum > 0)
        {
            grpPercents[2].GetComponent<Text>().text = String.Format("{0:F1} %", percents[2]);
            myDay.GrpsActive[2] = true;
        }
        else
        {
            myDay.GrpsActive[2] = false;
            grpTopBtns[2].SetActive(false);
        }

        for (int i = 0; i < assEntered.Length; i++)
        {
            if (!assEntered[i])
                return;
        }

        ResetPopups();
    }

    /// <summary>
    /// Input other percent and number of bartenders
    /// </summary>
    public void OtherInput(InputField thisInput)
    {
        changed = true;

        // Other %
        if (thisInput.tag == "0")
        {
            othIms[0].SetActive(false);
            othEntered[0] = true;
            float.TryParse(thisInput.text, out percents[3]);
            thisInput.text = String.Format("{0:F1}  %", percents[3]);
            myDay.otherPercent = percents[3];
        }
        // Other #
        else if (thisInput.tag == "1")
        {
            othIms[1].SetActive(false);
            othEntered[1] = true;
            int.TryParse(thisInput.text, out number[3]);
            thisInput.text = String.Format("{0}  #", number[3]);
            myDay.somNum = number[3];
        }

        if(myDay.otherPercent > 0 && myDay.somNum > 0)
        {
            grpPercents[3].GetComponent<Text>().text = String.Format("{0:F1} %", percents[3]);
            myDay.GrpsActive[3] = true;
        }
        else
        {
            myDay.GrpsActive[3] = false;
            grpTopBtns[3].SetActive(false);
        }
        

        for (int i = 0; i < othEntered.Length; i++)
        {
            if (!othEntered[i])
                return;
        }

        ResetPopups();
    }

    /// <summary>
    /// Transfer data to GameManager and go to output panel
    /// </summary>
    public void GoButton()
    {
        // Adds what each group tips out on and finds the total for that group
        float groupTotal = 0;
        for (int i = 0; i < 4; ++i)
        {
            groupTotal = 0;

            // Food   
            if (wrkgrps[i, 0])
                groupTotal += myDay.foodSales;

            // Bev
            if (wrkgrps[i, 1])
                groupTotal += myDay.barSales;

            // Wine
            if (wrkgrps[i, 2])
                groupTotal += myDay.wineSales;

            // Other
            if (wrkgrps[i, 3])
                groupTotal += myDay.grossSales;

            if (i == 0) // Bar
                myDay.barTotal = groupTotal * myDay.barPercent * 0.01f;
            else if (i == 1) // Runner
                myDay.runTotal = groupTotal * myDay.runPercent * 0.01f;
            else if (i == 2) // Assistant
                myDay.assistTotal = groupTotal * myDay.assistPercent * 0.01f;
            else if (i == 3) // Other
                myDay.otherTotal = groupTotal * myDay.otherPercent * 0.01f;
        }

        GameManager.manager.myDay = myDay;
        StopAllCoroutines();
        outputPnl.SetActive(true);
        OutputManager.manager.OutputActive(changed);
        gameObject.SetActive(false);
    }

    /// <summary>
    /// Resets the input panel if returning from another panel
    /// </summary>
    public void InputActive()
    {
        StartCoroutine(BtnBlink());
    }
    #endregion

    #region Private Methods
    /// <summary>
    /// Initializes everything for the input scene
    /// </summary>
    private void InitBtns()
    {
        inputPopupPnl.SetActive(true); // Turn this off at the end of input
        StartCoroutine(BtnBlink());
        wrkgrps = GameManager.manager.WorkGroups;
        percents = GameManager.manager.Percents;

        for (int i = 0; i < 4; i++)
        {
            grpPercents[i].text = string.Format("{0:F1}  %", percents[i]);
            for (int j = 0; j < 4; j++)
            {
                if (wrkgrps[i, j])
                {
                    myDay.GrpsActive[i] = true;
                    salesActive[j] = true;
                    salesPopsIms[j].GetComponent<Image>().color = enabledColor;
                }
            }
        }
    }

    /// <summary>
    /// Makes all of the input buttons blink with the input value and button title
    /// </summary>
    private IEnumerator BtnBlink()
    {
        bool onoff = false;
        bool blink = true;
        while (blink)
        {
            onoff = !onoff;

            // Total Sales popups
            if(salesEntered[0])
            {
                salesPopsIms[0].SetActive(onoff);
            }
            if (salesEntered[1])
            {
                salesPopsIms[1].SetActive(onoff);
            }
            if (salesEntered[2])
            {
                salesPopsIms[2].SetActive(onoff);
            }
            if (salesEntered[3])
            {
                salesPopsIms[3].SetActive(onoff);
            }

            // Tips popups
            if (tipsEntered[0])
            {
                tipsPopsIms[0].SetActive(onoff);
            }
            if (tipsEntered[1])
            {
                tipsPopsIms[1].SetActive(onoff);
            }

            // Left side of input panel button blink
            if (leftSideEntered[0])
            {
                grpTopBtns[4].SetActive(onoff);
            }
            if (leftSideEntered[1])
            {
                grpTopBtns[5].SetActive(onoff);
            }
            if (leftSideEntered[2])
            {
                grpTopBtns[6].SetActive(onoff);
            }
            if (leftSideEntered[3])
            {
                grpTopBtns[7].SetActive(onoff);
            }

            // Bar popups
            if (barEntered[0])
            {
                barIms[0].SetActive(onoff);
            }
            if (barEntered[1])
            {
                barIms[1].SetActive(onoff);
            }

            // Runner popups
            if (runEntered[0])
            {
                runIms[0].SetActive(onoff);
            }
            if (runEntered[1])
            {
                runIms[1].SetActive(onoff);
            }

            // Assistant popups
            if (assEntered[0])
            {
                assIms[0].SetActive(onoff);
            }
            if (assEntered[1])
            {
                assIms[1].SetActive(onoff);
            }

            // Other popups
            if (othEntered[0])
            {
                othIms[0].SetActive(onoff);
            }
            if (othEntered[1])
            {
                othIms[1].SetActive(onoff);
            }

            // Right sid of input panel button blink
            if (myDay.GrpsActive[0])
            {
                grpTopBtns[0].SetActive(onoff);
            }
            if (myDay.GrpsActive[1])
            {
                grpTopBtns[1].SetActive(onoff);
            }
            if (myDay.GrpsActive[2])
            {
                grpTopBtns[2].SetActive(onoff);
            }
            if (myDay.GrpsActive[3])
            {
                grpTopBtns[3].SetActive(onoff);
            }

            yield return new WaitForSeconds(1f);
        }

        yield return null;
    }
    #endregion
}
