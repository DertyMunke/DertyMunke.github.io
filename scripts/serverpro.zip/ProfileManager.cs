﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;
using System;
using System.Runtime.Serialization.Formatters.Binary;
using System.IO;

public class ProfileManager : MonoBehaviour 
{
    #region Public Variables
    public static ProfileManager manager;
    public GameObject[] skipNaming; // If editing profile settings
    public GameObject popupsPanel;
    public GameObject logoPanel;
    public GameObject setupPnl;
    public GameObject inputPnl;
    public InputField inputProfile;
    public Button[] optionsProfile; // The profile buttons in the options popup
    public Button deleteButton;
    public Button statsButton;
    public Button startButton;
    public Button editProfBtn;
    public Button profile_1;
    public Button profile_2;
    public Button profile_3;
    public Sprite[] profileDefault;
    public Sprite[] profileBlanks;
    public bool skipProfiles = false;
    public bool profile_1_active = false;
    public bool profile_2_active = false;
    public bool profile_3_active = false;
    #endregion

    #region Private Variables
    private FileStream file = null;
	private Button selectButton = null;
    private bool changeSettings = false;
    private bool saving = true;
    #endregion

    #region Unity Methods
    private void Start()
	{
        manager = this;
		//for testing only
		Debug.Log (Application.persistentDataPath);
		//ResetProfilesTestingFunction ();

		//splashTimer = Time.time + 2.5f;
		StartingProfiles ();
	}
	
	private void Update()
	{
		//if(splashTimer < Time.time)
		//{
		//	logoPanel.SetActive(false);
		//}
		ActivateFuntionButtons ();
	}
    #endregion

    #region Public Methods
    /// <summary>
    /// Enables all of the profile buttons to be active for saving
    /// </summary>
    public void EnableAllProfileBtns()
    {
        saving = true;

        optionsProfile[0].interactable = true;
        optionsProfile[0].GetComponentInChildren<Text>().text = profile_1.GetComponentInChildren<Text>().text;

        optionsProfile[1].interactable = true;
        optionsProfile[1].GetComponentInChildren<Text>().text = profile_2.GetComponentInChildren<Text>().text;

        optionsProfile[2].interactable = true;
        optionsProfile[2].GetComponentInChildren<Text>().text = profile_3.GetComponentInChildren<Text>().text;
    }

    /// <summary>
    /// From the options popup, opens the profile buttons. Allows user to select from available profiles
    /// </summary>
    public void ChangeProfileBtn()
    {
        if (profile_1_active)
        {
            optionsProfile[0].interactable = true;
            optionsProfile[0].GetComponentInChildren<Text>().text = profile_1.GetComponentInChildren<Text>().text;
        }

        if (profile_2_active)
        {
            optionsProfile[1].interactable = true;
            optionsProfile[1].GetComponentInChildren<Text>().text = profile_2.GetComponentInChildren<Text>().text;
        }

        if (profile_3_active)
        {
            optionsProfile[2].interactable = true;
            optionsProfile[2].GetComponentInChildren<Text>().text = profile_3.GetComponentInChildren<Text>().text;
        }
    }

    /// <summary>
    /// From the options popup, opens the profile buttons. Allows user to select from empty profile slots and create new profile
    /// </summary>
    public void NewProfileBtn()
    {
        if (!profile_1_active)
        {
            optionsProfile[0].interactable = true;
        }
        else
            optionsProfile[0].GetComponentInChildren<Text>().text = profile_1.GetComponentInChildren<Text>().text;

        if (!profile_2_active)
        {
            optionsProfile[1].interactable = true;
        }
        else
            optionsProfile[1].GetComponentInChildren<Text>().text = profile_2.GetComponentInChildren<Text>().text;

        if (!profile_3_active)
        {
            optionsProfile[2].interactable = true;
        }
        else
            optionsProfile[2].GetComponentInChildren<Text>().text = profile_3.GetComponentInChildren<Text>().text;
    }

    /// <summary>
    /// Funcion called when the submit button is pushed
    /// </summary>
    public void OnSubmit(Text line)
    {
        // Activates the profile that is selected
        if (selectButton != null)
        {
            if (line.text == "")
            {
                // If no text was entered 
                //inputProfile.interactable = false;
                if (selectButton.GetComponentInChildren<Text>().text == "")
                    line.text = selectButton.name;
                else
                    line.text = selectButton.GetComponentInChildren<Text>().text;
            }
        }
        else
        {
            Debug.Log("Error: No button selected");
        }
    }

    /// <summary>
    /// Saves the newly created profile from the setup panel
    /// </summary>
    public void SaveNewProfileName()
    {
        selectButton.GetComponentInChildren<Text>().text = inputProfile.text;

        if (selectButton.name == "Profile 1")
        {
            profile_1_active = true;
            profile_1.GetComponentInChildren<Text>().text = inputProfile.text;
        }          
        else if (selectButton.name == "Profile 2")
        {
            profile_2_active = true;
            profile_2.GetComponentInChildren<Text>().text = inputProfile.text;
        }           
        else if (selectButton.name == "Profile 3")
        {
            profile_3_active = true;
            profile_3.GetComponentInChildren<Text>().text = inputProfile.text;
        }

        // Enables the new profile as the active profile
        GameManager.manager.currProfileName = inputProfile.text;
        
        // Saves new profile state
        GameManager.manager.Save(inputProfile.text);

        SaveProfiles();
    }

    /// <summary>
    /// Enables the popup profile buttons to change settings 
    /// </summary>
    public void ChangeSettings()
    {
        changeSettings = true;
    }

    /// <summary>
    /// Selects the current profile of the button that is pressed
    /// </summary>
	public void ProfileButton(Button button)
	{ 
		selectButton = button;

        if (changeSettings)
        {
            changeSettings = false;
            skipNaming[0].SetActive(false);
            skipNaming[1].SetActive(true);
            setupPnl.SetActive(true);
            inputProfile.text = selectButton.GetComponentInChildren<Text>().text;
            GameManager.manager.currProfileName = inputProfile.text;
        }
        else if (selectButton.name == "Profile 1")
		{
			if(!profile_1_active)
            {
                inputProfile.text = "Profile 1";
                setupPnl.SetActive(true);
            }
            else
			{
				inputProfile.text = selectButton.GetComponentInChildren<Text>().text;
				GameManager.manager.currProfileName = inputProfile.text;
			}
		}
		else if(selectButton.name == "Profile 2")
		{
			if(!profile_2_active)
			{
                inputProfile.text = "Profile 2";
                setupPnl.SetActive(true);
            }
			else
			{
                inputProfile.text = selectButton.GetComponentInChildren<Text>().text;
				GameManager.manager.currProfileName = inputProfile.text;
			}
		}
		else if(selectButton.name == "Profile 3")
		{
			if(!profile_3_active)
			{
                inputProfile.text = "Profile 3";
                setupPnl.SetActive(true);
            }
			else
			{
                inputProfile.text = selectButton.GetComponentInChildren<Text>().text;
				GameManager.manager.currProfileName = inputProfile.text;
			}
		}
	}

    /// <summary>
    ///  Deletes the currently selected profile
    /// </summary>
    public void DeleteButton()
	{
		GameManager.manager.currProfileName = "";
		GameManager.manager.Delete (inputProfile.text);

		if(selectButton.name == "Profile 1")
		{
			profile_1.GetComponentInChildren<Text>().text = "";
            profile_1.GetComponent<Image>().sprite = profileDefault[0];
			profile_1_active = false;
		}
		else if(selectButton.name == "Profile 2")
		{
			profile_2.GetComponentInChildren<Text>().text = "";
            profile_2.GetComponent<Image>().sprite = profileDefault[1];
            profile_2_active = false;
		}
		else if(selectButton.name == "Profile 3")
		{
			profile_3.GetComponentInChildren<Text>().text = "";
            profile_3.GetComponent<Image>().sprite = profileDefault[2];
            profile_3_active = false;
		}

		ActivateFuntionButtons ();

		inputProfile.text = "";
		selectButton = null;
		
		SaveProfiles ();
	}

    /// <summary>
    /// Skips the input scene and goes to ytd scene to see previous entries
    /// </summary>
	public void StatsButton()
	{
		GameManager.manager.Load (inputProfile.text);
		Application.LoadLevel("YTDs");
	}

    /// <summary>
    /// Starts creating a new profile or new saved day stats 
    /// </summary>
	public void StartButton()
	{
		GameManager.manager.Load (inputProfile.text);
        inputPnl.SetActive(true);
		if(GameManager.manager.SetupComplete == false)
		{
            setupPnl.SetActive(true);
		}
	}

    /// <summary>
    /// Allows you to calculate a days stats without saving the data
    /// </summary>
    public void SkipProfiles()
	{
		GameManager.manager.currProfileName = "";
        skipProfiles = true;
		//Application.LoadLevel("Setup");
	}

    /// <summary>
    /// Exits the application 
    /// </summary>
	public void Exit()
	{
		//SaveProfiles();
		Application.Quit();
	}
    #endregion

    #region Private Methods
    /// <summary>
    /// This function is for testing purposes and resets the saved profiles
    /// </summary>
    private void ResetProfilesTestingFunction()
    {
        inputProfile.text = "";
        profile_1.GetComponentInChildren<Text>().text = "Profile 1";
        profile_2.GetComponentInChildren<Text>().text = "Profile 2";
        profile_3.GetComponentInChildren<Text>().text = "Profile 3";
        profile_1_active = false;
        profile_2_active = false;
        profile_3_active = false;
        SaveProfiles();
    }

    /// <summary>
    /// Activates buttons if there is a profile loaded
    /// </summary>
    private void ActivateFuntionButtons()
    {
        if (GameManager.manager.SetupComplete)
        {
            deleteButton.interactable = true;
            statsButton.interactable = true;
            startButton.interactable = true;
            editProfBtn.interactable = true;
        }
        else
        {
            deleteButton.interactable = false;
            statsButton.interactable = false;
            startButton.interactable = false;
            editProfBtn.interactable = false;
        }
    }

    /// <summary>
    /// Checks for saved profiles
    /// </summary>
    private void StartingProfiles()
    {
        // If there is not a saved profiles doc 
        if (!File.Exists(Application.persistentDataPath + "/profiles.prof"))
        {
            // Create a saved profiles doc
            SaveProfiles();
        }
        else
        {
            // Otherwise load the profiles from the profiles doc
            LoadProfiles();
        }
    }

    /// <summary>
    /// Save all of the current profiles data
    /// </summary>
    private void SaveProfiles()
    {
        try
        {
            BinaryFormatter bf = new BinaryFormatter();
            file = File.Create(Application.persistentDataPath + "/profiles.prof");
            ProfilesData data = new ProfilesData();

            data.current = inputProfile.text;
            data.profile_1 = profile_1.GetComponentInChildren<Text>().text;
            data.profile_2 = profile_2.GetComponentInChildren<Text>().text;
            data.profile_3 = profile_3.GetComponentInChildren<Text>().text;

            data.profile_1_active = profile_1_active;
            data.profile_2_active = profile_2_active;
            data.profile_3_active = profile_3_active;

            bf.Serialize(file, data);
            file.Close();
        }
        finally
        {
            if (file != null)
                file.Close();
        }
    }

    /// <summary>
    /// Load all of the previously saved profiles data
    /// </summary>
    private void LoadProfiles()
    {
        try
        {
            BinaryFormatter bf = new BinaryFormatter();
            file = File.Open(Application.persistentDataPath + "/profiles.prof", FileMode.Open);
            ProfilesData data = (ProfilesData)bf.Deserialize(file); //without cast, makes generic obj
            file.Close();

            inputProfile.text = data.current;
            profile_1.GetComponentInChildren<Text>().text = data.profile_1;
            profile_2.GetComponentInChildren<Text>().text = data.profile_2;
            profile_3.GetComponentInChildren<Text>().text = data.profile_3;

            profile_1_active = data.profile_1_active;
            profile_2_active = data.profile_2_active;
            profile_3_active = data.profile_3_active;

            if (profile_1_active)
                profile_1.GetComponent<Image>().sprite = profileBlanks[0];
            if (profile_2_active)
                profile_2.GetComponent<Image>().sprite = profileBlanks[1];
            if (profile_3_active)
                profile_3.GetComponent<Image>().sprite = profileBlanks[2];

        }
        finally
        {
            if (file != null)
                file.Close();
        }

        GameManager.manager.currProfileName = inputProfile.text;
        GameManager.manager.Load(inputProfile.text);
    }
    #endregion
}

//data container that allows you to write the data to a file
[Serializable]
class ProfilesData
{
	public string current;
	public string profile_1;
	public string profile_2;
	public string profile_3;
	public bool profile_1_active;
	public bool profile_2_active;
	public bool profile_3_active;

}