﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class MonthTotals 
{
	public Dictionary<int, DayTotals> daysDict = new Dictionary<int, DayTotals> ();
	public float sales = 0;  
	public float tipsNet = 0;
	public float percent = 0;
	public float expenses = 0;  //End month quick view
	public float wineSales = 0;
	public float tipsGross = 0;
	public float percentGross = 0;
	public float bar = 0;
	public float other = 0;
	public float runner = 0;
	public float assistant = 0;
	public float totalTipout = 0;  //End month detailed view
	public int month = 0;

    /// <summary>
    /// Creates a zeroed MonthTotals 
    /// </summary>
	public MonthTotals(){}

    /// <summary>
    /// Constructor that takes a month of days and initializes this to that months values
    /// </summary>
	public MonthTotals(Dictionary<int, DayTotals> newDays)
	{
		daysDict = newDays;
		foreach(DayTotals day in newDays.Values)
		{
			sales = sales + day.sales;
			tipsNet = tipsNet + day.tipsNet;
			expenses = expenses + day.expenses;
			wineSales = wineSales + day.wineSales;
			tipsGross = tipsGross + day.grossTips;
			bar = bar + day.bar;
			other = other + day.other;
			runner = runner + day.runner;
			assistant = assistant + day.assistant;
			totalTipout = totalTipout + day.totalTipout; 
			month = day.myMonth;
//			Debug.Log ("month" + monthDGrossTips.ToString ());
		}
		if(sales == 0)
		{
			percent = 0;
			percentGross = 0;
		}
		else
		{
			percent = tipsNet / sales * 100;
			percentGross = tipsGross / sales * 100;
		}
	}
}
