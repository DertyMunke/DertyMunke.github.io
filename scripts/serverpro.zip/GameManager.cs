﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;
using System.Collections.Generic;
using System;
using System.Runtime.Serialization.Formatters.Binary;
using System.IO;

public class GameManager : MonoBehaviour
{
    #region Public Variables
    public static GameManager manager;
    public Day myDay;
    public Dictionary<int, Dictionary<int, Dictionary<int, Day[]>>> savedDays = new Dictionary<int, Dictionary<int, Dictionary<int, Day[]>>>();
    public Dictionary<int, Dictionary<int, string>> monthlyNotes = new Dictionary<int, Dictionary<int, string>>();
    public Dictionary<int, string> yearlyNotes = new Dictionary<int, string>();

    // The first string is the name: ie WorkGroup1 and the first element in array is group name
    // The following elements are the selected assignments
    public Dictionary<String, String[]> workgroups = new Dictionary<string, string[]>();
    public List<int[]> daysLookup = new List<int[]>();  // Saved date values {year, month, day, AM/PM} -> AM == 0
    public String currProfileName = "";
    public String tipOutOn = "";  // Tip out on "Sales", "Tips", or "Both"
    public String customName = "";  

    // Categories to tip out on: Bar, runner, assistant, Other
    public bool bar = false;    //0
    public bool assist = false; //1
    public bool run = false;    //2
    public bool other = false;  //3

    // Categories for tipout: Bev, Food, Wine, TotSales, Custom
    public bool bev = false;    //0
    public bool food = false;   //1
    public bool wine = false;   //2
    public bool grossSales = false;  //3
    public bool custom = false;
    public int[] years;
    public int[] months = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12 };
    public int yearIndex = 0;
    public int monthIndex = 0;
    public int dayIndex = 0; // DayIndex is the actual selected day
    public int AmPm = 0;
    #endregion

    #region Private Variables
    private FileStream file = null;
    private bool setup = false;  // Has setup been completed  
    private bool overideData = false; // Make this true if overide is confirmed
    #endregion

    #region Properties
    // Categories: Bar, runner, assistant, Other
    private bool[,] wrkgrps = { { false, true, true, false }, { true, false, false, false},
        { false, false, false, false}, { false, false, false, false}}; // Each: Food, Bev, Wine, TotSales, Custom

    private float[] percents = { 3.0f, 3.0f, 3.0f, 3.0f };
    private int[] availableYears = { 2012, 2013, 2014, 2015, 2016, 2017, 2018, 2019, 2020, 2021, 2022, 2023, 2024, 2025, 2026, 2027, 2028, 2029, 2030 };

    public float[] Percents { get { return percents; } set { percents = value; } }
    public bool[,] WorkGroups { get { return wrkgrps; } set { wrkgrps = value; } }
    public bool SetupComplete { get { return setup; } set { setup = value; } }
    public bool SetOveride { set { overideData = value; } }
    #endregion

    #region Unity Methods
    private void Awake()
	{
		if(manager == null)
		{
			DontDestroyOnLoad(gameObject);
			manager = this;
		}
		else if(manager != this)
		{
			Destroy(gameObject);
		}
	}

    private void Start()
    {
        myDay = new Day();
        years = availableYears;
        //InitIndex();  //Set the year to current
    }
    #endregion

    #region Public Methods
    /// <summary>
    /// Test for deletion
    /// </summary>
    public Day[] GetDay()
	{
		Day[] noMatch = new Day[2];
		noMatch[0] = new Day();

		if (savedDays.ContainsKey(years [yearIndex])) 
		{
			if(savedDays[years [yearIndex]].ContainsKey(months [monthIndex]))
			{
				if(savedDays[years [yearIndex]][months [monthIndex]].ContainsKey(dayIndex))
				{
					return savedDays [years [yearIndex]] [months [monthIndex]] [dayIndex];
				}
				else
					return noMatch;
			}
			else
				return noMatch;
		}
		else
			return noMatch;
	}

    /// <summary>
    /// Adds a new day to the dictionary of saved days. Returns true if success
    /// </summary>
	public bool AddDayToDict(Day saveDay)
	{
		//The following adds myDay to the savedDays
		Day[] tempAmPm = new Day[2];
		Dictionary<int, Day[]> tempDay = new Dictionary<int, Day[]> ();
		Dictionary<int, Dictionary<int, Day[]>> tempMonth = new Dictionary<int, Dictionary<int, Day[]>>();
		
		tempAmPm [saveDay.amPm] = saveDay;
		tempDay.Add (saveDay.myDay, tempAmPm);
		tempMonth.Add (saveDay.myMonth, tempDay);

		if (savedDays.ContainsKey(saveDay.myYear)) 
		{
			if(savedDays[saveDay.myYear].ContainsKey(saveDay.myMonth))
			{
				if(savedDays[saveDay.myYear][saveDay.myMonth].ContainsKey(saveDay.myDay))
				{
					if(savedDays[saveDay.myYear][saveDay.myMonth][saveDay.myDay][saveDay.amPm] != null)
					{
						//Add warning -> "Would you like to override data?"
						
                        if (overideData)
                        {
                            Debug.Log("Overriding data");
                            overideData = false;
                            savedDays[saveDay.myYear][saveDay.myMonth][saveDay.myDay][saveDay.amPm] = saveDay;
                            return true;
                        }
                        else
                            return false;
						    
                    }
					else
                    {
                        savedDays[saveDay.myYear][saveDay.myMonth][saveDay.myDay][saveDay.amPm] = saveDay;
                        return true;
                    }						
				}
				else
					savedDays[saveDay.myYear][saveDay.myMonth].Add(saveDay.myDay, tempAmPm);
			}
			else
				savedDays[saveDay.myYear].Add (saveDay.myMonth, tempDay);
		}
		else
			savedDays.Add (saveDay.myYear, tempMonth);

        return true;
	}

    /// <summary>
    /// Creates days for testing
    /// </summary>
	public void TestSave()
	{
		AddDayToDict (myDay);

		for(int i = 10; i <= 20; i++)
		{
			Day tempDay = new Day(2012, 2, i);

			tempDay.amPm = 1;
			tempDay.grossSales = 1000;
			tempDay.ccTips = 160;
			tempDay.cashTips = 40;
			tempDay.wineSales = 100;
			tempDay.expenses = 20;
			tempDay.grossTips = 200;
			tempDay.netTips = 148.07f;
			tempDay.barSales = 14.7f;
			tempDay.wineSales = 4;
			tempDay.foodSales = 8.82f;
			tempDay.assistTotal = 4.41f;
			tempDay.totalTipout = 31.93f;
			tempDay.SetOutput();

			AddDayToDict(tempDay);
		}

		Save (currProfileName);
	}
	
    /// <summary>
    /// Saves profile data
    /// </summary>
	public void Save(string playerName = "")
	{
        if(playerName == "")
        {
            playerName = currProfileName;
        }

		try
		{
			BinaryFormatter bf = new BinaryFormatter ();
			file = File.Create (Application.persistentDataPath + "/" + playerName + ".dat"); 
			PlayerData data = new PlayerData();
			
			// Save data goes here 
			data.savedDays = savedDays;
			data.monthlyNotes = monthlyNotes;
			data.yearlyNotes = yearlyNotes;
			data.workgroups = workgroups;
			data.currProfileName = currProfileName;
			data.setup = setup;
            data.wrkgrps = wrkgrps;
            data.percents = percents;
			bf.Serialize (file, data);
			file.Close ();
		}
		finally
		{
			if(file != null)
				file.Close();
		}
		
	}
	
    /// <summary>
    /// Loads profile data
    /// </summary>
	public void Load(string playerName)
	{
		if(File.Exists(Application.persistentDataPath + "/" + playerName + ".dat"))
		{
			try
			{
				BinaryFormatter bf = new BinaryFormatter();
				file = File.Open(Application.persistentDataPath + "/" + playerName + ".dat", FileMode.Open);
				PlayerData data = (PlayerData)bf.Deserialize(file); //without cast, makes generic obj
				file.Close();

				// Load data goes here 
				savedDays = data.savedDays;
				monthlyNotes = data.monthlyNotes;
				yearlyNotes = data.yearlyNotes;
				workgroups = data.workgroups;
				currProfileName = data.currProfileName;
				setup = data.setup;
                wrkgrps = data.wrkgrps;
                percents = data.percents;

            }
			finally
			{
				if(file != null)
					file.Close();
			}
			
			currProfileName = playerName;
		}
	}
	
    /// <summary>
    /// Deletes a profiles data
    /// </summary>
	public void Delete(string playerName)
	{
		if(File.Exists(Application.persistentDataPath + "/" + playerName + ".dat"))
		{
			File.Delete(Application.persistentDataPath + "/" + playerName + ".dat");
		}
	}
    #endregion

    #region Private Methods
    /// <summary>
    /// Test for deletion
    /// </summary>
    private void InitIndex()
    {
        for (int i = 0; i < years.Length; i++)
        {
            if (myDay.myYear == years[i])
            {
                yearIndex = i;
                break;
            }
        }
        for (int i = 0; i < months.Length; i++)
        {
            if (myDay.myMonth == months[i])
            {
                monthIndex = i;
                break;
            }
        }
        dayIndex = myDay.myDay;
    }
    #endregion
}

// Data container that allows you to write the data to a file
[Serializable]
class PlayerData
{
	// Saved data objects go here
	public Dictionary<int, Dictionary<int, Dictionary<int, Day[]>>> savedDays = new Dictionary<int, Dictionary<int, Dictionary<int, Day[]>>> ();
	public Dictionary<int, Dictionary<int, string>> monthlyNotes = new Dictionary<int, Dictionary<int, string>> ();
	public Dictionary<String, String[]> workgroups = new Dictionary<string, string[]> ();
	public Dictionary<int, string> yearlyNotes = new Dictionary<int, string> ();
	public String currProfileName;
	public bool setup;
    public bool[,] wrkgrps ; // The categories and their percents
    public float[] percents;
}

