﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;

public class SetupManager : MonoBehaviour
{
    #region Public Variables
    public GameObject[] toOptionsPnls;  // Panels: bar, assistant, runner, other, next, skip
    public GameObject[] toPercentPnls;  // Percent panels that follow "toOptionsPnls"
    public GameObject salesBtnPnl;      // Contains the sales btns
    public InputField[] percentBtns;    // Input fields on toPercentPnls 
    public Button[] categoryBtns;       // bar, runner, assistant, other
    public Button[] tipOutBtns;         // Bev, food, wine, total sales
    public Sprite[] toBlackBtns;
    public Sprite[] toWhiteBtns;
    public Sprite[] catBlackBtns;
    public Sprite[] catWhiteBtns;
    #endregion

    #region Private Variables
    private bool[] salesBtnIndex = { false, false, false, false };
    private bool[] activeCats = { false, false, false, false };
    private bool[] activeTOs = { false, false, false, false };
    private bool[,] catsTOs =  { {false, false, false, false }, {false, false, false, false}, 
        {false, false, false, false}, {false, false, false, false} };
    private float[] percents = { 10f, 10f, 10f, 10f };
    private int index = 0;
    #endregion

    #region Public Methods
    /// <summary>
    /// Resets the tipout btns to the default state
    /// </summary>
    public void ResetTOBtns()
    {
        for(int i = 0; i < tipOutBtns.Length; i++)
        {
            tipOutBtns[i].GetComponent<Image>().sprite = toBlackBtns[i];
            activeTOs[i] = false;
        }
    }

    /// <summary>
    /// Swaps the sprites for category buttons and enables or disables the category
    /// </summary>
    public void CatSpriteSwap(Button thisBtn)
    {        
        for(int i = 0; i < categoryBtns.Length; i++)
        {
            if (thisBtn.name == categoryBtns[i].name)
            {
                activeCats[i] = !activeCats[i];
                if (activeCats[i])
                    categoryBtns[i].GetComponent<Image>().sprite = catWhiteBtns[i];
                else
                    categoryBtns[i].GetComponent<Image>().sprite = catBlackBtns[i];
            }              
        }
    }

    /// <summary>
    /// Swaps the sprites for category buttons and selects the categories you tip out on
    /// </summary>
    public void TOSelectSprtSwap(Button thisBtn)
    {
        Debug.Log("here");
        for (int i = 0; i < tipOutBtns.Length; i++)
        {
            if (thisBtn.name == tipOutBtns[i].name)
            {
                activeTOs[i] = !activeTOs[i];
                if (activeTOs[i])
                    thisBtn.GetComponent<Image>().sprite = toWhiteBtns[i];
                else
                    thisBtn.GetComponent<Image>().sprite = toBlackBtns[i];
            }
        }
    }

    /// <summary>
    /// Swaps the sprites for category buttons and enables or disables the category
    /// </summary>
    public void TOSpriteSwap(Button thisBtn)
    {
        for (int i = 0; i < tipOutBtns.Length; i++)
        {
            if (thisBtn.name == "TotSales")
            {
                if(!activeTOs[i])
                {
                    ResetTOBtns();
                }              
            }
            else if (activeTOs[3])
            {
                tipOutBtns[3].GetComponent<Image>().sprite = toBlackBtns[3];
                activeTOs[3] = false;
            }

            if (thisBtn.name == tipOutBtns[i].name)
            {
                activeTOs[i] = !activeTOs[i];
                if (activeTOs[i])
                    tipOutBtns[i].GetComponent<Image>().sprite = toWhiteBtns[i];
                else
                    tipOutBtns[i].GetComponent<Image>().sprite = toBlackBtns[i];
            }
        }
        //Debug.Log("activeTOs " + index + ": " + activeTOs[0] + ": " + activeTOs[1] + ": " + activeTOs[2] + ": " + activeTOs[3]);
    }
    
    /// <summary>
    /// Skips the tipout setup if user only tipouts on total sales
    /// </summary>
    public void TOContinue()
    {
        if (activeTOs[3])
            toOptionsPnls[5].SetActive(true);
        else
            toOptionsPnls[4].SetActive(true);
        ResetTOBtns();
    }

    /// <summary>
    /// Saves the selected input values, resets input buttons and opens next panel
    /// </summary>
    public void TONext()
    {
        if (index >= 4)
        {
            toOptionsPnls[5].SetActive(true);
            return;
        }
            
        // Store these tipout options to the current category 
        for (int i = 0; i < 4; i++)
        {
            catsTOs[index, i] = activeTOs[i];
        }
        ResetTOBtns();

        index++;
        InitNext();
    }

    /// <summary>
    /// Opens the next set of input options
    /// </summary>
    public void InitNext()
    {
        //Debug.Log("InitNext()" + index);
        for (int i = index; i < 4; i++)
        {
            index = i;
            if (activeCats[i])
            {
                toOptionsPnls[i].SetActive(true);
                salesBtnPnl.SetActive(true);

                //Debug.Log(index);
                return;
            }
        }

        if (index >= 3)
            toOptionsPnls[5].SetActive(true);
    }

    /// <summary>
    /// Finalize the values for each category
    /// </summary>
    public void PercentEdit(Text input)
    {      
        if (!float.TryParse(input.text, out percents[index]))
        {
            Debug.Log("Percent to float failed: percentBtns[index].text)");
        }        
    }

    /// <summary>
    /// Complete and save setup info
    /// </summary>
    public void SetupComplete()
    {
        Debug.Log("setup complete");
        GameManager.manager.WorkGroups = catsTOs;
        GameManager.manager.Percents = percents;
        GameManager.manager.SetupComplete = true;
        ProfileManager.manager.SaveNewProfileName();
    }
    #endregion

}

