﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;
using System;

[Serializable]
public class Day
{
    #region Public Variables
    public String notes;
	public String day = "Day";
	public String date = "Date";
	public String dateTime = "Date AM/PM";
	public float grossSales = 0;        
	public float ccTips = 0;            
	public float cashTips = 0;          
	public float wineSales= 0;          
	public float expenses = 0;          
	public float barPercent = 3.0f;     
	public float runPercent = 3.0f;       
	public float assistPercent = 3.0f;     
	public float otherPercent = 3.0f;      
	public float grossTips = 0;         
	public float barSales = 0;          
	public float foodSales = 0;         
    public float barTotal = 0;          
    public float runTotal = 0;          
	public float assistTotal = 0;       
    public float otherTotal = 0;        
	public float totalTipout = 0;       
	public float netTips = 0;           
	public float grossPercent = 0;      
	public float netPercent = 0;        
	public int myYear = 0;
	public int myMonth = 0;
	public int myDay = 0;
	public int amPm= 1;  // 0 for Am 1 for Pm
	public int runNum = 1;
	public int assistNum = 1;
    public int barNum = 1;
    public int somNum = 1;
    #endregion

    #region Private Variables
    private bool pm = true;
    private bool[] grpsActive = { false, false, false, false };     // 0-bar; 1-runner; 2-assistant; 3-other
    #endregion

    #region Properties
    public bool GetPM { get { return pm; } set { pm = value; } }

    public bool[] GrpsActive { get { return grpsActive; } set { grpsActive = value; } }

    public DateTime SetDay {
        set
        {
            day = value.DayOfWeek.ToString();
            date = value.ToString("MM/dd/yyyy");
            SetDatePM(pm);
            myYear = value.Year;
            myMonth = value.Month;
            myDay = value.Day;
        }
    }
    #endregion

    #region Public Methods and Constructors
    /// <summary>
    /// Default constructor creats a day with from todays date
    /// </summary>
    public Day()
	{
		notes = "";
		day = DateTime.Now.DayOfWeek.ToString();
		date = DateTime.Now.ToString("MM/dd/yyyy");
		dateTime = date + " PM";
		myYear = DateTime.Now.Year;
		myMonth = DateTime.Now.Month;
		myDay = DateTime.Now.Day;
	}

    /// <summary>
    /// Custom day constructor
    /// </summary>
	public Day(int newYear, int newMonth, int newDay)
	{
		notes = "";
		day = "Unknown";
		date = string.Format ("{0:D2}/{1:D2}/{2}", newMonth, newDay, newYear);
		dateTime = date;
		myYear = newYear;
		myMonth = newMonth;
		myDay = newDay;
	}

    /// <summary>
    /// Sets am or pm for the shift
    /// </summary>
	public void SetDatePM(bool isPM)
	{
		if(isPM)
		{
			pm = true;
			amPm = 1;
			dateTime = date + " PM";
		}
		else
		{
			pm = false;
			amPm = 0;
			dateTime = date + " AM";
		}
	}

    /// <summary>
    /// Sets up the ouput totals for the output panel
    /// </summary>
	public void SetOutput()
	{
        grossTips = cashTips + ccTips;
        totalTipout = barTotal + runTotal + assistTotal + otherTotal;
        netTips = grossTips - totalTipout - expenses;

        if (grossSales == 0)
        {
            grossPercent = 0;
            netPercent = 0;
        }
        else
        {
            grossPercent = grossTips / grossSales * 100f;
            netPercent = netTips / grossSales * 100f;
        }
    }

    #endregion
}
