/**
 * 
 */

function popupOn(num) { 			
    var popup = document.getElementById("popup" + num);	       
    popup.style.display = "block";
}

function popupOff(num) { 			
    var popup = document.getElementById("popup" + num);	       
    popup.style.display = "none";
}