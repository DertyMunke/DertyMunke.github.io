/**
 * Index functions
 */

// Turns the popup on
function popupOn() { 			
    var popup = document.getElementById("popup");	       
    popup.style.display = "block";
}

// Turns the popup off
function popupOff() { 			
    var popup = document.getElementById("popup");	       
    popup.style.display = "none";
}

//Browser Support Code
function ajaxFunction(){
	var ajaxRequest;  // The variable that makes Ajax possible!

	try{
		// Opera 8.0+, Firefox, Safari
		ajaxRequest = new XMLHttpRequest();
	} catch (e){
		// Internet Explorer Browsers
		try{
			ajaxRequest = new ActiveXObject("Msxml2.XMLHTTP");
		} catch (e) {
			try{
				ajaxRequest = new ActiveXObject("Microsoft.XMLHTTP");
			} catch (e){
				// Something went wrong
				alert("Your browser broke!");
				return false;
			}
		}
	}
	// Create a function that will receive data sent from the server
	ajaxRequest.onreadystatechange = function(){
		if(ajaxRequest.readyState == 4){
			var results= ajaxRequest.responseText.split(";=");
			var first = document.getElementById("a_alt1");
			var second = document.getElementById("a_alt2");
			var third = document.getElementById("a_alt3");
			first.innerHTML = results[0];
			first.href = "Browse?search=" + results[0];
			second.innerHTML = results[1];
			second.href = "Browse?search=" + results[1];
			third.innerHTML = results[2];
			third.href = "Browse?search=" + results[2];
		}
	}
	
	var getSearch = "AutoComplete?search=" + document.searchform.search.value + "&pseudoParam=" + new Date().getTime();
	ajaxRequest.open("GET", getSearch, true);
	ajaxRequest.send(null);
}