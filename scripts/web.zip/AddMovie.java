

import java.sql.*;
import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.WebServlet;
//import java.util.ArrayList;

import javax.naming.InitialContext;
import javax.naming.Context;
import javax.sql.DataSource;

/**
 * Servlet implementation class AddMovie
 */
@WebServlet("/AddMovie")
public class AddMovie extends HttpServlet {
	private static final long serialVersionUID = 1L;

	//@SuppressWarnings("unused")
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		
		response.setContentType("text/html"); // Response mime type

		// Output stream to STDOUT
		PrintWriter out = response.getWriter();
		
		out.println("addMovie ninja!");
        try
        {        	
        	Context initCtx = new InitialContext();
        	if (initCtx == null) out.println ("initCtx is NULL");
		   
        	Context envCtx = (Context) initCtx.lookup("java:comp/env");
        	if (envCtx == null) out.println ("envCtx is NULL");
			
        	// Look up our data source
        	DataSource ds = (DataSource) envCtx.lookup("jdbc/moviedb");
	       
			if (ds == null)
				   out.println ("ds is null.");
	      
			Connection dbcon = ds.getConnection();
			if (dbcon == null)
	          out.println ("dbcon is null.");
			  
			// Perform the query
			ServletContext sc = getServletContext();
			RequestDispatcher rd = sc.getRequestDispatcher("/_dashboard/options.jsp");
			  		
			// Get the parameters that were passed to query
			String title = request.getParameter("title");
			String year_string = request.getParameter("year");
			String director = request.getParameter("director");
			String banner_url = request.getParameter("banner_url");
			String trailer_url = request.getParameter("trailer_url");
			String first = request.getParameter("first");
			String last = request.getParameter("last");		
			String genre = request.getParameter("genre");
			
			// Declare our statement
			PreparedStatement cs = dbcon.prepareStatement("{CALL add_movie (?, ?, ?, ?, ?, ?, ?, ?)}");
			
			// If only one name is provided, make sure it's inserted into the last name attribute
			if(last == "" && first != "")
			{
				last = first;
				first = "";
			}
			
			// Double check the required fields
			if(title != "" && year_string != "" && director != "" && last != "" && genre != "")
			{
				try
				{
					int year = Integer.parseInt(year_string);
					cs.setString(1, title);
					cs.setInt(2, year);
					cs.setString(3, director);
					cs.setString(4, banner_url);
					cs.setString(5, trailer_url);
					cs.setString(6, first);
					cs.setString(7, last);
					cs.setString(8, genre);
					
					ResultSet rs = cs.executeQuery();
					String answer = "";
					while(rs.next())
					{
						answer = rs.getString("answer");
					}
					// Message from the procedure call
					request.setAttribute("result", answer);	
					rd.forward(request, response);
				}
				catch(NumberFormatException e)
				{
					// Year is not an integer error message
					request.setAttribute("result", "Error: Year should be a number.<br>Movie was <b>NOT</b> added to database.");	
					rd.forward(request, response);
				}
				
			}
			else
			{
				// Required fields error message
				request.setAttribute("result", "Error: Title, Year, Director, Star, and Genre are required.<br>Movie was <b>NOT</b> added to database.");	
				rd.forward(request, response);
			}
  
            cs.close();
            dbcon.close();
        }	
        catch (SQLException ex) {
            while (ex != null) {
                System.out.println ("SQL Exception:  " + ex.getMessage ());
                ex = ex.getNextException ();
            }  // end while
        }  // end catch SQLException
        catch(java.lang.Exception ex)
        {
            out.println("<HTML>" +
                        "<HEAD><TITLE>" +
                        "MovieDB: Error" +
                        "</TITLE></HEAD>\n<BODY>" +
                        "<P>SQL error in doGet: " +
                        ex.getMessage() + "</P></BODY></HTML>");
            return;
        }
        out.close();
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
