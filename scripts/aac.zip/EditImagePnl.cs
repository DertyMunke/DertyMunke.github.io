﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;

public class EditImagePnl : MonoBehaviour {

    #region Public Variables
    public GameObject btn;
    public Image btnImg;
    public Image editImg;
    #endregion

    #region Private Variables
    private Sprite editSprite;
    private Texture2D editTxtr2D;
    #endregion

    #region Unity Methods
    /// <summary>
    /// Stores initial values to be reset.
    /// </summary>
    private void Start()
    {
        editSprite = editImg.sprite;
        editTxtr2D = editSprite.texture;
    }
    #endregion

    #region Public Methods
    /// <summary>
    /// Rotates the image clockwise by default. Pass false for counter clockwise.
    /// </summary>
    public void RotateImg(bool right = true)
    {
        Debug.Log(editImg.rectTransform.rotation.z);
        if(right)
            editImg.rectTransform.Rotate(new Vector3(0, 0, -90));
        else
            editImg.rectTransform.Rotate(new Vector3(0, 0, 90));
    }

    /// <summary>
    /// Enlarge the image by default. Pass false to shrink image.
    /// </summary>
    public void ResizeImg(bool plus = true)
    {        
        if(plus)
            editImg.rectTransform.sizeDelta = new Vector2(editImg.rectTransform.sizeDelta.x * 1.1f, editImg.rectTransform.sizeDelta.y * 1.1f);
        else
            editImg.rectTransform.sizeDelta = new Vector2(editImg.rectTransform.sizeDelta.x / 1.1f, editImg.rectTransform.sizeDelta.y / 1.1f);
    }

    /// <summary>
    /// Saves the changes made to the image for the selected button.
    /// </summary>
    public void SaveImageEdit()
    {
        btnImg.rectTransform.rotation = editImg.rectTransform.rotation;
        btnImg.sprite = editImg.sprite;
        btnImg.rectTransform.sizeDelta = editImg.rectTransform.sizeDelta * 0.25f;
        btnImg.rectTransform.localPosition = editImg.rectTransform.localPosition * .25f;

        ButtonManager.buttonManagerScript.DoneImageEdit();
    }

    /// <summary>
    /// Resets the image to its default state.
    /// </summary>
    public void ResetImg()
    {
        editImg.rectTransform.sizeDelta = new Vector2(400, 400);
        editImg.rectTransform.rotation = Quaternion.Euler(Vector2.zero);
    }

    /// <summary>
    /// Increases the image size from the edit image button to the larger edit image panel.
    /// </summary>
    public void EditImageBtn()
    {
        editImg.rectTransform.rotation = btnImg.rectTransform.rotation;
        editImg.sprite = btnImg.sprite;
        editImg.rectTransform.sizeDelta = btnImg.rectTransform.sizeDelta * 4;
        editImg.rectTransform.localPosition = btnImg.rectTransform.localPosition * 4;
    }
    #endregion
}
