﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;

public class GalleryAccess : MonoBehaviour {
    #region Public Variables
    public GameObject cropImgObj;
    #endregion

    #region Private Variables
    private Image thisBtnImg;
    #endregion

    #region Public Methods
    /// <summary>
    /// Accesses the image gallery on the current device.
    /// </summary>
    public void GotoGallery(Image btn)
    {
        thisBtnImg = btn;
        AndroidCamera.Instance.OnImagePicked += OnImagePicked;
        AndroidCamera.Instance.GetImageFromGallery();
    }
    #endregion

    #region Private Methods
    /// <summary>
    /// The selected image is converted to a sprite and applied to the currently selected button.
    /// </summary>
    private void OnImagePicked(AndroidImagePickResult result)
    {
        Debug.Log("OnImagePicked");
        if (result.IsSucceeded)
        {
            Texture2D img = result.Image;
            cropImgObj.GetComponent<Renderer>().material.mainTexture = result.Image;
            thisBtnImg.sprite = Sprite.Create(img, new Rect(0, 0, img.width, img.height), new Vector2(.5f, .5f));
            thisBtnImg.GetComponentInChildren<Text>().text = "";
            //AN_PoupsProxy.showMessage("Image Pick Rsult", "Succeeded, path: " + result.ImagePath)
        }
        else
        {
            AN_PoupsProxy.showMessage("Image Pick Rsult", "Failed");
        }

        AndroidCamera.Instance.OnImagePicked -= OnImagePicked;
    }
    #endregion
}
