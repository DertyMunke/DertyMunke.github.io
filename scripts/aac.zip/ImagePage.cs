﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;

public class ImagePage : MonoBehaviour {

    #region Public Variables
    public GameObject[] imgBtns { get { return ImageBtns; } }
    public GameObject[] ImageBtns;
    public float btnSize = 1;
    #endregion

    #region Public Methods
    /// <summary>
    /// When edit mode is enables all buttons are enabled, so they are selectable for edit
    /// </summary>
    public void EnableAll()
    {
        Debug.Log(gameObject.name);
        foreach(GameObject btn in ImageBtns)
        {
            if (btn.GetComponent<ButtonBrain>().Hide)
            {
                btn.GetComponent<Image>().enabled = true;
                btn.GetComponent<ButtonBrain>().MyButton.gameObject.SetActive(true);
            }   
        }
    }

    /// <summary>
    /// When edit mode is over then revert button values
    /// </summary>
    public void SetValuesToCurrent()
    {
        foreach (GameObject btn in ImageBtns)
        {
            if(btn.GetComponent<ButtonBrain>().Hide)
            {
                btn.GetComponent<Image>().enabled = false;
                btn.GetComponent<ButtonBrain>().MyButton.gameObject.SetActive(false);
            }
        }
    }
    #endregion
}
