﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;
using System;
using System.Runtime.Serialization.Formatters.Binary;


public class ButtonBrain : MonoBehaviour {
    #region Public Variables
    public Image myImage;
    public string myImagePath = "";
    #endregion

    #region Private Variables
    private ButtonData myBtnData = new ButtonData();
    private Button myButton;
    private Color myColor;
    private string myText = "Button";
    private string myAudio = "";
    private bool hide = false;
    private bool noAction = false;
    private bool playWord = false;
    private bool opensWindow = false;
    private bool myAudioSet = false;
    private bool homeBtnEnabled = false;
    private int myPnlIndex = 0;
    private int myChildPnlIndex = -1;
    private int myBtnIndex = 0;
    private int myZoom = 0;
    private int myImageIndex = 0;
    private int myImageType = 0; // 0 = None; 1 = Included; 2 = Saved;
    #endregion

    #region Properties
    /// <summary>
    /// Gets and sets the image type associated with this button.
    /// </summary>
    public int MyImageType { get { return myImageType; } set { myImageType = value; } }

    /// <summary>
    /// Gets and sets the image size needed to fit this buttons size.
    /// </summary>
    public Vector2 MyImgSize { get { return myImage.rectTransform.sizeDelta; } set { myImage.rectTransform.sizeDelta = value; } }

    /// <summary>
    /// Gets and sets the position of the image on this button.
    /// </summary>
    public Vector3 MyImgPos { get { return myImage.rectTransform.localPosition; } set { myImage.rectTransform.localPosition = value; } }

    /// <summary>
    /// Gets the button object.
    /// </summary>
    public Button MyButton { get { return myButton; } }

    /// <summary>
    /// Gets and sets the sprite on the button image component.
    /// </summary>
    public Sprite MySprite { get { return myImage.sprite; } set{ myImage.sprite = value; } }

    /// <summary>
    /// Gets the image component of this button.
    /// </summary>
    public Image MyImage { get { return myImage; } }

    /// <summary>
    /// Gets and sets the text value of the text component.
    /// </summary>
    public string MyText { get { return myText; }
        set
        {
            myText = value;
            GetComponentInChildren<Text>().text = myText;
        }
    }

    /// <summary>
    /// Gets and sets the recorded audio for this button.
    /// </summary>
    public string MyAudio { get { return myAudio; }
        set {
            myAudioSet = true;
            playWord = true;
            myAudio = value;
        }
    }

    /// <summary>
    /// Gets and sets the color for this button.
    /// </summary>
    public Color MyColor{ get { return myColor; }
        set{
            myColor = value;
            GetComponent<Image>().color = myColor;
        }
    }

    /// <summary>
    /// Get returns true if the button is set to hidden.
    /// Set toggles the hide feature on or off. 
    /// </summary>
    public bool Hide { get { return hide; }
        set {
            hide = value;
            if (!myButton)
                myButton = GetComponentInChildren<Button>();
            myButton.gameObject.SetActive(!hide);
            GetComponent<Image>().enabled = !hide;
            if (hide)
                myImage.color = new Color(1, 1, 1, 0.5f);
            else
                myImage.GetComponent<Image>().color = new Color(1, 1, 1, 1);
                
        }
    }

    /// <summary>
    /// Get returns true if the button features are active.
    /// Set toggles the button features on or off.
    /// </summary>
    public bool NoAction { get { return noAction; } set { noAction = value; } }

    /// <summary>
    /// Returns true if this buttons audio has been set.
    /// </summary>
    public bool MyAudioSet { get { return myAudioSet; } }

    /// <summary>
    /// Get and set true value enables the audio clip for the button to play.
    /// </summary>
    public bool PlayWord  { get { return playWord; } set { playWord = value; } }

    /// <summary>
    /// Get and set true value enables the button to open a new panel of buttons.
    /// </summary>
    public bool OpenWindow { get { return opensWindow; } set { opensWindow = value; } }

    /// <summary>
    /// Get and set true value enables a home button on the nested button panel from this button.
    /// </summary>
    public bool HomeBtn { get { return homeBtnEnabled; } set { homeBtnEnabled = value; } }

    /// <summary>
    /// Get and set the rotation of the image from the edit image settings.
    /// </summary>
    public Quaternion MyRotation { get { return myImage.rectTransform.rotation; }
        set { myImage.rectTransform.rotation = value; } }

    /// <summary>
    /// Gets and sets the index of this panel in the list of panels.
    /// </summary>
    public int MyPnlInx { get { return myPnlIndex; } set { myPnlIndex = value; } }

    /// <summary>
    /// Gets and sets the index of this buttons nested button panel in the list of panels.
    /// </summary>
    public int MyChildPnlInx { get { return myChildPnlIndex; } set { myChildPnlIndex = value; } }

    /// <summary>
    /// Gets and sets the index of this button on its button panel.
    /// </summary>
    public int MyBtnInx { get { return myBtnIndex; } set { myBtnIndex = value; } }

    /// <summary>
    /// Gets and sets the index of this buttons image in the list of saved images.
    /// </summary>
    public int MyImgInx { get { return myImageIndex; } set { myImageIndex = value; } }

    /// <summary>
    /// Gets and sets the type of image associated with this button.
    /// 0 = None; 1 = Included; 2 = Saved;
    /// </summary>
    public int MyImgType { get { return myImageType; } set { myImageType = value; } }

    /// <summary>
    /// Gets and sets zoom property from the image edit options.
    /// </summary>
    public int MyZoom { get { return myZoom; } set { myZoom = value; } }
    #endregion

    #region Unity Methods
    /// <summary>
    /// Captures initial button values
    /// </summary>
    private void Awake()
    {
        myColor = GetComponent<Image>().color;
        myButton = GetComponentInChildren<Button>();
    }
    #endregion

    #region Public Methods
    /// <summary>
    /// Sets the button to be edited to this button when pressed in edit mode
    /// </summary>
    public void MyButtonPressed()
    {
        ButtonManager.buttonManagerScript.ImageBtn(gameObject);
    }
    #endregion
}


