﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;
using System.Linq;
using System.Collections.Generic;
using UnityEngine.SceneManagement;

public class ButtonManager : MonoBehaviour {

    /// <summary>
    /// Indexing of the available actions
    /// </summary>
    private enum actions
    {
        none,
        text,
        sound,
        txtSound,
        page,
        txtPage,
        soundPage,
        txtSoundPage, 
        editBtn,
        editPnl
    }

    #region Public Variables
    public static ButtonManager buttonManagerScript;
    public GameObject cropImgObj;
    public GameObject ImgPnlHolder;
    public GameObject editPnl;
    public GameObject playPnl;
    public GameObject[] ImagePnlPrefabs;
    public GameObject passwordPnl;
    public GameObject pswrdContPnl;
    public GameObject editBtnExample;
    public GameObject editTopPnl;
    public GameObject editTopBackBtn;
    public GameObject homeBtn;
    public GameObject homeBtnEnableToggle;
    public GameObject editNextWindowBtn;
    public GameObject audioSelectPnl;
    public GameObject audioSavePnl;
    public AudioSource audioPlayer;
    public InputField buttonTxt;
    public InputField audioNameInput;
    public Image editBtnImg;
	public Sprite errorSprite;
    public Button record;
    public Button stop;
    public Button play;
    public Button delete;
    public Button saveAudio;
    public Button savePnlEnable;
    public Button selectAudioContinue;
    public Button editImage;
    public Dropdown audioDropdown;
    public Toggle hide;
    public Toggle action;
    public Toggle words;
    public Toggle open;
    public Toggle home; 
    public Text[] pswrdText;
    public Text[] pswrdText2;
    public Text spokenTxt;
    public Text audioActionTxt;
    public Text editTopPnlTitle;
    #endregion

    #region Private Variables
    private Dictionary<int, GameObject> imagePnls = new Dictionary<int, GameObject>();
    private Dictionary<string, AudioClip> audioTracks = new Dictionary<string, AudioClip>();
    private List<GameObject> activePnls = new List<GameObject>();
    private List<GameObject> currentBtns = new List<GameObject>();
    private List<actions> actionsList = new List<actions>();
    private List<string> spokenAudioStrings = new List<string>();
    private List<string> spokenTextStrings = new List<string>();
    private GameObject currentImagePnl;
    private GameObject homeImagePnl;
    private GameObject currentBtn;
    private Color defaultColor;
    private Sprite defaultImage;
    private string defaultText;
    private string[] password = { "1", "2", "3", "4" };
    private bool editEnabled = false;
    private bool changePassword = false;
    private bool noAction = false;
    private bool goingBack = false;
    private float recordLength = 0;
    private int passwordIndex = 0;
    private int imgPnlIndex = 0;
    #endregion

    #region Properties
    /// <summary>
    /// Sets the dictionary of audio clips and adds all of the clips to the dropdown box for button editing.
    /// </summary>
    public Dictionary<string, AudioClip> MyAudioTracks {
        set
        {
            audioTracks = value;
            foreach(string s in audioTracks.Keys)
            {
                Dropdown.OptionData newDD = new Dropdown.OptionData() { text = s };
                audioDropdown.options.Add(newDD);
            }           
        }
    }
    #endregion

    #region Unity Methods
    /// <summary>
    /// Stores the initial values of the edit button.
    /// </summary>
    private void Awake()
    {
        buttonManagerScript = this;
        defaultColor = editBtnExample.GetComponent<Image>().color;
        defaultImage = editBtnExample.GetComponentInChildren<Button>().GetComponent<Image>().sprite;
        defaultText = editBtnExample.GetComponentInChildren<Text>().text;
    }

    /// <summary>
    /// Initializes the current image panel
    /// </summary>
    private void Start()
    {
        currentImagePnl = homeImagePnl;
    }
    #endregion
    
    #region Audio Methods
    /// <summary>
    /// Plays the selected words as a sentence.
    /// </summary>
    public void PlayWordlist()
    {
        //StartCoroutine(PlayWords());

        List<float[]> trackData = new List<float[]>();
        int numFloats = 0;

        foreach (string s in spokenAudioStrings)
        {
            float[] samples = new float[audioTracks[s].samples * audioTracks[s].channels];
            audioTracks[s].GetData(samples, 0);
            numFloats += samples.Length;
            trackData.Add(samples);

            //yield return new WaitForSeconds(audioPlayer.clip.length + 0.2f);
        }

        float[] finalClip = new float[numFloats];
        int index = 0;

        foreach(float[] track in trackData)
        {
            if (index < numFloats)
            {
                for (int i = 0; i < track.Length; i++)
                    finalClip[index++] = track[i];
            }
            else
                Debug.Log("audio index error");
        }

        audioPlayer.clip = AudioClip.Create("RecordedSound", finalClip.Length, 1, 44100, false, false);
        audioPlayer.clip.SetData(finalClip, 0);
        audioPlayer.Play();
    }

    /// <summary>
    /// Start recording a new track.
    /// </summary>
    public void RecordBtn()
    {
        audioDropdown.value = 0; // Set the dropdown to default value
        audioActionTxt.text = "Recording...";
        audioActionTxt.enabled = true;
        audioPlayer.clip = Microphone.Start("Built-in Microphone", false, 10, 44100);
        recordLength = Time.time;
  
        stop.interactable = true;
        play.interactable = false;
        delete.interactable = false;
        savePnlEnable.interactable = false;
        audioDropdown.value = 0;
    }

    /// <summary>
    /// Stops any running audio action.
    /// </summary>
    public void Stop()
    {
        if (Microphone.IsRecording("Built-in Microphone"))
        {
            recordLength = Time.time - recordLength;
            Microphone.End("Built-in Microphone");
            AudioClip ac = audioPlayer.clip;
            float lengthL = ac.length;
            float samplesL = ac.samples;
            float samplesPerSec = (float)samplesL / lengthL;
            float[] samples = new float[(int)(samplesPerSec * recordLength)];
            ac.GetData(samples, 0);

            audioPlayer.clip = AudioClip.Create("RecordedSound", (int)(recordLength * samplesPerSec), 1, 44100, false, false);
            audioPlayer.clip.SetData(samples, 0);
            play.interactable = true;
            savePnlEnable.interactable = true;
        }            

        if (audioPlayer.isPlaying)
            audioPlayer.Stop();

        audioActionTxt.text = "Stopped";
        Invoke("AudioTextTimer", 0.5f);
    }

    /// <summary>
    /// Plays the currently selected or recently recorded track.
    /// </summary>
    public void Play()
    {
        if (audioPlayer.clip.loadState == AudioDataLoadState.Loaded)
        {
            Invoke("AudioTextTimer", audioPlayer.clip.length);
            audioPlayer.Play();
            audioActionTxt.text = "Playing...";
            audioActionTxt.enabled = true;
        }  
    }

    /// <summary>
    /// Adds the currently selected audio file to the currently selected button.
    /// </summary>
    public void AddAudio(bool cancel = false)
    {
        if(!cancel)
        {
            if(audioDropdown.value != 0)
            {
                currentBtn.GetComponent<ButtonBrain>().MyAudio = audioDropdown.captionText.text;
                words.interactable = true;
                words.isOn = true;
            }
            else
            {
                audioActionTxt.text = "No Audio Selected";
                Invoke("AudioTextTimer", 0.5f);
                return;
            }
        }

        audioSelectPnl.SetActive(false);
    }

    /// <summary>
    /// Saves the recorded audio to file.
    /// </summary>
    public void SaveAudio(bool cancel = false)
    {
        if(!cancel && audioNameInput.text.ToString() != "No Track Selected")
        {
            currentBtn.GetComponent<ButtonBrain>().MyAudio = audioNameInput.text.ToString();
            SaveLoad.saveLoadScript.UpdateButtonData(currentBtn.GetComponent<ButtonBrain>());

            audioTracks.Add(audioNameInput.text.ToString(), audioPlayer.clip);
            Dropdown.OptionData newDD = new Dropdown.OptionData() { text = audioNameInput.text };
            audioDropdown.options.Add(newDD);
            audioDropdown.value = audioDropdown.options.Count;

            SaveLoad.saveLoadScript.SaveNewTrack(audioNameInput.text.ToString(), audioPlayer.clip);
        }
        audioNameInput.text = "";
    }

    /// <summary>
    /// Deletes the currently selected audio.
    /// </summary>
    public void DeleteAudioBtn()
    {
        if (audioDropdown.value != 0)
        {
            audioTracks.Remove(audioNameInput.text.ToString());
            audioDropdown.options.RemoveAt(audioDropdown.value);
            audioDropdown.value = 0;
        }
        else
            delete.interactable = false;
    }

    /// <summary>
    /// Select a track from the dropdown box.
    /// </summary>
    public void SelectTrackDropdown()
    {
        if (audioTracks.ContainsKey(audioDropdown.captionText.text.ToString()))
        {
            audioPlayer.clip = audioTracks[audioDropdown.captionText.text];
            delete.interactable = true;
            play.interactable = true;
            selectAudioContinue.interactable = true;
            saveAudio.interactable = false;
        }
        else
        {
            delete.interactable = false;
            play.interactable = false;
            selectAudioContinue.interactable = false;
        }            
    }

    /// <summary>
    /// Use with invoke to allow the action text to turn off after a certain amount of time.
    /// </summary>
    private void AudioTextTimer()
    {
        audioActionTxt.text = "";
        audioActionTxt.enabled = false;
    }

    #endregion
    
    #region Edit Page Methods

    /// <summary>
    /// Searches for images in the phone
    /// </summary>
    public void SelectImage()
    {
		#if UNITY_IOS
		IOSCamera.OnImagePicked += OnImage;
		IOSCamera.Instance.PickImage(ISN_ImageSource.Library);

		#else
        AndroidCamera.Instance.OnImagePicked += OnImagePicked;
        AndroidCamera.Instance.GetImageFromGallery();
		#endif
    }

    /// <summary>
    /// Sets the current button and the example buttons background color to the selected color.
    /// </summary>
    public void ColorPicker(Image color)
    {
        currentBtn.GetComponent<ButtonBrain>().MyColor = color.color;
        currentBtn.GetComponent<Image>().color = color.color;
        editBtnExample.GetComponent<Image>().color = color.color;
    }

    /// <summary>
    /// Changes the text on the example button and the selected button.
    /// </summary>
    public void EditTextOnSubmit(Text newTxt)
    {
        editBtnExample.GetComponentInChildren<Text>().text = newTxt.text;
        //currentBtn.GetComponentInChildren<Text>().text = newTxt.text;
        currentBtn.GetComponent<ButtonBrain>().MyText = newTxt.text;
    }

    /// <summary>
    /// Opens the input field to change the text on the currently selected button.
    /// </summary>
    public void ChangeText()
    {
        buttonTxt.ActivateInputField();
    }

    /// <summary>
    /// Hides the currently selected button.
    /// </summary>
    public void Hide(Toggle value)
    {
        currentBtn.GetComponent<ButtonBrain>().Hide = value.isOn;
        action.interactable = !value.isOn;
        words.interactable = !value.isOn;
        open.interactable = !value.isOn;
        home.interactable = !value.isOn;
        editNextWindowBtn.GetComponentInChildren<Button>().interactable = !value.isOn;
    }

    /// <summary>
    /// Enables or disables audio and text actions.
    /// </summary>
    public void NoAction(Toggle value)
    {
        currentBtn.GetComponent<ButtonBrain>().NoAction = value.isOn;
    }

    /// <summary>
    /// Allows the current buttons audio to play when the button is pressed.
    /// </summary>
    public void PlayWord(Toggle value)
    {
        currentBtn.GetComponent<ButtonBrain>().PlayWord = value.isOn;
    }

    /// <summary>
    /// Enables the button to open a new ImagePage and creates one for the button if it doesn't have one.
    /// </summary>
    public void OpenWindowEnabled(Toggle value )
    {
        if(value.isOn)
        {
            ButtonBrain brain = currentBtn.GetComponent<ButtonBrain>();
            brain.OpenWindow = true;

            // If the button doesn't have a child ImagePage, then create one
            Debug.Log(brain.MyChildPnlInx);
            if (brain.MyChildPnlInx <= 0)
            {
                SaveLoad.saveLoadScript.CreateNewPnl(brain, false);
                SaveLoad.saveLoadScript.Save();
            }
                
            homeBtnEnableToggle.SetActive(true);
            editNextWindowBtn.SetActive(true);
        }
        else
        {
            currentBtn.GetComponent<ButtonBrain>().OpenWindow = false;
            homeBtnEnableToggle.SetActive(false);
            editNextWindowBtn.SetActive(false);
        }
    }

    /// <summary>
    /// Saves the current buttons choice on allowing its child ImagePage to have a home button.
    /// </summary>
    public void HomeBtnEnabled(Toggle value)
    {
        currentBtn.GetComponent<ButtonBrain>().HomeBtn = value.isOn;
    }

    /// <summary>
    /// After successful password, allows the user to select a button to edit.
    /// </summary>
    public void ContinueBtn()
    {
        editTopPnl.SetActive(true);
        editTopPnlTitle.GetComponent<Text>().text = "Select A Button To Edit";
        currentImagePnl.GetComponent<ImagePage>().EnableAll();
        pswrdContPnl.SetActive(false);
        passwordPnl.SetActive(false);
        ResetLists();
    }

    /// <summary>
    /// Enables change password or resets the password when true is passed.
    /// </summary>
    public void ChangePassword(bool reset = false)
    {
        passwordIndex = 0;
        // Reset the password to default
        if(reset)
        {
            for (int i = 1; i <= password.Length; i++)
            {
                password[i - 1] = i.ToString();
                pswrdText[i - 1].text = i.ToString();
                pswrdText2[i - 1].text = i.ToString();
            }
                
        }
        // Enable change password
        else
        {
            changePassword = true;
            pswrdContPnl.SetActive(false);
        }
            
    }

    /// <summary>
    /// Determines if the user enters the correct password.
    /// </summary>
    public void PasswordBtn(Button pressed)
    {
        // Entering new password
        if (editEnabled && changePassword)
        {
            int btnName;
            int.TryParse(pressed.name, out btnName);

            // Only allow the four corners to be part of the password
            if(pressed.name != "0")
                if(passwordIndex < 3)
                {
                    password[passwordIndex] = pressed.name;
                    pswrdText[btnName - 1].text = (passwordIndex + 1).ToString();
                    pswrdText2[btnName - 1].text = (passwordIndex + 1).ToString();
                    passwordIndex++;
                }
                else
                {
                    password[passwordIndex] = pressed.name;
                    pswrdText[btnName - 1].text = (passwordIndex + 1).ToString();
                    pswrdText2[btnName - 1].text = (passwordIndex + 1).ToString();
                    passwordIndex = 0;
                    pswrdContPnl.SetActive(true);
                    changePassword = false;
                }
        }
        // Entering current password
        else if (pressed.name == password[passwordIndex])
        {
            passwordIndex++;
            if (passwordIndex == 4)
            {
                editEnabled = true;
                pswrdContPnl.SetActive(true);
                passwordIndex = 0;
            }
        }
        else
        {
            passwordPnl.SetActive(false);
            passwordIndex = 0;
        }
            
    }

    /// <summary>
    /// Home button functionality.
    /// </summary>
    public void HomeBtn()
    {
        SaveLoad.saveLoadScript.UpdateButtonData(currentBtn.GetComponent<ButtonBrain>());

        if (currentImagePnl)
            currentImagePnl.SetActive(false);

        currentImagePnl = homeImagePnl;
        currentImagePnl.SetActive(true);
        homeBtn.SetActive(false);
        ResetLists();
    }

    /// <summary>
    /// Done button functionality.
    /// </summary>
    public void DoneBtn()
    {
        editTopBackBtn.SetActive(false);
        changePassword = false;
        editEnabled = false;
        playPnl.SetActive(true);
        currentImagePnl.SetActive(false);
        editPnl.SetActive(false);
        editTopPnl.SetActive(false);
        currentImagePnl = homeImagePnl;
        currentImagePnl.SetActive(true);
        currentImagePnl.GetComponent<ImagePage>().SetValuesToCurrent();
        ResetLists();
        SaveLoad.saveLoadScript.HomePnl = currentImagePnl;
        SaveLoad.saveLoadScript.UpdateButtonData(currentBtn.GetComponent<ButtonBrain>());
    }

    /// <summary>
    /// Edit button functionality.
    /// </summary>
    public void EditBtn()
    {
        passwordIndex = 0;
        passwordPnl.SetActive(true);
    }

    /// <summary>
    /// When the edit button is pressed, immulate the press of the actual image button.
    /// </summary>
    public void ImageBtnEdit()
    {
        ButtonBrain brain = currentBtn.GetComponent<ButtonBrain>();

        if (brain.PlayWord)
        {
            if (brain.MyAudioSet)
            {
                audioPlayer.Play();
            }
        }

        if (brain.OpenWindow)
        {
            currentImagePnl.SetActive(false);
            //if (brain.MyChildPnlInx < 0)
            //    brain.ChildImagePnl = SaveLoad.saveLoadScript.MyPnls[brain.MyChildPnlInx];

            SaveLoad.saveLoadScript.UpdateButtonData(brain);

            currentImagePnl = SaveLoad.saveLoadScript.MyPnls[brain.MyChildPnlInx];
            currentImagePnl.SetActive(true);
            currentImagePnl.GetComponent<ImagePage>().EnableAll();

            currentBtns.Add(currentBtn);
            editPnl.SetActive(false);
            actionsList.Add(actions.editPnl);
        }
    }

    /// <summary>
    /// Image button functionality.
    /// </summary>
    public void ImageBtn(GameObject pressed)
    {
        ButtonBrain brain = pressed.GetComponent<ButtonBrain>();
        //Debug.Log(currentBtn.name);

        if (editEnabled)
        {
            editTopPnlTitle.GetComponent<Text>().text = "Edit Panel";
            editTopBackBtn.SetActive(true);

            // Returns the buttons on the current image page to their edited state 
            currentImagePnl.GetComponent<ImagePage>().SetValuesToCurrent();
            if (!goingBack)
            {
                actionsList.Add(actions.editBtn);
                activePnls.Add(currentImagePnl);
            }
            else
                goingBack = false;
            
            spokenTxt.text = "";

            // Change the edit button if its different from the previous button
            if(currentBtn != pressed)
            {
                currentBtn = pressed;
                currentBtns.Add(currentBtn);
                if (brain.MyAudioSet)
                {
                    audioPlayer.clip = audioTracks[brain.MyAudio];
                    words.isOn = true;

                    if (brain.PlayWord)
                        words.interactable = true;
                    else
                        words.interactable = false;
                }
                else
                {
                    words.isOn = false;
                    words.interactable = false;
                }
              
                editImage.interactable = brain.MyImgType != 0 ? true : false;  
                 
                hide.isOn = brain.Hide;
                action.isOn = brain.NoAction;
                open.isOn = brain.OpenWindow;
                words.interactable = brain.PlayWord;
                words.isOn = brain.MyAudioSet;

                if (open.isOn)
                {
                    homeBtnEnableToggle.SetActive(true);
                    editNextWindowBtn.SetActive(true);
                }
                else
                {
                    homeBtnEnableToggle.SetActive(false);
                    editNextWindowBtn.SetActive(false);
                }

                // Set the edit button to look like the selected button
                editBtnImg.rectTransform.rotation = brain.MyImage.rectTransform.rotation;
                editBtnImg.sprite = brain.MyImage.sprite;

                editBtnImg.rectTransform.sizeDelta = brain.MyImage.rectTransform.sizeDelta * (4f / (SaveLoad.saveLoadScript.BtnSize + 1));
                editBtnImg.rectTransform.localPosition = brain.MyImage.rectTransform.localPosition * (4f / (SaveLoad.saveLoadScript.BtnSize + 1));

                editBtnExample.GetComponentInChildren<Text>().text = brain.MyText;
                //editBtnExample.GetComponentInChildren<Text>().enabled = brain.PlayWord;
                editBtnExample.GetComponent<Image>().color = brain.MyColor;
            }

            currentImagePnl.SetActive(false);
            playPnl.SetActive(false);
            editPnl.SetActive(true);
            editTopPnl.SetActive(true);
        }
        else
        {
            actions myAction = actions.none;
            if(!brain.NoAction)
            {
                if (brain.MyText != "")
                {
                    spokenTxt.text += brain.MyText + " ";
                    spokenTextStrings.Add(brain.MyText);
                    myAction = actions.text;
                }

                if (brain.MyAudioSet)
                {
                    if(audioPlayer.clip != audioTracks[brain.MyAudio])
                        audioPlayer.clip = audioTracks[brain.MyAudio];
                    if (brain.PlayWord)
                        audioPlayer.Play();

                    spokenAudioStrings.Add(brain.MyAudio);

                    if (myAction == actions.text)
                        myAction = actions.txtSound;
                    else
                        myAction = actions.sound;
                }
  
            }

            if (brain.OpenWindow)
            {

                if (brain.HomeBtn)
                    homeBtn.SetActive(true);
                currentBtns.Add(pressed);
                currentImagePnl.SetActive(false);
                currentImagePnl = SaveLoad.saveLoadScript.MyPnls[brain.MyChildPnlInx];
                currentImagePnl.SetActive(true);
                activePnls.Add(currentImagePnl);

                if (myAction == actions.text)
                    myAction = actions.txtPage;
                else if (myAction == actions.sound)
                    myAction = actions.soundPage;
                else if (myAction == actions.txtSound)
                    myAction = actions.txtSoundPage;
                else
                    myAction = actions.page;
            }

            if (myAction != actions.none)
                actionsList.Add(myAction);
        }
   

        currentBtn = pressed;
    }

    /// <summary>
    /// The back arrow button removes the last pressed button action.
    /// </summary>
    public void BackBtn(bool save = false)
    {
        if(save)
            SaveLoad.saveLoadScript.UpdateButtonData(currentBtn.GetComponent<ButtonBrain>());

        actions myAction = actions.none;

        if (actionsList.Count > 0)
        {
            myAction = actionsList.Last();
            actionsList.RemoveAt(actionsList.Count - 1);
        }

        if (myAction == actions.text || myAction == actions.txtSound || myAction == actions.txtPage || myAction == actions.txtSoundPage)
        {
            if (spokenTextStrings.Count > 0)
                spokenTextStrings.RemoveAt(spokenTextStrings.Count - 1);

            spokenTxt.text = "";
            foreach (string s in spokenTextStrings)
                spokenTxt.text += s + " ";
        }

        if (myAction == actions.sound || myAction == actions.txtSound || myAction == actions.soundPage || myAction == actions.txtSoundPage)
        {
            if (spokenAudioStrings.Count > 0)
                spokenAudioStrings.RemoveAt(spokenAudioStrings.Count - 1);
        }

        if (myAction == actions.page || myAction == actions.txtPage || myAction == actions.soundPage || myAction == actions.txtSoundPage)
        {
            if(activePnls.Count > 0)
            {
                activePnls.Last().SetActive(false);
                activePnls.RemoveAt(activePnls.Count - 1);
                if (activePnls.Count > 0)
                {
                    activePnls.Last().SetActive(true);
                    currentImagePnl = activePnls.Last();
                }
                else
                {
                    homeImagePnl.SetActive(true);
                    currentImagePnl = homeImagePnl;
                }
            }
        }

        if(myAction == actions.editBtn)
        {
            if(activePnls.Count > 0)
            {
                currentImagePnl = activePnls.Last();
                activePnls.RemoveAt(activePnls.Count - 1);
                currentImagePnl.SetActive(true);
                currentImagePnl.GetComponent<ImagePage>().EnableAll();
                editPnl.SetActive(false);
            }

            if (activePnls.Count == 0)
                editTopBackBtn.SetActive(false);
            
        }

        if(myAction == actions.editPnl)
        {
            if(currentBtns.Count > 0)
            {
                currentImagePnl.GetComponent<ImagePage>().SetValuesToCurrent();
                goingBack = true;
                ImageBtn(currentBtns.Last());
                currentBtns.RemoveAt(currentBtns.Count - 1);
            }      
        }
    }

    /// <summary>
    /// Saves edited button image details to currently selected button.
    /// </summary>
    public void DoneImageEdit()
    {
        ButtonBrain brain = currentBtn.GetComponent<ButtonBrain>();

        brain.MyRotation = editBtnImg.rectTransform.rotation;
        brain.MySprite = editBtnImg.sprite;
        brain.MyImgSize = editBtnImg.rectTransform.sizeDelta * ((SaveLoad.saveLoadScript.BtnSize + 1) / 4f);
        brain.MyImgPos = editBtnImg.rectTransform.localPosition * ((SaveLoad.saveLoadScript.BtnSize + 1) / 4f);

        SaveLoad.saveLoadScript.Save();
    }

    /// <summary>
    /// Set the home image panel and the index for future panels.
    /// </summary>
    public void SetLoadedValues(GameObject hmPnl, int index)
    {
        imgPnlIndex = index;

        homeImagePnl = (GameObject)(Instantiate(ImagePnlPrefabs[imgPnlIndex], ImagePnlPrefabs[imgPnlIndex].transform.position,
            Quaternion.identity));
        homeImagePnl.transform.SetParent(ImgPnlHolder.transform, false);
      
        if (hmPnl)
        {
            homeImagePnl = hmPnl;
            //homeImgPnls[imgPnlIndex] = homeImagePnl;
        } 
        currentImagePnl = homeImagePnl;   
    }

    /// <summary>
    /// Creates a new panel and returns an array of the panels buttons.
    /// </summary>
    public GameObject InitImgPnl(int _index)
    {
        GameObject newpnl = (GameObject)(Instantiate(ImagePnlPrefabs[_index], ImagePnlPrefabs[_index].transform.position,
            Quaternion.identity));
        newpnl.transform.SetParent(ImgPnlHolder.transform, false);
        return newpnl;
    }

    /// <summary>
    /// Starts the app over from the beginning.
    /// </summary>
    public void ExitBtn()
    {
        SceneManager.LoadScene(0);
    }

    /// <summary>
    /// When the game is first loaded set the base image panel as the home and current panel.
    /// </summary>
    public void InitCurrHomePnl(GameObject pnl)
    {
        currentImagePnl = pnl;
        homeImagePnl = pnl;
    }

    #endregion

    #region Private Methods
    /// <summary>
    /// Plays the list of selected words in a single sentance.
    /// </summary>
    private IEnumerator PlayWords()
    {
        foreach(string s in spokenAudioStrings)
        {
            audioPlayer.clip = audioTracks[s];
            audioPlayer.Play();
            yield return new WaitForSeconds(audioPlayer.clip.length + 0.2f);
        }
        yield return null;
    }

    /// <summary>
    /// Resets the record of used buttons.
    /// </summary>
    private void ResetLists()
    {
        activePnls.Clear();
        currentBtns.Clear();
        actionsList.Clear();
        spokenAudioStrings.Clear();
        spokenTextStrings.Clear();
        spokenTxt.text = "";
    }

	#if UNITY_IOS
	/// <summary>
	/// When an image is selected from the gallery, assign it to the edit button and the selected button. 
	/// </summary>
	private void OnImage(IOSImagePickResult result)
	{
		if(result.IsSucceeded)
		{

			Texture2D img = result.Image;
			//cropImgObj.GetComponent<Renderer>().material.mainTexture = result.Image;
			Sprite image = Sprite.Create(img, new Rect(0, 0, img.width, img.height), new Vector2(.5f, .5f));

			ButtonBrain brain = currentBtn.GetComponent<ButtonBrain>();
			brain.MySprite = image;
			brain.MyImage.sprite = image;
			//brain.myImagePath = result.ImagePath;
			editBtnImg.sprite = image;
			editImage.interactable = true;

			SaveLoad.saveLoadScript.SaveImagePicked(brain);
			//AN_PoupsProxy.showMessage("Image Pick Rsult", "Succeeded, path: " + result.ImagePath);
		}
		else
		{
			//AN_PoupsProxy.showMessage("Image Pick Rsult", "Failed");
			editBtnImg.sprite = errorSprite;
		}

		IOSCamera.OnImagePicked -= OnImage;
	}

	#else
    /// <summary>
    /// When an image is selected from the gallery, assign it to the edit button and the selected button. 
    /// </summary>
    private void OnImagePicked(AndroidImagePickResult result)
    {
        if (result.IsSucceeded)
        {
            Texture2D img = result.Image;
            //cropImgObj.GetComponent<Renderer>().material.mainTexture = result.Image;
            Sprite image = Sprite.Create(img, new Rect(0, 0, img.width, img.height), new Vector2(.5f, .5f));

            ButtonBrain brain = currentBtn.GetComponent<ButtonBrain>();
            brain.MySprite = image;
            brain.MyImage.sprite = image;
            brain.myImagePath = result.ImagePath;
            editBtnImg.sprite = image;
            editImage.interactable = true;

            SaveLoad.saveLoadScript.SaveImagePicked(brain);
            AN_PoupsProxy.showMessage("Image Pick Rsult", "Succeeded, path: " + result.ImagePath);

        }
        else
        {
            AN_PoupsProxy.showMessage("Image Pick Rsult", "Failed");
        }

        AndroidCamera.Instance.OnImagePicked -= OnImagePicked;
    }
	#endif

    #endregion
}
