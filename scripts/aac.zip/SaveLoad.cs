﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;
using System.Collections.Generic;
using System;
using System.Runtime.Serialization.Formatters.Binary;
using System.IO;

public class SaveLoad : MonoBehaviour
{
    #region Public Variables
    public static SaveLoad saveLoadScript;
    public GameObject optionsPnl;
    public GameObject startPnl;
    public GameObject loadProfPnl;
    public GameObject createProfPnl;
    public Dropdown profileDropdown;
    public Toggle[] btnSizeTgl;
    public InputField profileNameInput;
    public Sprite[] standardImgs;
    #endregion

    #region Private Variables
    //private Dictionary<string, float[]> savedAudioTracks = new Dictionary<string, float[]>();
    private List<string> keys = new List<string>();
    private List<float[]> values = new List<float[]>();
    private List<GameObject> myPnls = new List<GameObject>();
    private GameObject homePnl;
    private List<string> profiles = new List<string>();
    private List<ButtonData[]> myBtnData = new List<ButtonData[]>();
    private List<byte[]> savedImgs = new List<byte[]>();
    private string currProfile = "";
    private bool soundValues = false; 
    private int btnSize = 0;
    #endregion

    #region Properties
    /// <summary>
    /// Gets or sets the root of the button panels.
    /// </summary>
    public GameObject HomePnl { get { return homePnl; } set { homePnl = value; } }

    /// <summary>
    /// Returns the list of all button panels.
    /// </summary>
    public List<GameObject> MyPnls { get { return myPnls; } }

    /// <summary>
    /// Gets or sets the currently selected profile.
    /// </summary>
    public string CurrProfile { get { return currProfile; } set { currProfile = value; } }

    /// <summary>
    /// Returns the button sizes for the currently selected profile.
    /// </summary>
    public int BtnSize { get { return btnSize; } }
    #endregion

    #region Unity Methods
    /// <summary>
    /// Initializes values.
    /// </summary>
    private void Awake()
    {
        Debug.Log(Application.persistentDataPath);
        saveLoadScript = this;
    }
    #endregion

    #region Public Methods
    /// <summary>
    /// Saves profiles if true, else saves current game data.
    /// </summary>
    public void Save(bool _profile = false)
    {
        FileStream file = null;
        string saveFile = "";

        // Determines if saving a profiles data or the list of profiles
        saveFile = _profile ? "profiles.prof" : currProfile + ".dat";

        try
        {
            BinaryFormatter bf = new BinaryFormatter();
            file = File.Create(Application.persistentDataPath + "/" + saveFile);

            if(_profile)
            {
                Profiles data = new Profiles();

                // Save profiles
                data.profiles = profiles;
                data.savedImgs = savedImgs;
                data.keys = keys;
                data.values = values;
                data.soundValues = soundValues;

                if (soundValues)
                    Debug.Log("save sound");

                bf.Serialize(file, data);
            }
            else
            {
                PlayerData data = new PlayerData();

                // Save data for current profile
                data.myBtnData = myBtnData;
                data.currProfile = currProfile;
                data.btnSize = btnSize;

                bf.Serialize(file, data);
            }

            file.Close();
        }
        finally
        {
            if (file != null)
                file.Close();
        }
    }

    /// <summary>
    /// Loads profiles if true, else loads current game data.
    /// </summary>
    public void Load(bool _profile = false)
    {
        FileStream file = null;
        string loadFile = "";

        // Determines if loading a profile or the list of profiles
        loadFile = _profile ? "profiles.prof" : currProfile + ".dat";
        //Debug.Log(loadFile);

        if (File.Exists(Application.persistentDataPath + "/" + loadFile))
        {
            try
            {
                BinaryFormatter bf = new BinaryFormatter();
                file = File.Open(Application.persistentDataPath + "/" + loadFile, FileMode.Open);

                if(_profile)
                {
                    Profiles data = (Profiles)bf.Deserialize(file);
                    file.Close();

                    // Load saved profile names
                    profiles = data.profiles;
                    savedImgs = data.savedImgs;
                    keys = data.keys;
                    values = data.values;               
                    soundValues = data.soundValues;
                    
                    if (soundValues)
                    {
                        Debug.Log("load sound");
                        //savedAudioTracks = data.savedSounds;
                        Dictionary<string, AudioClip> audioTracks = new Dictionary<string, AudioClip>();
                        //foreach (string k in keys)
                        for(int i = 0; i < keys.Count; i++)
                        {
                            AudioClip clip = new AudioClip();
                            clip = AudioClip.Create("RecordedSound", values[i].Length, 1, 44100, false, false);
                            clip.SetData(values[i], 0);
                            audioTracks.Add(keys[i], clip);
                        }
                        ButtonManager.buttonManagerScript.MyAudioTracks = audioTracks;
                    }


                    // Add profiles to profile dropdown
                    UpdateProfileDropdown();
                    loadProfPnl.SetActive(true);           
                }    
                else
                {
                    PlayerData data = (PlayerData)bf.Deserialize(file);
                    file.Close();

                    // Load data for current profile
                    myBtnData = data.myBtnData;
                    currProfile = data.currProfile;
                    btnSize = data.btnSize;

                    LoadBtnData();
                }     
            }
            finally
            {
                if (file != null)
                    file.Close();
            }
        }
        else if(_profile)
            createProfPnl.SetActive(true);
    }

    /// <summary>
    /// Deletes player data.
    /// </summary>
    public void Delete(string playerName)
    {
        if (File.Exists(Application.persistentDataPath + "/" + playerName + ".dat"))
        {
            File.Delete(Application.persistentDataPath + "/" + playerName + ".dat");
        }
    }

    /// <summary>
    /// Creates a new profile if the button size and name are filled in correctly.
    /// </summary>
    public void CreateProfileBtn()
    {
        if (btnSize == 0 && profileNameInput.text == "")
        {
            // There is no correct input
            StopAllCoroutines();
            StartCoroutine(InvalidToggle(3));
        }
        else if(btnSize == 0)
        {
            // There is no button size selected
            StopAllCoroutines();
            StartCoroutine(InvalidToggle(2));
        }
        else if (profileNameInput.text == "")
        {
            // There is no profile name entered
            StopAllCoroutines();
            StartCoroutine(InvalidToggle(1));
        }
        else
        {
            currProfile = profileNameInput.text;
            profiles.Add(currProfile);
            UpdateProfileDropdown(false);

            CreateNewPnl(null);
            Save(true); // Save profile name to profiles
            Save();  // Save profile data: Name and Button Size

            if(myPnls.Count > 0)
            {
                foreach (GameObject p in myPnls)
                    GameObject.Destroy(p);
                myPnls.Clear();
            }

            myBtnData.Clear();

            profileNameInput.text = "";
            loadProfPnl.SetActive(true);
            createProfPnl.SetActive(false);
        }
    }

    /// <summary>
    /// Save an image from your phone to the app and tag the current button as a carrier of the image.
    /// </summary>
    public void SaveImagePicked(ButtonBrain brain)
    {
        byte[] val = brain.MyImage.sprite.texture.EncodeToPNG();

        brain.MyImgInx = savedImgs.Count;
        brain.MyImgType = 2;

        savedImgs.Add(val);

        Save(true);

        UpdateButtonData(brain);
    }

    /// <summary>
    /// Saves the current state of the button.
    /// </summary>
    public void UpdateButtonData(ButtonBrain brain)
    {
        myBtnData[brain.MyPnlInx][brain.MyBtnInx].myChildPnlInx = brain.MyChildPnlInx;
        myBtnData[brain.MyPnlInx][brain.MyBtnInx].myText = brain.MyText;
        myBtnData[brain.MyPnlInx][brain.MyBtnInx].myAudio = brain.MyAudio;
        myBtnData[brain.MyPnlInx][brain.MyBtnInx].hide = brain.Hide;
        myBtnData[brain.MyPnlInx][brain.MyBtnInx].noAction = brain.NoAction;
        myBtnData[brain.MyPnlInx][brain.MyBtnInx].playWord = brain.PlayWord;
        myBtnData[brain.MyPnlInx][brain.MyBtnInx].opensWindow = brain.OpenWindow;
        myBtnData[brain.MyPnlInx][brain.MyBtnInx].myAudioSet = brain.MyAudioSet;
        myBtnData[brain.MyPnlInx][brain.MyBtnInx].homeBtnEnabled = brain.HomeBtn;
        myBtnData[brain.MyPnlInx][brain.MyBtnInx].color_r = brain.MyColor.r;
        myBtnData[brain.MyPnlInx][brain.MyBtnInx].color_g = brain.MyColor.g;
        myBtnData[brain.MyPnlInx][brain.MyBtnInx].color_b = brain.MyColor.b;
        myBtnData[brain.MyPnlInx][brain.MyBtnInx].myImgSize = new float[]{ brain.MyImgSize.x, brain.MyImgSize.y };
        myBtnData[brain.MyPnlInx][brain.MyBtnInx].myImgRot = 
            new float[]{ brain.MyRotation.x, brain.MyRotation.y, brain.MyRotation.z, brain.MyRotation.w };
        myBtnData[brain.MyPnlInx][brain.MyBtnInx].myImgPos =
            new float[]{ brain.MyImgPos.x, brain.MyImgPos.y, brain.MyImgPos.z};
        myBtnData[brain.MyPnlInx][brain.MyBtnInx].myImgInx = brain.MyImgInx;
        myBtnData[brain.MyPnlInx][brain.MyBtnInx].myImgType = brain.MyImgType; // Saved image type

        Save();
    }

    /// <summary>
    /// Sets the button size to the selected size.
    /// </summary>
    public void SelectBtnSize(Toggle _tog)
    {
        btnSize = _tog.name == "21" ? 3 : _tog.name == "36" ? 2 : 1;
    }

    /// <summary>
    /// When profile selected from dropdown set that as the new current profile name.
    /// </summary>
    public void SelectProfile()
    {
        currProfile = profileDropdown.captionText.text;
    }

    /// <summary>
    /// Loads the saved data for the current profile and sets up the saved profile for play.
    /// </summary>
    public void ContinueBtn()
    { 
        if(currProfile != "")
        {
            //StopAllCoroutines();
            //StartCoroutine(LoadProfileAnim());

            Load();
            //ButtonManager.buttonManagerScript.SetLoadedValues(homePnl ,btnSize - 1);

            loadProfPnl.SetActive(false);
            startPnl.SetActive(false);
        }

    }

    /// <summary>
    /// Creates a new button panel and initializes each buttons information.
    /// </summary>
    public void CreateNewPnl(ButtonBrain currBrain, bool setActive = true)
    {
        // Create new panel of the appropriate size
        GameObject newPnl = ButtonManager.buttonManagerScript.InitImgPnl(btnSize - 1);
        // Collect all the buttons on the new panel
        GameObject[] btns = newPnl.GetComponent<ImagePage>().ImageBtns;
        // Store each button data in this array for saving
        ButtonData[] saveBtnBrainData = new ButtonData[btns.Length];

        // Initialize each button
        for (int i = 0; i < btns.Length; i++)
        {
            ButtonData data = new ButtonData();
            ButtonBrain brain = btns[i].GetComponent<ButtonBrain>();
            brain.MyPnlInx = myBtnData.Count;
            brain.MyBtnInx = i;
            if(currBrain)
            {
                currBrain.MyChildPnlInx = myBtnData.Count;
                Debug.Log("count = " + myBtnData.Count);
                //currBrain.ChildImagePnl = newPnl;
                //data.myChildPnlInx = myBtnData.Count;
            }

            data.myPnlInx = myBtnData.Count;
            data.myBtnInx = i;

            saveBtnBrainData[i] = data;
        }

        myPnls.Add(newPnl);
        myBtnData.Add(saveBtnBrainData);

        if (!setActive)
            newPnl.SetActive(false);
    }

    /// <summary>
    /// Saves a new audio track.
    /// </summary>
    public void SaveNewTrack(string key, AudioClip val)
    {
        //audioTracks.Add(key, val);
        //savedAudioTracks.Add(key, val.)
        soundValues = true;
        float[] samples = new float[val.samples * val.channels];
        val.GetData(samples, 0);

        //savedAudioTracks.Add(key, samples);
        keys.Add(key);
        values.Add(samples);

        Save(true);
    }
    #endregion

    #region Private Methods
    /// <summary>
    /// Load all of the buttons data, options, images, and sounds.
    /// </summary>
    private void LoadBtnData()
    {
        for (int i = 0; i < myBtnData.Count; i++)
        {
            GameObject newPnl = ButtonManager.buttonManagerScript.InitImgPnl(btnSize - 1);
            GameObject[] btns = newPnl.GetComponent<ImagePage>().ImageBtns;

            for (int j = 0; j < btns.Length; j++)
            {
                ButtonBrain brain = btns[j].GetComponent<ButtonBrain>();
                brain.MyPnlInx = myBtnData[i][j].myPnlInx;
                brain.MyBtnInx = myBtnData[i][j].myBtnInx;
                brain.MyChildPnlInx = myBtnData[i][j].myChildPnlInx;
                brain.MyColor = new Vector4(myBtnData[i][j].color_r, myBtnData[i][j].color_g, myBtnData[i][j].color_b, 1);
                brain.MyText = myBtnData[i][j].myText;
                if (myBtnData[i][j].myAudioSet)
                    brain.MyAudio = myBtnData[i][j].myAudio;
                brain.Hide = myBtnData[i][j].hide;
                brain.NoAction = myBtnData[i][j].noAction;
                brain.OpenWindow = myBtnData[i][j].opensWindow;
                brain.HomeBtn = myBtnData[i][j].homeBtnEnabled;

                if (myBtnData[i][j].myImgType != 0)
                {
                    brain.MyImgType = myBtnData[i][j].myImgType;
                    brain.MyImgInx = myBtnData[i][j].myImgInx;

                    if (myBtnData[i][j].myImgType == 1)
                    {
                        // Included image
                    }
                    else
                    {
                        // Saved image from gallery
                        Sprite newSprite = LoadPNG(savedImgs[myBtnData[i][j].myImgInx]);
                        if (newSprite)
                        {
                            brain.MySprite = newSprite;
                        }
                    }

                    brain.MyRotation = new Quaternion(myBtnData[i][j].myImgRot[0], myBtnData[i][j].myImgRot[1],
                        myBtnData[i][j].myImgRot[2], myBtnData[i][j].myImgRot[3]);
                    brain.MyImgSize = new Vector2(myBtnData[i][j].myImgSize[0], myBtnData[i][j].myImgSize[1]);
                    brain.MyImgPos = new Vector3(myBtnData[i][j].myImgPos[0], myBtnData[i][j].myImgPos[1], myBtnData[i][j].myImgPos[2]);
                }
            }

            myPnls.Add(newPnl);
            if (i > 0)
                newPnl.SetActive(false);
            else
                ButtonManager.buttonManagerScript.InitCurrHomePnl(newPnl);
        }

        myPnls[0].GetComponent<ImagePage>().SetValuesToCurrent();
    }

    /// <summary>
    /// Loads a png image, converts it and returns it as a sprite.
    /// </summary>
    private Sprite LoadPNG(byte[] file)
    {
        Texture2D img = new Texture2D(2, 2);
        Sprite newSprite = null;

        img.LoadImage(file);
        newSprite = Sprite.Create(img, new Rect(0, 0, img.width, img.height), new Vector2(.5f, .5f));

        return newSprite;
    }

    /// <summary>
    /// Populates the dropdown list of profile names.
    /// </summary>
    private void UpdateProfileDropdown(bool initCurrent = true)
    {
        profileDropdown.ClearOptions();
        if(profiles.Count != 0)
        {
            profileDropdown.AddOptions(profiles);
            if (initCurrent)
                currProfile = profileDropdown.captionText.text;
            else
                profileDropdown.value = profileDropdown.options.Count -1;
        }   
    }

    /// <summary>
    /// Turns the toggle buttons and/or the name input field red, if none are selected then slowly fade to white.
    /// </summary>
    private IEnumerator InvalidToggle(int _correct = 0)
    {
        // Turn the toggle buttons red
        if (_correct == 2 || _correct == 3)
        {
            foreach (Toggle t in btnSizeTgl)
            {
                ColorBlock cb = t.colors;
                cb.normalColor = Color.red;
                t.colors = cb;
            }
        }

        // Turn the profile name input field red
        if (_correct == 1 || _correct == 3)
        {
            ColorBlock cb = profileNameInput.colors;
            cb.normalColor = Color.red;
            profileNameInput.colors = cb;
        }

        Color cbTracker = Color.red;
        // Lerp everything back to white
        while (cbTracker != Color.white)
        {
            foreach (Toggle t in btnSizeTgl)
            {
                ColorBlock cb = t.colors;
                cb.normalColor = Color.Lerp(cb.normalColor, Color.white, .2f);
                t.colors = cb;
            }

            ColorBlock cb1 = profileNameInput.colors;
            cb1.normalColor = Color.Lerp(cb1.normalColor, Color.white, .2f);
            profileNameInput.colors = cb1;

            cbTracker = Color.Lerp(cbTracker, Color.white, .2f);

            yield return new WaitForSeconds(0.1f);
        }

        yield return null;
    }

    /// <summary>
    /// Not complete. Provides an animation while loading profile info and setting button values.
    /// </summary>
    private IEnumerator LoadProfileAnim()
    {
        yield return null;
    }

    #endregion
}

// Saved profiles
[Serializable]
class Profiles
{
    public List<string> profiles;
    public List<byte[]> savedImgs = new List<byte[]>();
    public bool soundValues = false;
    //public Dictionary<string, float[]> savedSounds = new Dictionary<string, float[]>();
    public List<string> keys = new List<string>();
    public List<float[]> values = new List<float[]>();
}

// Saved player data
[Serializable]
class PlayerData
{
    public List<ButtonData[]> myBtnData = new List<ButtonData[]>();
    public string currProfile = "";
    public int btnSize = 0;
}

// Saved button data
[Serializable]
class ButtonData
{
    public float[] myImgRot = new float[4];
    public float[] myImgPos = new float[3];
    public float[] myImgSize = new float[2];
    public float color_r;
    public float color_g;
    public float color_b;
    public string myText = "Button";
    public string myAudio = "";
    public bool hide = false;
    public bool noAction = false;
    public bool playWord = false;
    public bool opensWindow = false;
    public bool myAudioSet = false;
    public bool homeBtnEnabled = false;
    public int myImgType = 0;
    public int myImgInx = 0;
    public int myBtnInx = 0;
    public int myPnlInx = 0;
    public int myChildPnlInx = 0;

}