﻿using UnityEngine;
using System.Collections;

public class PickupsManager : MonoBehaviour
{
    #region Public Variables
    public static PickupsManager pickupsManagerScript;
    public GameObject flyPrefab;
    public static int enabledFlyCount = 0;
    #endregion

    #region Private Variables
    private GameObject[] flies;
    private readonly int maxFlies = 10;
    private int eatFly = 0;
    #endregion

    #region Unity Methods
    /// <summary>
    /// Initializes pickup items in the game.
    /// </summary>
    private void Start()
    {
        pickupsManagerScript = this;
        flies = new GameObject[maxFlies];
        for (int i = 0; i < maxFlies; i++)
            flies[i] = Instantiate(flyPrefab, transform.position, Quaternion.identity) as GameObject;
    }
    #endregion

    #region Public Methods
    /// <summary>
    /// Spawns the initial group of flys on the map.
    /// </summary>
    public void InitSpawnFlys(SpriteRenderer[,] _map, int _numRows, int _numCols)
    {
        for (int i = 0; i < maxFlies; i++)
            flies[i].GetComponent<Fly>().EnableFly(_map, _numRows, _numCols);
    }

    /// <summary>
    /// Keeps track of the flies that have been eaten and checks gameover condition.
    /// </summary>
    public void EatFly()
    {
        eatFly++;
        if (eatFly == maxFlies)
            GameManager.gameManagerScript.GameOver();
    }
    #endregion
}
