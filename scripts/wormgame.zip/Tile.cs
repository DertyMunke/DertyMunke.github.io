﻿using UnityEngine;
using System.Collections;

public class Tile : MonoBehaviour
{
    #region Public Variables
    public Transform flySpawnPt;
    public bool[] rotOpenings = new bool[4];
    public bool[] openings; // -y, -x, y, x
    public bool edgePiece;  // Can be used as an edge piece
    public int[] edgeRotation;  // index 0 = bottom wall, rotates clockwise
    public int myRotIndex;
    public int myRow;
    public int myCol;
    #endregion

    #region Private Variables
    private bool pickup = false;
    private int myYRot = 0;
    #endregion

    #region Getters Setters
    public Transform FlySpawnPt { get { return flySpawnPt; } }
    public bool[] RotatedOpenings { get { return rotOpenings; } }
    public bool Pickup { get { return pickup; } set { pickup = value; } }
    public int[] Position { get { return new int[] { myRow, myCol }; } }
    #endregion

    #region Public Methods
    /// <summary>
    /// Set the position in the map of the tile.
    /// </summary>
    public void SetPosition(int row, int col)
    {
        myRow = row;
        myCol = col;
    }

    /// <summary>
    /// Set the rotation of the tile or the edge rotation index if its an edge.
    /// </summary>
    public void SetRotation(int rot, bool edge = true)
    {
        if (edge)
        {
            myRotIndex = rot;
            myYRot = edgeRotation[rot];
        }
        else
            myYRot = rot;

        SetNewOpenings();
    }

    /// <summary>
    /// Set the new openings for the tiles new rotation.
    /// </summary>
    public void SetNewOpenings()
    {
        if (myYRot == 0)
        {
            rotOpenings[0] = openings[0];
            rotOpenings[1] = openings[1];
            rotOpenings[2] = openings[2];
            rotOpenings[3] = openings[3];
        }
        else if (myYRot == 90)
        {
            rotOpenings[0] = openings[1];
            rotOpenings[1] = openings[2];
            rotOpenings[2] = openings[3];
            rotOpenings[3] = openings[0];
        }
        else if (myYRot == 180)
        {
            rotOpenings[0] = openings[2];
            rotOpenings[1] = openings[3];
            rotOpenings[2] = openings[0];
            rotOpenings[3] = openings[1];
        }
        else if (myYRot == -90 || myYRot == 270)
        {
            rotOpenings[0] = openings[3];
            rotOpenings[1] = openings[0];
            rotOpenings[2] = openings[1];
            rotOpenings[3] = openings[2]; 
        }
    }

    /// <summary>
    /// Returns the current rotation.
    /// </summary>
    public int GetRotation()
    {
        return myYRot;
    }
    #endregion
}
