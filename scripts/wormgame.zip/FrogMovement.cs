﻿using UnityEngine;
using System.Collections;

public class FrogMovement : MonoBehaviour 
{
    #region Public Variables
    public Sprite[] frogSprites;
    #endregion

    #region Private Variables
    private Tile tileScript = null;
	private Vector3 deltaSwipe;
    private Vector3 tempDeltaSwipe;
	private Vector3 frogStartPos;
    private float frogAnimSpacing = .05f;
	private int[] rowCol = { 0, 0 };
    #endregion

    #region Unity Methods
    /// <summary>
    /// Initializations.
    /// </summary>
    private void Start()
	{
		frogStartPos = transform.position;
		deltaSwipe = Vector3.zero;
	}

	/// <summary>
	/// Checks every frame for swipe input.
	/// </summary>
	private void Update()
	{
		LookForSwipe();
	}

    /// <summary>
    /// Checks if the frog lands on a pickup and eats it.
    /// </summary>
    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.tag == "pickup")
        {
            other.gameObject.SetActive(false);
            PickupsManager.pickupsManagerScript.EatFly();
        }
    }
    #endregion

    #region Private Methods
    /// <summary>
    /// Determines frog behavior on swipe.
    /// </summary>
    private void LookForSwipe()
	{
        if (!tileScript)
            tileScript = MapMaker.mapScript.GetTile(rowCol[0], rowCol[1]).GetComponent<Tile>();

        if (Input.GetMouseButtonDown(0))  // Sets the start point of the swipe
        {
            deltaSwipe = Input.mousePosition;
        }
        else if (Input.GetMouseButton(0))  // Points frog in the correct direction before he jumps
        {
            tempDeltaSwipe = deltaSwipe - Input.mousePosition;

            if (tempDeltaSwipe.x > 40 && Mathf.Abs(tempDeltaSwipe.x) > Mathf.Abs(tempDeltaSwipe.y))
            {
                transform.rotation = Quaternion.Euler(new Vector3(0, 0, 0));
            }
            else if (tempDeltaSwipe.x > -40 && Mathf.Abs(tempDeltaSwipe.x) > Mathf.Abs(tempDeltaSwipe.y))
            {
                transform.rotation = Quaternion.Euler(new Vector3(0, 0, 180));
            }
            else if (tempDeltaSwipe.y > 40 && Mathf.Abs(tempDeltaSwipe.y) > Mathf.Abs(tempDeltaSwipe.x))
            {
                transform.rotation = Quaternion.Euler(new Vector3(0, 0, 90));
            }
            else if (tempDeltaSwipe.y > -40 && Mathf.Abs(tempDeltaSwipe.y) > Mathf.Abs(tempDeltaSwipe.x))
            {
                transform.rotation = Quaternion.Euler(new Vector3(0, 0, 270));
            }

        }
        else if (Input.GetMouseButtonUp(0))  // Makes from jump in the correct direction
        {
            deltaSwipe -= Input.mousePosition;

            if (deltaSwipe.x > 40 && transform.position.x > frogStartPos.x + 1 && tileScript && tileScript.rotOpenings[1]
                && Mathf.Abs(deltaSwipe.x) > Mathf.Abs(deltaSwipe.y))
            {
                StartCoroutine(JumpAnim(1));
                rowCol[1]--;
                tileScript = null;
            }
            else if (deltaSwipe.x < -40 && transform.position.x < frogStartPos.x + 2.55f * 7 && tileScript.rotOpenings[3]
                 && Mathf.Abs(deltaSwipe.x) > Mathf.Abs(deltaSwipe.y))
            {
                StartCoroutine(JumpAnim(3));
                rowCol[1]++;
                tileScript = null;
            }
            else if (deltaSwipe.y > 40 && transform.position.y > frogStartPos.y + 1 && tileScript.rotOpenings[0]
                 && Mathf.Abs(deltaSwipe.y) > Mathf.Abs(deltaSwipe.x))  // Down
            {
                StartCoroutine(JumpAnim(0));               
                rowCol[0]--;
                tileScript = null;
            }
            else if (deltaSwipe.y < -40 && transform.position.y < frogStartPos.y + 2.55f * 5 && tileScript.rotOpenings[2]
                 && Mathf.Abs(deltaSwipe.y) > Mathf.Abs(deltaSwipe.x))  // Up
            {
                StartCoroutine(JumpAnim(2));                
                rowCol[0]++;
                tileScript = null;
            }
            deltaSwipe = Vector3.zero;
        }
	}

    /// <summary>
    /// Animates the frogs jump. The dir = 0 -> down, 1 -> left, 2 -> up, 3 -> right.
    /// </summary>
    private IEnumerator JumpAnim(int dir)
    {
        gameObject.GetComponent<SpriteRenderer>().sprite = frogSprites[1];
        yield return new WaitForSeconds(frogAnimSpacing); 
        switch (dir)
        {
            case 0:                
                transform.position = new Vector3(transform.position.x, transform.position.y - 2.55f, transform.position.z);
                break;
            case 1:
                transform.position = new Vector3(transform.position.x - 2.55f, transform.position.y, transform.position.z);
                break;
            case 2:
                transform.position = new Vector3(transform.position.x, transform.position.y + 2.55f, transform.position.z);
                break;
            case 3:
                transform.position = new Vector3(transform.position.x + 2.55f, transform.position.y, transform.position.z);
                break;
            default:
                break;
        }
        yield return new WaitForSeconds(frogAnimSpacing);
        gameObject.GetComponent<SpriteRenderer>().sprite = frogSprites[0];

        yield return null;
    }
    #endregion
}
