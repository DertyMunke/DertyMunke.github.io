﻿using UnityEngine;
using System.Collections;

public class Segment : MonoBehaviour
{
    #region Private Variables
    private Centipede.Direction turning = Centipede.Direction.FORWARD;
    private Centipede.Direction nextTurn = Centipede.Direction.FORWARD;
    private GameObject myChildSegment;
    private int[] turnAtRowCol = { 0, 0 };
    #endregion

    #region Getters Setters
    public Centipede.Direction SetNextTurnDir { set { nextTurn = value; } }
    public GameObject SetMyChildSegment { set { myChildSegment = value; } }
    public int[] SetTurnAtRowCol { set { turnAtRowCol = value; } }
    #endregion

    #region Unity Methods
    /// <summary>
    /// Triggers the turn of the centipede segment.
    /// </summary>
    private void OnTriggerEnter2D(Collider2D other)
    {
        if ((other.tag == "corner" || other.tag == "t" || other.tag == "line" || other.tag == "cross"))
        {
            if (other.GetComponent<Tile>().Position[0] == turnAtRowCol[0] && other.GetComponent<Tile>().Position[1] == turnAtRowCol[1])
            {
                turning = nextTurn;
            }
        }
    }
    #endregion

    #region Public Methods
    /// <summary>
    /// Enables the segment animation coroutine.
    /// </summary>
    public void StartSegmentParentAI()
    {
        StartCoroutine(SegmentAI());
    }
    #endregion

    #region Coroutines
    /// <summary>
    /// Determines the movement of the segment and moves it accordingly.
    /// </summary>
    private IEnumerator SegmentAI()
    {
        bool segmentAI = true;
        while(segmentAI)
        {
            yield return new WaitForSeconds(.1f);

            switch (turning)
            {
                case Centipede.Direction.RIGHT:
                    if (myChildSegment.transform.localEulerAngles.z >= 310)
                        myChildSegment.transform.localEulerAngles = new Vector3(0, 0, myChildSegment.transform.localEulerAngles.z + 9);
                    else if (Mathf.Floor(myChildSegment.transform.localEulerAngles.z) < 45)
                        myChildSegment.transform.localEulerAngles = new Vector3(0, 0, myChildSegment.transform.localEulerAngles.z + 5);
                    break;
                case Centipede.Direction.LEFT:
                    if (myChildSegment.transform.localEulerAngles.z <= 50 && myChildSegment.transform.localEulerAngles.z > 0)
                        myChildSegment.transform.localEulerAngles = new Vector3(0, 0, myChildSegment.transform.localEulerAngles.z - 9);
                    if (Mathf.Floor(myChildSegment.transform.localEulerAngles.z) > 315 || myChildSegment.transform.localEulerAngles.z == 0)
                    {
                        myChildSegment.transform.localEulerAngles = new Vector3(0, 0, myChildSegment.transform.localEulerAngles.z - 5);
                    }
                    break;
                case Centipede.Direction.FORWARD:
                    if (myChildSegment.transform.localEulerAngles.z <= 5 || myChildSegment.transform.localEulerAngles.z >= 355)
                        myChildSegment.transform.localEulerAngles = Vector3.zero;
                    if (Mathf.Floor(myChildSegment.transform.localEulerAngles.z) > 0 && myChildSegment.transform.localEulerAngles.z <= 50)
                        myChildSegment.transform.localEulerAngles = new Vector3(0, 0, myChildSegment.transform.localEulerAngles.z - 5);
                    else if (Mathf.Floor(myChildSegment.transform.localEulerAngles.z) >= 310)
                        myChildSegment.transform.localEulerAngles = new Vector3(0, 0, myChildSegment.transform.localEulerAngles.z + 5);
                    else
                        myChildSegment.transform.localEulerAngles = Vector3.zero;
                    break;
                default:
                    break;
            }
        }
    }
    #endregion
}
