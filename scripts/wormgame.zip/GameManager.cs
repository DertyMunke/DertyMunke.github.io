﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;
using System.Collections.Generic;

public class GameManager : MonoBehaviour
{
    #region Public Variables
    public static GameManager gameManagerScript;
    public Transform selectMapBtnParent;
    public Button selectMapBtn;
    public int numBtns = 0;
    #endregion

    #region Unity Methods
    /// <summary>
    /// Initialize this script
    /// </summary>
    private void Awake()
    {
        gameManagerScript = this;
    }

    /// <summary>
    /// Initializes the game board
    /// </summary>
    private void Start()
    {
        MapMaker.mapScript.MakeMap();
    }
    #endregion

    #region Public Methods
    /// <summary>
    /// Adds a new botton with its associated map name.
    /// </summary>
    public void AddNewBtn(string _mapName)
    {
        Button newBtn = Instantiate(selectMapBtn) as Button;
        newBtn.transform.SetParent(selectMapBtnParent, false);
        newBtn.GetComponentInChildren<Text>().text = _mapName;
        newBtn.onClick.AddListener(() => MapMaker.mapScript.SelectMapBtn(newBtn));
        RectTransform posBtn = newBtn.GetComponent<RectTransform>();

        if (numBtns % 2 == 0)  // Left column of buttons
        {
            posBtn.anchorMax = new Vector2(posBtn.anchorMax.x, posBtn.anchorMax.y - Mathf.Ceil(numBtns * .5f) * .08f);
            posBtn.anchorMin = new Vector2(posBtn.anchorMin.x, posBtn.anchorMin.y - Mathf.Ceil(numBtns * .5f) * .08f);
        }
        else  // Right column of buttons
        {
            posBtn.anchorMax = new Vector2(posBtn.anchorMax.x + .44f, posBtn.anchorMax.y - Mathf.Floor(numBtns * .5f) * .08f);
            posBtn.anchorMin = new Vector2(posBtn.anchorMin.x + .44f, posBtn.anchorMin.y - Mathf.Floor(numBtns * .5f) * .08f);
        }
        numBtns++;
    }

    /// <summary>
    /// Creates the buttons that will load a different map.
    /// </summary>
    public void CreateMapBtns(Dictionary<string, string[,]> _savedMaps)
    {
        foreach (string key in _savedMaps.Keys)
        {
            AddNewBtn(key);
        }
    }

    /// <summary>
    /// Incomplete: This will check game over conditions.
    /// </summary>
    public void GameOver()
    {
        Debug.Log("game is ova!");
    }
    #endregion
}
