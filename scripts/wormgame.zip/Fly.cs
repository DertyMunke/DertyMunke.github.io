﻿using UnityEngine;
using System.Collections;

public class Fly : MonoBehaviour
{
    #region Public Variables
    public GameObject buttGlow;
    #endregion

    #region Private Variables
    private bool buttGlowActive = false;
    private float maxLifeTime = 10;
    private float minLifeTime = 5;
    #endregion

    #region Public Methods
    /// <summary>
    /// Starts the fly AI coroutine.
    /// </summary>
    public void EnableFly(SpriteRenderer[,] _map, int _numRows, int _numCols)
    {
        StartCoroutine(FlyAI(_map, _numRows, _numCols));
    }
    #endregion

    #region Coroutines
    /// <summary>
    /// Each fly manages its AI through this function.
    /// </summary>
    private IEnumerator FlyAI(SpriteRenderer[,] _map, int _numRows, int _numCols)
    {
        Tile tileScript;
        bool runAI = true;
        int ranRow = 0;
        int ranCol = 0;

        while (runAI)
        {
            do
            {
                // Chooses a new tile to fly to
                ranRow = Random.Range(0, _numRows);
                ranCol = Random.Range(0, _numCols);
                tileScript = _map[ranRow, ranCol].GetComponent<Tile>();
            }
            while (tileScript.Pickup);

            transform.position = tileScript.FlySpawnPt.position;
            gameObject.GetComponent<SpriteRenderer>().enabled = true;
            StartCoroutine(EndButtGlow()); // Prepares fly to take off
            PickupsManager.enabledFlyCount++;
            yield return new WaitForSeconds(Random.Range(minLifeTime, maxLifeTime)); // Random flight time
            buttGlowActive = true;
            StartCoroutine(StartButtGlow()); // Landing butt glow
            while (buttGlowActive)
                yield return null;
            gameObject.GetComponent<SpriteRenderer>().enabled = false;
            PickupsManager.enabledFlyCount--;
        }
        yield return null;
    }

    /// <summary>
    /// Starts the butt glow landing animation.
    /// </summary>
    private IEnumerator StartButtGlow()
    {
        buttGlow.SetActive(true);
        yield return new WaitForSeconds(.3f);
        int rand = Random.Range(5, 10);
        for (int i = 0; i < rand; i++)
        {
            buttGlow.SetActive(false);
            yield return new WaitForSeconds(Random.Range(0.1f, 0.3f));
            buttGlow.SetActive(true);
        }

        yield return new WaitForSeconds(.1f);
        buttGlow.SetActive(true);
        yield return new WaitForSeconds(.3f);
        buttGlowActive = false;
    }

    /// <summary>
    /// Starts the butt glow take off animation.
    /// </summary>
    private IEnumerator EndButtGlow()
    {
        int rand = Random.Range(5, 10);
        for (int i = 0; i < rand; i++)
        {
            buttGlow.SetActive(true);
            yield return new WaitForSeconds(Random.Range(0.1f, 0.3f));
            buttGlow.SetActive(false);
        }

        yield return new WaitForSeconds(.1f);
        buttGlow.SetActive(true);
        yield return new WaitForSeconds(.3f);
        buttGlow.SetActive(false);
        yield return null;
    }
    #endregion

}
