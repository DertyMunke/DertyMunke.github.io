#othello_gui
#Double click or run this file if you have IDLE and you can play
#play my full version of Othello

import collections
import othello_logic
import tkinter

DEFAULT_FONT = ('Helvetica', 14)
GameOptions = collections.namedtuple('GameOptions', 'rows columns first upper_left winner')

class OptionsMenu:
    def __init__(self):
        self._num_rows = 4
        self._num_cols = 4
        self._first = 'W'
        self._upper_left = 'B'
        self._wins = 'M'
        
        self._option_window = tkinter.Tk()

        welcome_label = tkinter.Label(master = self._option_window, text =
                                      "Thanks for playing Othello by JOel\n"
                                      "Please choose your gameplay options below.", font = DEFAULT_FONT)
        welcome_label.grid(row = 0, column = 0, columnspan = 2, padx = 10, pady = 10, sticky = tkinter.W)

        self._label(1, 0, "How many rows?")
        self._options_button(1, 1, self._on_rows)
        self._label(1, 3, self._num_rows)

        self._label(2, 0, "How many columns?")
        self._options_button(2, 1, self._on_cols)
        self._label(2, 3, self._num_cols)

        self._label(3, 0, "Who moves first?")
        self._options_button(3, 1, self._on_first)
        self._label(3, 3, self._first)

        self._label(4, 0, "Who starts in upper-left?")
        self._options_button(4, 1, self._on_upper)
        self._label(4, 3, self._upper_left)

        self._label(5, 0, "Who wins? Most or Fewest?")
        self._options_button(5, 1, self._on_wins)
        self._label(5, 3, self._wins)

        done_button = tkinter.Button(master = self._option_window, text = '   Done   ',
                                font = DEFAULT_FONT, command = self._on_done)
        
        done_button.grid(row = 6, column = 0, padx = 10, pady = 10, sticky = tkinter.E)

    def _on_done(self)-> GameOptions:
        '''Returns the current values to create game board'''
        options = GameOptions(self._num_rows, self._num_cols, self._first, self._upper_left, self._wins)
        game_state.rows_columns(options.rows, options.columns)
        game_state.first_player(options.first)
        game_state.set_win_type(options.winner)
        game_state.init_board(options.upper_left)
        
        self._option_window.destroy()

        GameBoard()

    def _on_wins(self):
        '''Gives options for who the winner will be'''
        self._wins_window = tkinter.Toplevel()
        self._wins_window.grab_set()
        
        most_button = tkinter.Button(master = self._wins_window, text = 'Most',
                                        font = DEFAULT_FONT, command = lambda name = 'M':self._set_wins(name))
        most_button.grid(row = 0, column = 0, padx = 10, pady = 10)
        
        fewest_button = tkinter.Button(master = self._wins_window, text = 'Fewest',
                                        font = DEFAULT_FONT, command = lambda name = 'F':self._set_wins(name))
        fewest_button.grid(row = 0, column = 1, padx = 10, pady = 10)

    def _set_wins(self, name):
        '''Sets if the winner has the most or fewest discs'''
        self._wins = name
        self._wins_window.destroy()
        self._label(5, 3, '     ') #<-this is because of some weird glitch
        self._label(5, 3, self._wins)
    
    def _on_upper(self):
        self._upper_window = tkinter.Toplevel()
        self._upper_window.grab_set()
        
        white_button = tkinter.Button(master = self._upper_window, text = 'White',
                                        font = DEFAULT_FONT, command = lambda name = 'W':self._set_upper_left(name))
        white_button.grid(row = 0, column = 0, padx = 10, pady = 10)
        
        black_button = tkinter.Button(master = self._upper_window, text = 'Black',
                                        font = DEFAULT_FONT, command = lambda name = 'B':self._set_upper_left(name))
        black_button.grid(row = 0, column = 1, padx = 10, pady = 10)

    def _set_upper_left(self, name):
        '''Sets who starts in the upper left of center four'''
        self._upper_left = name
        self._upper_window.destroy()
        self._label(4, 3, '     ') #<-this is because of some weird glitch
        self._label(4, 3, self._upper_left)

    def _on_first(self):
        '''Gives options for who goes first'''
        self._first_window = tkinter.Toplevel()
        self._first_window.grab_set()
        
        white_button = tkinter.Button(master = self._first_window, text = 'White',
                                        font = DEFAULT_FONT, command = lambda name = 'W':self._set_first(name))
        white_button.grid(row = 0, column = 0, padx = 10, pady = 10)
        
        black_button = tkinter.Button(master = self._first_window, text = 'Black',
                                        font = DEFAULT_FONT, command = lambda name = 'B':self._set_first(name))
        black_button.grid(row = 0, column = 1, padx = 10, pady = 10)

    def _set_first(self, name):
        '''Sets the first player to move'''
        self._first = name
        self._first_window.destroy()
        self._label(3, 3, '     ') #<-this is because of some weird glitch
        self._label(3, 3, self._first)
        
    def _on_cols(self):
        '''Gives options for columns'''
        self._cols_window = tkinter.Toplevel()
        self._cols_window.grab_set()

        for button in range(4, 17):
            if button % 2 == 0:
                num_button = tkinter.Button(master = self._cols_window, text = '{}'.format(button),
                                            font = DEFAULT_FONT, command = lambda name = button:self._set_cols(name))
                num_button.grid(row = 1, column = button - 4, padx = 0, pady = 0)

    def _set_cols(self, name):
        '''Sets the number of cols'''
        self._num_cols = int(name)
        self._cols_window.destroy()
        self._label(2, 3, '     ') #<-this is because of some weird glitch
        self._label(2, 3, self._num_cols)

    def _on_rows(self):
        '''Gives options for rows'''
        self._rows_window = tkinter.Toplevel()
        self._rows_window.grab_set()

        for button in range(4, 17):
            if button % 2 == 0:
                num_button = tkinter.Button(master = self._rows_window, text = ' {} '.format(button),
                                            font = DEFAULT_FONT, command = lambda name = button:self._set_rows(name))
                num_button.grid(row = 1, column = button - 4, padx = 0, pady = 0)
        
    def _set_rows(self, name):
        self._num_rows = int(name)
        self._rows_window.destroy()
        self._label(1, 3, '     ') #<-this is because of some weird glitch
        self._label(1, 3, self._num_rows)
        
    def _options_button(self, r: int, col: int, com: str):
        '''Creates a button that says Options in column 2 row r'''
        button = tkinter.Button(master = self._option_window, text = 'Options',
                                font = DEFAULT_FONT, command = com)
        
        button.grid(row = r, column = col, padx = 10, pady = 10, sticky = tkinter.E)

    def _label(self, r: int, col: int, message: str):
        '''Creates a label with the specified message in column 1 row r'''
        label = tkinter.Label(master = self._option_window, text = message, font = DEFAULT_FONT)
        label.grid(row = r, column = col, padx = 10, pady = 10, sticky = tkinter.W)
    
    def start(self) -> None:
        '''Opens the Options Menu'''
        self._option_window.mainloop()

class GameBoard:
    def __init__(self):
        
        self._row = 4
        self._column = 4

        self._game_window = tkinter.Tk()


        self._label(0, 0, self._turn_message())
        self._label(0, 1, self._score_message())
        

        self._canvas = tkinter.Canvas(master = self._game_window, width = 600,
                                      height = 600, background = '#006000')
        self._canvas.grid(row = 1, column= 0, columnspan = 2, padx = 10, pady = 10,
                          sticky = tkinter.N + tkinter.S + tkinter.E + tkinter.W)

        self._label(3, 0, '  ')
        
        self._game_window.rowconfigure(1, weight = 1)
        self._game_window.columnconfigure(0, weight = 1)

        self._canvas.bind('<Configure>', self._on_canvas_resized)
        self._canvas.bind('<Button-1>', self._on_canvas_clicked)        

    def _on_canvas_clicked(self, event: tkinter.Event):
        '''When the canvas is clicked'''
        width = self._canvas.winfo_width()
        height = self._canvas.winfo_height()
        rows = game_state.get_rows()
        cols = game_state.get_columns()
        tile_height = int(height/rows)
        tile_width = int(width/cols)
        this_row = 0
        this_col = 0
        
        for row in range(1, rows + 1):
            if event.y <= tile_height * row:
                this_row = row
                break
        for col in range(1, cols + 1):
            if event.x <= tile_width * col:
                this_col = col
                break
        try:
            game_state.move(this_row - 1, this_col - 1)
            
            self._canvas_draw()
            self._label(3, 0, '                                                                  ')
            if game_state.can_move() == False:
                game_state.cannot_move()
                if game_state.can_move():    
                    if game_state.player_turn() == 'B':
                        label = tkinter.Label(master = self._game_window, text = "White has no moves, Black goes again",
                                              font = DEFAULT_FONT)
                        label.grid(row = 3, column = 0, padx = 10, pady = 10, sticky = tkinter.W)
                    else:
                        label = tkinter.Label(master = self._game_window, text = "Black has no moves, White goes again",
                                              font = DEFAULT_FONT)
                        label.grid(row = 3, column = 0, padx = 10, pady = 10, sticky = tkinter.W)

                    self._canvas_draw()


                else:

                    label = tkinter.Label(master = self._game_window, text = game_state.winner(), font = DEFAULT_FONT)
                    label.grid(row = 3, column = 0, padx = 10, pady = 10, sticky = tkinter.W)

        except othello_logic.OthelloGameOverError:
            pass
        except othello_logic.OthelloInvalidMoveError:
            pass
        except:
            print('Unknown Error')
            self._quit()
                
    def _quit(self):
        '''Closes game window'''
        self._game_window.destroy()

    def _draw_disc(self, coord: tuple):
        '''draws a disc in the clicked square'''
        pass
        
    def _on_canvas_resized(self, event: tkinter.Event):
        '''Re-draw when canvas is resized'''
        self._canvas_draw()
      
    def _canvas_draw(self):
        '''creates visual checkerdboard on canvas'''
        self._canvas.delete(tkinter.ALL)

        board = game_state.get_board()
        
        width = self._canvas.winfo_width()
        height = self._canvas.winfo_height()
        rows = game_state.get_rows()
        cols = game_state.get_columns()
        tile_height = int(height/rows)
        tile_width = int(width/cols)
        
        for x in range(int(width / cols), width, int(width / cols)):
            self._canvas.create_line(x, 0, x, height, fill = "#476042")

        for y in range(int(height / rows), height, int(height / rows)):
            self._canvas.create_line(0, y, width, y, fill = "#476042")

        for row in range(len(board)):
            for col in range(len(board[row])):
                if board[row][col] == 'B':
                    center_x = (col + 1) * tile_width - .5* tile_width
                    center_y = (row + 1)* tile_height - .5* tile_height
                    self._canvas.create_oval(center_x - .5* tile_width, center_y - .5* tile_height,
                                             center_x + .5* tile_width, center_y + .5* tile_height,
                                             fill = 'black', outline = '#000000')
                if board[row][col] == 'W':
                    center_x = (col + 1) * tile_width - .5* tile_width
                    center_y = (row + 1)* tile_height - .5* tile_height
                    self._canvas.create_oval(center_x - .5* tile_width, center_y - .5* tile_height,
                                             center_x + .5* tile_width, center_y + .5* tile_height,
                                             fill = 'white', outline = '#000000')
                     
        self._label(0, 0, self._turn_message())      
        self._label(0, 1, self._score_message())              
                               
    def _score_message(self)-> str:
        '''Returns a message with the current score'''
        return "Score: Black {} White {}  ".format(game_state.current_score()[1], game_state.current_score()[0])

    def _turn_message(self)-> str:
        '''returns a message with the current players turn'''
        turn = game_state.player_turn()
        if turn == 'W':
            return "White it's your turn."
        else:
            return "Black it's your turn."
        
    def _label(self, r: int, col: int, message: str):
        '''Used to make Gameboard labels'''
        label = tkinter.Label(master = self._game_window, text = message, font = DEFAULT_FONT)
        label.grid(row = r, column = col, padx = 10, pady = 10, sticky = tkinter.W)
        
    def start(self) -> None:
        '''Opens the Options Menu'''
        self._game_window.mainloop()

if __name__ == "__main__":
    game_state = othello_logic.GameState()
    OptionsMenu().start()
