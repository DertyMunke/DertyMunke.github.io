# othello_logic
##Double click or run othello_gui.py if you have IDLE and you can play
#play my full version of Othello

import collections

class OthelloInitError(Exception):
    '''Raised when an error occurs during board initialization'''
    pass

class OthelloNumbersRowsColumnsError(Exception):
    '''Raised whenever a non even number, or less than 4 rows or columns is choosen'''
    pass

class OthelloNonExistentRowColumnError(Exception):
    '''Raised whenever a non-existent row or column is attempted'''
    pass

class OthelloInvalidMoveError(Exception):
    '''Raised whenever an invalid move is made'''
    pass

class OthelloGameOverError(Exception):
    '''Raised whenever an attempt is made to make a move after the game isalready over'''
    pass

class GameState:
    '''Objects represent the current state of the game with methods that manipulate that state'''
    def __init__(self):
        self._rows = 0
        self._columns = 0
        self._player = ''
        self._board = []
        self._win_type = ''
        self._white = 0
        self._black = 0
        self._game_over = False

    def winner(self)-> str:
        '''Determines the winner'''
        if self._win_type == 'M':
            if self._white > self._black:
                self._game_over = True
                return "CONGRATULATIONS WHITE!!! You are the victor."          
            elif self._white < self._black:
                self._game_over = True
                return "CONGRATULATIONS BLACK!!! You are the victor."
            else:
                self._game_over = True
                return "IT'S A TIE!!! You are both equally intelligent."
        elif self._win_type == 'F':
            if self._white < self._black:
                self._game_over = True
                return "CONGRATULATIONS WHITE!!! You are the victor."
            elif self._white > self._black:
                self._game_over = True
                return "CONGRATULATIONS BLACK!!! You are the victor."
            else:
                self._game_over = True
                return "IT'S A TIE!!! You are both equally intelligent."

    def can_move(self)-> bool:
        '''Determine if a player has a valid move available'''
        for row in range(len(self._board)):
            for col in range(len(self._board[row])):
                if _will_flip(self._board, row, col, self._player) != []:
                    return True
        return False

    def cannot_move(self):
        '''If cannot move, switches player'''
        self._player = _switch_turn(self._player)
                    

    def move(self, row: int, column: int):
        '''Make a move'''
        coords = []
        if self._game_over:
            raise OthelloGameOverError
        
        if 0 <= row <= self._rows and 0 <= column <= self._columns:
            if _disc_color(self._board, row, column) != None:
                raise OthelloInvalidMoveError
            coords = _will_flip(self._board, row, column, self._player)
            if  coords == []:
                raise OthelloInvalidMoveError
            else:
                self._board = _flip(self._board, coords, self._player)
            
            if self._board[row][column] == ' ':
                self._board[row][column] = self._player

                
            self._player = _switch_turn(self._player)
        else:
            raise OthelloInvalidMoveError

    def current_score(self)-> (int, int):
        '''Returns a tuple containing scores White, Black'''
        self._white = 0
        self._black = 0
        for row in self._board:
            for col in row:               
                if col == 'W':
                    self._white += 1
                elif col == 'B':
                    self._black += 1              
        return (self._white, self._black)

    def set_win_type(self, win: str):
        if win == 'M' or win == 'F':
            self._win_type = win
        else:
            raise OthelloInitError
        
    def init_board(self, top_left: str):
        '''Initializes a game board'''
        for row in range(self._rows):
            board = []
            for column in range(self._columns):
                board.append(' ')
            self._board.append(board)
            
        row = (self._rows // 2) - 1
        col = (self._columns // 2) - 1
        if top_left == 'W':
            self._board[row][col] = 'W'
            self._board[row][col + 1] = 'B'
            self._board[row + 1][col] = 'B'
            self._board[row + 1][col + 1] = 'W'
        elif top_left == 'B':
            self._board[row][col] = 'B'
            self._board[row][col + 1] = 'W'
            self._board[row + 1][col] = 'W'
            self._board[row + 1][col + 1] = 'B'
        else:
            raise OthelloInitError
                
    def rows_columns(self, rows: int, columns: int):
        '''Get the number of rows and/or columns on the board.'''
        if rows < 4 or columns < 4 or rows % 2 != 0 or columns % 2 != 0:
            raise OthelloNumbersRowsColumns
        self._rows = rows
        self._columns = columns

    def get_rows(self):
        return self._rows

    def get_columns(self):
        return self._columns

    def player_turn(self)-> 'player':
        '''Find out whose turn it is'''
        return self._player

    def first_player(self, player: str):
        self._player = player

    def game_over(self)-> bool:
        '''Determine whether the game is over'''
        pass

    def get_board(self)-> [[str]]:
        '''Returns the current game board'''
        return self._board

def _switch_turn(player: str)-> str:
    '''Switches the players turn'''
    if player == 'W':
        return 'B'
    else:
        return 'W'
    
def _disc_color(board: [[str]], row: int, col: int)-> str:
    '''Determine whether a disc is in some cell in the grid; if so, determine its color'''
    if board[row][col] == 'W':
        return 'W'
    elif board[row][col] == 'B':
        return 'B'
    else:
        return None
    
def _will_flip(board: [[str]], row: int, col: int, player: str)-> [(int, int)]:
    '''If a move were made here, returns what would be flipped'''
    coords = []
    if _disc_color(board, row, col) == None:
        try:
            coords.extend(_right(board, row, col, player))
        except:
            pass
        try:
            coords.extend(_left(board, row, col, player))
        except:
            pass
        try:
            coords.extend(_down(board, row, col, player))
        except:
            pass
        try:
            coords.extend(_up(board, row, col, player))
        except:
            pass
        try:
            coords.extend(_down_right(board, row, col, player))
        except:
            pass
        try:
            coords.extend(_down_left(board, row, col, player))
        except:
            pass
        try:
            coords.extend(_up_right(board, row, col, player))
        except:
            pass
        try:
            coords.extend(_up_left(board, row, col, player))
        except:
            pass

    return coords
        
def _right(board: [[str]], row: int, col: int, player: str)-> [(int, int)]:
    '''returns the coordinates of everything that would be flipped one direction'''
    coords = []
    
    col += 1
    if _disc_color(board, row, col) == _switch_turn(player):
        coords.extend(_right(board, row, col, player))
        coords.append((row, col))
    elif _disc_color(board, row, col) != player or row < 0 or col < 0:
        raise OthelloInvalidMoveError

    return coords



def _left(board: [[str]], row: int, col: int, player: str)-> [(int, int)]:
    '''returns the coordinates of everything that would be flipped one direction'''
    coords = []
    
    col -= 1
    if _disc_color(board, row, col) == _switch_turn(player):
        coords.extend(_left(board, row, col, player))
        coords.append((row, col))
    elif _disc_color(board, row, col) != player or row < 0 or col < 0:
        raise OthelloInvalidMoveError

    return coords

def _up(board: [[str]], row: int, col: int, player: str)-> [(int, int)]:
    '''returns the coordinates of everything that would be flipped one direction'''
    coords = []
    
    row += 1
    if _disc_color(board, row, col) == _switch_turn(player):
        coords.extend(_up(board, row, col, player))
        coords.append((row, col))
    elif _disc_color(board, row, col) != player or row < 0 or col < 0:
        raise OthelloInvalidMoveError

    return coords

def _down(board: [[str]], row: int, col: int, player: str)-> [(int, int)]:
    '''returns the coordinates of everything that would be flipped one direction'''
    coords = []
    
    row -= 1
    if _disc_color(board, row, col) == _switch_turn(player):
        coords.extend(_down(board, row, col, player))
        coords.append((row, col))
    elif _disc_color(board, row, col) != player or row < 0 or col < 0:
        raise OthelloInvalidMoveError

    return coords
  
def _down_right(board: [[str]], row: int, col: int, player: str)-> [(int, int)]:
    '''returns the coordinates of everything that would be flipped one direction'''
    coords = []

    row += 1
    col += 1
    if _disc_color(board, row, col) == _switch_turn(player):
        coords.extend(_down_right(board, row, col, player))
        coords.append((row, col))
    elif _disc_color(board, row, col) != player or row < 0 or col < 0:
        raise OthelloInvalidMoveError

    return coords

def _down_left(board: [[str]], row: int, col: int, player: str)-> [(int, int)]:
    '''returns the coordinates of everything that would be flipped one direction'''
    coords = []

    row += 1
    col -= 1
    if _disc_color(board, row, col) == _switch_turn(player):
        coords.extend(_down_left(board, row, col, player))
        coords.append((row, col))
    elif _disc_color(board, row, col) != player or row < 0 or col < 0:
        raise OthelloInvalidMoveError

    return coords
  
def _up_right(board: [[str]], row: int, col: int, player: str)-> [(int, int)]:
    '''returns the coordinates of everything that would be flipped one direction'''
    coords = []

    row -= 1
    col += 1
    if _disc_color(board, row, col) == _switch_turn(player):
        coords.extend(_up_right(board, row, col, player))
        coords.append((row, col))
    elif _disc_color(board, row, col) != player or row < 0 or col < 0:
        raise OthelloInvalidMoveError

    return coords

def _up_left(board: [[str]], row: int, col: int, player: str)-> [(int, int)]:
    '''returns the coordinates of everything that would be flipped one direction'''
    coords = []
    
    row -= 1
    col -= 1
    
    if _disc_color(board, row, col) == _switch_turn(player):
        coords.extend(_up_left(board, row, col, player))
        coords.append((row, col))
    elif _disc_color(board, row, col) != player or row < 0 or col < 0:
        raise OthelloInvalidMoveError

    return coords

def _flip(board: [[str]], coords: [(int, int)], player: str)-> [[str]]:
    '''Flip the discs that can be flipped and returns a new gameboard'''
    new_board = []
    
    for row in range(len(board)):
        temp = []
        for col in range(len(board[row])):
            copy = True
            for point in coords:
                if (row, col) == point:
                    temp.append(player)
                    copy = False
            if copy:
                temp.append(board[row][col])
        new_board.append(temp)

    return new_board

