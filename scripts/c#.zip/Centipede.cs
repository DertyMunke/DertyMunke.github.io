﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class Centipede : MonoBehaviour
{
	public enum Direction { DOWN, LEFT, UP, RIGHT, FORWARD, NONE};
	
	#region Private Variables
    private Tile currTileScript;
    private Direction currDir = Direction.RIGHT;
    private Direction turning = Direction.FORWARD;
    private Vector3[] headForwardPos  = { new Vector3(.3f, 0, 0), new Vector3(.3f, 0, 0), Vector3.zero, new Vector3(-.3f, 0, 0),
        new Vector3(-.3f, 0, 0), Vector3.zero };
    private List<GameObject> segments = new List<GameObject>();
    private float forwardAngle = 0;
    private float angleDelta = 0;
    private bool[,] mapVisited;
    private int[] headForwardRot = { 20, 0, -20, -20, 0, 20 };
    private int[] mapSize;
    private int currRot = 0;
    private int numSegments = 2;
	#endregion
	
	#region Public Variables
    public GameObject tailPrefab;
    public GameObject segmentTwo;
    public static float speedTrans = .1f;
    public static float speedRot = 5;
	#endregion
	
	#region Private Functions
    /// <summary>
    /// Initializations
    /// </summary>
    private void Start()
    {
        // Initialize all map squares to false so we can check if we've been there
        mapSize = MapMaker.mapScript.MapSize;
        mapVisited = new bool[mapSize[0], mapSize[1]];
        for(int row = 0; row < mapSize[0]; row++)
            for(int col = 0; col < mapSize[1]; col++)
            {
                mapVisited[row, col] = false;
            }

        // Initialize the centipede segments and start the AI
        segments.Add(gameObject);
        segments.Add(segmentTwo);
        AddNewSegment();
        StartCoroutine(CentipedeAI());
    }

    /// <summary>
    /// Adds a new segment to the centipede
    /// </summary>
    private void AddNewSegment()
    {
        GameObject newTail = Instantiate(tailPrefab, segments[segments.Count - 1].transform.position, 
            segments[segments.Count - 1].transform.parent.rotation) as GameObject;
        newTail.transform.parent = segments[segments.Count - 1].transform;

        newTail.transform.localPosition = new Vector3(newTail.transform.localPosition.x, newTail.transform.localPosition.y + 2.13f,
            newTail.transform.localPosition.z);

        segments[segments.Count - 1].GetComponent<Segment>().SetMyChildSegment = newTail;
        segments[segments.Count - 1].GetComponent<Segment>().StartSegmentParentAI();
        segments.Add(newTail);
    }

    

    /// <summary>
    /// Handles centipede actions when colliding with other objects
    /// </summary>
    private void OnTriggerEnter2D(Collider2D other)
    {
        if(other.tag == "t" || other.tag == "corner" || other.tag == "line" || other.tag == "cross")
        {
            if(currTileScript != other.gameObject.GetComponent<Tile>())
            {
                currTileScript = other.gameObject.GetComponent<Tile>();
                ChooseDirection(currTileScript);
            }
        }
    }

    /// <summary>
    /// Centipede evaluates a tile and chooses a new direction
    /// </summary>
    private void ChooseDirection(Tile _tileScript)
    {
        if (!mapVisited[_tileScript.Position[0], _tileScript.Position[1]])
        {
            mapVisited[_tileScript.Position[0], _tileScript.Position[1]] = true;
            bool[] _openings = new bool[4];  
            _tileScript.RotatedOpenings.CopyTo(_openings, 0);
            
            switch (currDir)
            {
                case Direction.DOWN:
                    _openings[2] = false;
                    break;
                case Direction.LEFT:
                    _openings[3] = false;
                    break;
                case Direction.UP:
                    _openings[0] = false;
                    break;
                case Direction.RIGHT:
                    _openings[1] = false;
                    break;
                default:
                    break;
            }

            List<int> _valid = new List<int>();
            List<int> _invalid = new List<int>();
            for (int i = 0; i < 4; i++)
            {
                if (_openings[i])
                {
                    int row = i == 0 ? _tileScript.Position[0] - 1 : i == 2 ? _tileScript.Position[0] + 1 : _tileScript.Position[0];
                    int col = i == 1 ? _tileScript.Position[1] - 1 : i == 3 ? _tileScript.Position[1] + 1 : _tileScript.Position[1];
                    if (!mapVisited[row, col])
                        _valid.Add(i);
                    else
                        _invalid.Add(i);
                }
            }

            int _newDir = 0;
            if (_valid.Count > 0)
            {
                _newDir = _valid[Random.Range(0, _valid.Count)];
            }
            else
            {
                _newDir = _invalid[Random.Range(0, _valid.Count)];
                int row = _newDir == 0 ? _tileScript.Position[0] - 1 : _newDir == 2 ? _tileScript.Position[0] + 1 : _tileScript.Position[0];
                int col = _newDir == 1 ? _tileScript.Position[1] - 1 : _newDir == 3 ? _tileScript.Position[1] + 1 : _tileScript.Position[1];
                mapVisited[row, col] = false;
            }

            switch (currDir)
            {
                case Direction.DOWN:
                    turning = _newDir == 0 ? Direction.FORWARD : _newDir == 1 ? Direction.RIGHT : Direction.LEFT;
                    break;
                case Direction.LEFT:
                    turning = _newDir == 1 ? Direction.FORWARD : _newDir == 2 ? Direction.RIGHT : Direction.LEFT;
                    break;
                case Direction.UP:
                    turning = _newDir == 2 ? Direction.FORWARD : _newDir == 3 ? Direction.RIGHT : Direction.LEFT;
                    break;
                case Direction.RIGHT:
                    turning = _newDir == 3 ? Direction.FORWARD : _newDir == 0 ? Direction.RIGHT : Direction.LEFT;
                    break;
                default:
                    break;
            }
            segmentTwo.GetComponent<Segment>().SetNextTurnDir = turning;
            segmentTwo.GetComponent<Segment>().SetTurnAtRowCol = _tileScript.Position; 
            currDir = _newDir == 0 ? Direction.DOWN : _newDir == 1 ? Direction.LEFT : _newDir == 2 ? Direction.UP : Direction.RIGHT;
        }
    }	
	#endregion
	
	#region Coroutines
    /// <summary>
    /// The centipedes brain
    /// </summary>
    public IEnumerator CentipedeAI()
    {
        bool centipedeEnabled = true;
        while (centipedeEnabled)
        {
            //Debug.Log(currDir + " currDir : turning " + turning);
            yield return new WaitForSeconds(.1f);

            //segmentTwo.GetComponent<Segment>().SetTurningDir = turning;

            switch (turning)
            {
                case Direction.RIGHT:
                    if (segmentTwo.transform.localEulerAngles.z >= 310)
                        segmentTwo.transform.localEulerAngles = new Vector3(0, 0, segmentTwo.transform.localEulerAngles.z + 9);
                    else if (Mathf.Floor(segmentTwo.transform.localEulerAngles.z) < 45)
                        segmentTwo.transform.localEulerAngles = new Vector3(0, 0, segmentTwo.transform.localEulerAngles.z + speedRot);
                    break;
                case Direction.LEFT:
                    if (segmentTwo.transform.localEulerAngles.z <= 50 && segmentTwo.transform.localEulerAngles.z > 0)
                        segmentTwo.transform.localEulerAngles = new Vector3(0, 0, segmentTwo.transform.localEulerAngles.z - 9);
                    if (Mathf.Floor(segmentTwo.transform.localEulerAngles.z) > 315 || segmentTwo.transform.localEulerAngles.z == 0)
                    {
                        segmentTwo.transform.localEulerAngles = new Vector3(0, 0, segmentTwo.transform.localEulerAngles.z - speedRot);
                    }
                    break;
                case Direction.FORWARD:
                    if (segmentTwo.transform.localEulerAngles.z <= 5 || segmentTwo.transform.localEulerAngles.z >= 355)
                        segmentTwo.transform.localEulerAngles = Vector3.zero;
                    if (Mathf.Floor(segmentTwo.transform.localEulerAngles.z) > 0 && segmentTwo.transform.localEulerAngles.z <= 50)
                        segmentTwo.transform.localEulerAngles = new Vector3(0, 0, segmentTwo.transform.localEulerAngles.z - speedRot);
                    else if (Mathf.Floor(segmentTwo.transform.localEulerAngles.z) >= 310)
                        segmentTwo.transform.localEulerAngles = new Vector3(0, 0, segmentTwo.transform.localEulerAngles.z + speedRot);
                    else
                        segmentTwo.transform.localEulerAngles = Vector3.zero;
                    break;
                default:
                    break;
            }

            

            switch (currDir)
            {
                case Direction.DOWN:
                    switch (turning)
                    {
                        case Direction.RIGHT:
                            if (transform.parent.position.x < currTileScript.Position[1] * 2.56)
                                transform.parent.position = new Vector3(transform.parent.position.x + speedTrans, transform.parent.position.y,
                                    transform.parent.position.z);

                            transform.parent.eulerAngles = new Vector3(0, 0, transform.parent.eulerAngles.z - speedRot);
                            if (Mathf.Floor(transform.parent.eulerAngles.z) == 0)
                                turning = Direction.FORWARD;
                            break;
                        case Direction.LEFT:
                            if (transform.parent.position.x > currTileScript.Position[1] * 2.56)
                                transform.parent.position = new Vector3(transform.parent.position.x - speedTrans, transform.parent.position.y,
                                    transform.parent.position.z);

                            transform.parent.eulerAngles = new Vector3(0, 0, transform.parent.eulerAngles.z + speedRot);
                            if (Mathf.Floor(transform.parent.eulerAngles.z) == 0)
                                turning = Direction.FORWARD;
                            break;
                        case Direction.FORWARD:
                            transform.parent.eulerAngles = Vector3.zero;
                            break;
                        default:
                            break;
                    }
                    transform.parent.position = new Vector3(transform.parent.position.x, transform.parent.position.y - speedTrans, transform.parent.position.z);
                    break;
                case Direction.LEFT:
                    switch (turning)
                    {
                        case Direction.RIGHT:
                            if (transform.parent.position.y > currTileScript.Position[0] * 2.56)
                                transform.parent.position = new Vector3(transform.parent.position.x, transform.parent.position.y - speedTrans,
                                    transform.parent.position.z);

                            transform.parent.eulerAngles = new Vector3(0, 0, transform.parent.eulerAngles.z - speedRot);
                            if (Mathf.Floor(transform.parent.eulerAngles.z) == 270)
                                turning = Direction.FORWARD;
                            break;
                        case Direction.LEFT:
                            if (transform.parent.position.y < currTileScript.Position[0] * 2.56)
                                transform.parent.position = new Vector3(transform.parent.position.x, transform.parent.position.y + speedTrans,
                                    transform.parent.position.z);

                            transform.parent.eulerAngles = new Vector3(0, 0, transform.parent.eulerAngles.z + speedRot);
                            if (Mathf.Floor(transform.parent.eulerAngles.z) == 270)
                                turning = Direction.FORWARD;
                            break;
                        case Direction.FORWARD:
                            transform.parent.eulerAngles = new Vector3(0, 0, 270);
                            break;
                        default:
                            break;
                    }
                    transform.parent.position = new Vector3(transform.parent.position.x - speedTrans, transform.parent.position.y, transform.parent.position.z);
                    break;
                case Direction.UP:
                    switch (turning)
                    {
                        case Direction.RIGHT:
                            if (transform.parent.position.x > currTileScript.Position[1] * 2.56)
                                transform.parent.position = new Vector3(transform.parent.position.x - speedTrans, transform.parent.position.y,
                                    transform.parent.position.z);

                            transform.parent.eulerAngles = new Vector3(0, 0, transform.parent.eulerAngles.z - speedRot);
                            if (Mathf.Floor(transform.parent.eulerAngles.z) == 180)
                                turning = Direction.FORWARD;

                            break;
                        case Direction.LEFT:
                            if (transform.parent.position.x < currTileScript.Position[1] * 2.56)
                                transform.parent.position = new Vector3(transform.parent.position.x + speedTrans, transform.parent.position.y,
                                    transform.parent.position.z);

                            transform.parent.eulerAngles = new Vector3(0, 0, transform.parent.eulerAngles.z + speedRot);
                            if (Mathf.Floor(transform.parent.eulerAngles.z) == 180)
                                turning = Direction.FORWARD;
                            break;
                        case Direction.FORWARD:
                            transform.parent.eulerAngles = new Vector3(0, 0, 180);
                            break;
                        default:
                            break;
                    }
                    transform.parent.position = new Vector3(transform.parent.position.x, transform.parent.position.y + speedTrans, transform.parent.position.z);
                    break;
                case Direction.RIGHT:                        
                    switch (turning)
                    {
                        case Direction.RIGHT:
                            if (transform.parent.position.y < currTileScript.Position[0] * 2.56)
                                transform.parent.position = new Vector3(transform.parent.position.x, transform.parent.position.y + speedTrans,
                                    transform.parent.position.z);

                            transform.parent.eulerAngles = new Vector3(0, 0, transform.parent.eulerAngles.z - speedRot);
                            if (Mathf.Floor(transform.parent.eulerAngles.z) == 90)
                                turning = Direction.FORWARD;
                            break;
                        case Direction.LEFT:
                            if (transform.parent.position.y > currTileScript.Position[0] * 2.56)
                                transform.parent.position = new Vector3(transform.parent.position.x, transform.parent.position.y - speedTrans,
                                     transform.parent.position.z);

                            transform.parent.eulerAngles = new Vector3(0, 0, transform.parent.eulerAngles.z + speedRot);
                            if (Mathf.Floor(transform.parent.eulerAngles.z) == 90)
                                turning = Direction.FORWARD;
                            break;
                        case Direction.FORWARD:
                            transform.parent.eulerAngles = new Vector3(0, 0, 90);
                            break;
                        default:
                            break;
                    }
                    transform.parent.position = new Vector3(transform.parent.position.x + speedTrans, transform.parent.position.y, transform.parent.position.z);
                    break;
                default:
                    break;
            }
        }  
        yield return null;
    }
	#endregion
}
