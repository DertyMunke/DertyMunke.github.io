﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;
using System.Collections.Generic;
using System;
using System.Runtime.Serialization.Formatters.Binary;
using System.IO;

public class MapMaker : MonoBehaviour
{
    #region Private Variables
    private FileStream file = null;
    private SpriteRenderer[,] map;
    private Dictionary<string, SpriteRenderer[,]> loadedMaps = new Dictionary<string, SpriteRenderer[,]>();  // The current map will be saved as default
    private Dictionary<string, string[,]> savedMaps = new Dictionary<string, string[,]>(); // Value => index||rotation
    private Button loadMapSelected;
    private const float tileSize = 2.56f;
    private List<string> newSavedMaps = new List<string>(); // Keeps track of saved maps while in play mode
    private string[,] thisMapSaveData;
    private string currMapName;
    private bool[,] checkedTiles;
    private int mapHeight = 6;
    private int mapWidth = 8;
    #endregion

    #region Public Variables
    public static MapMaker mapScript;
	public GameObject frog;
    public GameObject mapSelectPnl;
    public Button[] saveLoadBtns;
    public Button loadMapBtn;
    public Button removeMapBtn;
    public Transform[] spawnPts;
    public SpriteRenderer[] availableTiles;
    #endregion

    #region Properties
    public Dictionary<string, string[,]> GetSavedMaps { get { return savedMaps; } }
    public int[] MapSize { get { return new int[] { mapHeight, mapWidth }; } } 
    #endregion

    #region Private Functions
    /// <summary>
    /// Initializations
    /// </summary>
    private void Awake()
    {
        //Debug.Log(Application.persistentDataPath);
        map = new SpriteRenderer[mapHeight, mapWidth];
        checkedTiles = new bool[mapHeight, mapWidth];
        thisMapSaveData = new string[mapHeight, mapWidth];
        mapScript = this;
    }

    /// <summary>
    /// Initializations
    /// </summary>
    private void Start()
    {
        LoadMaps(true);
    }

    /// <summary>
    /// Searches for closed regions on the map. Returns true if none found.
    /// </summary>
    private void SetCheckedTiles(int row, int col)
    {
        checkedTiles[row, col] = true;
        Tile tileScript = map[row, col].GetComponent<Tile>() ;
        
        if (tileScript.rotOpenings[0] && !checkedTiles[row - 1, col])  // Check south tile
            SetCheckedTiles(row - 1, col);
        if (tileScript.rotOpenings[1] && !checkedTiles[row, col - 1])  // Check west tile
            SetCheckedTiles(row, col - 1);
        if (tileScript.rotOpenings[2] && !checkedTiles[row + 1, col])  // Check north tile
            SetCheckedTiles(row + 1, col);
        if (tileScript.rotOpenings[3] && !checkedTiles[row, col + 1])  // Check east tile
            SetCheckedTiles(row, col + 1);

        
    }

    /// <summary>
    /// Returns true if there are no closed paths in the map
    /// </summary>
    /// <returns></returns>
    private bool NoClosedPaths()
    {
        for (int row = 0; row < mapHeight; row++)
        {
            for (int col = 0; col < mapWidth; col++)
            {
                if (!checkedTiles[row, col])
                    return false;
            }
        }

        return true;
    }
    #endregion

    #region Public Functions
    /// <summary>
    /// Starts the map creator coroutine
    /// </summary>
    public void MakeMap()
    {
        StartCoroutine(MapCreator());
    }

    /// <summary>
    /// Sets all of the tiles in a map to inactive
    /// </summary>
    public void SetMap(SpriteRenderer[,] newMap)
    {
        for (int row = 0; row < mapHeight; row++)
        {
            for (int col = 0; col < mapWidth; col++)
            {
                map[row, col].enabled = false;
            }
        }
    }

    /// <summary>
    /// When  you click a saved map it saves your selection
    /// </summary>
    public void SelectMapBtn(Button thisBtn)
    {
        if (loadMapSelected)
            loadMapSelected.interactable = true;
        else
        {
            loadMapBtn.interactable = true;
            removeMapBtn.interactable = true;
        }
           
        loadMapSelected = thisBtn;
        loadMapSelected.interactable = false;
    }

    /// <summary>
    /// Remove the selected map from the saved list
    /// </summary>
    public void RemoveMapBtn()
    {
        Text select = loadMapSelected.GetComponentInChildren<Text>();
        savedMaps.Remove(select.text);
        newSavedMaps.Remove(select.text);
        select.text = "";
        loadMapSelected.interactable = false;
        loadMapSelected = null;
        loadMapBtn.interactable = false;
        removeMapBtn.interactable = false;
        SaveMap(null);
    }

    /// <summary>
    /// Saves the current map 
    /// </summary>
    public void SaveMap(Text mapName)
    {
        if(mapName)
            savedMaps.Add(mapName.text, thisMapSaveData);
        try
        {
            BinaryFormatter bf = new BinaryFormatter();
            file = File.Create(Application.persistentDataPath + "/myMaps.maps");
            SavedMaps maps = new SavedMaps();

            // Data to save
            maps.savedMaps = savedMaps;
            if(mapName)
            {
                newSavedMaps.Add(mapName.text);
                loadedMaps.Add(mapName.text, map);
            }
               
            bf.Serialize(file, maps);
            file.Close();
        }
        finally
        {
            if (file != null)
                file.Close();
        }
    }

    /// <summary>
    /// Loads the list of saved maps
    /// </summary>
    public void LoadMaps(bool init = false)
    {
        if (savedMaps.Count == 0 && File.Exists(Application.persistentDataPath + "/myMaps.maps"))
        {
            try
            {
                BinaryFormatter bf = new BinaryFormatter();
                file = File.Open(Application.persistentDataPath + "/myMaps.maps", FileMode.Open);
                SavedMaps maps = (SavedMaps)bf.Deserialize(file);
                file.Close();

                // Data to load
                savedMaps = maps.savedMaps;
                if (savedMaps.Count > 0)
                    foreach (string mapname in savedMaps.Keys)
                        newSavedMaps.Add(mapname);
                    //GameManager.gameManagerScript.CreateMapBtns(savedMaps);
            }
            finally
            {
                if (file != null)
                    file.Close();
            }
        }

        // Make new buttons for the saved maps without exiting play mode
        if (newSavedMaps.Count > 0 && !init)
        {
            foreach (string map in newSavedMaps)
            {
                GameManager.gameManagerScript.AddNewBtn(map);
            }
            newSavedMaps.Clear();
        }
    }

    /// <summary>
    /// Starts the coroutine that animates the newly selected map
    /// </summary>
    public void LoadMapBtn()
    {
        StartCoroutine(LoadMapCoroutine(loadMapSelected.GetComponentInChildren<Text>().text));
    }

	/// <summary>
	/// Returns the current tile at position[row, col]
	/// </summary>
	/// <param name="row">Row.</param>
	/// <param name="col">Col.</param>
	public SpriteRenderer GetTile(int row, int col)
	{
		return loadedMaps[currMapName][row, col];
	}
    #endregion

    #region Coroutines
    /// <summary>
    /// Animates the selected saved map changing tiles
    /// </summary>
    private IEnumerator LoadMapCoroutine(string loadMap)
    {
        Tile tileScript;
        SpriteRenderer[,] newMap = new SpriteRenderer[mapHeight, mapWidth];
        Vector3 pos;
        string[] indexRotation;

        mapSelectPnl.SetActive(false);

        // Turn off save and load buttons until the map loads
        foreach (Button b in saveLoadBtns)
        {
            b.interactable = false;
        }

        for (int row = 0; row < mapHeight; row++)
        {
            for (int col = 0; col < mapWidth; col++)
            {
                yield return new WaitForSeconds(.1f);
                map[row, col].enabled = false;

                // See if the map has already been loaded so its not re-loaded
                if (loadedMaps.ContainsKey(loadMap))
                {
                    newMap = loadedMaps[loadMap];
                }
                else
                {
                    // If the map has not been loaded                   
                    indexRotation = savedMaps[loadMap][row, col].Split(new[] { "||" }, StringSplitOptions.None);
                    pos = new Vector3(spawnPts[col].position.x, spawnPts[col].position.y + tileSize * row, 0);
                    newMap[row, col] = (SpriteRenderer)Instantiate(availableTiles[int.Parse(indexRotation[0])],
                                        pos, Quaternion.Euler(0, 0, int.Parse(indexRotation[1])));
                    tileScript = newMap[row, col].GetComponent<Tile>();
                    tileScript.SetPosition(row, col);
                    tileScript.SetRotation(int.Parse(indexRotation[1]), false);
                }
                newMap[row, col].enabled = true;
            }
        }

        currMapName = loadMap;
        map = newMap;
        foreach (Button b in saveLoadBtns)
        {
            b.interactable = true;
        }
        yield return null;
    }

    /// <summary>
    /// Creates a new randomly generated map
    /// </summary>
    /// <returns></returns>
    private IEnumerator MapCreator()
    {
        Vector3 pos;
        SpriteRenderer randomTile;
        List<int> availableIndex = new List<int> { 0, 1, 2, 3 };
        Tile tileScript;
        int selectedIndex = 0;

        do
        {
            for (int row = 0; row < mapHeight; row++)
            {
                for (int col = 0; col < mapWidth; col++)
                {
                    checkedTiles[row, col] = false;  // Used to verify no closed paths 

                    if (map[row, col])
                    {
                        map[row, col].enabled = false;
                        map[row, col] = null;
                    }

                    availableIndex = new List<int> { 0, 1, 2, 3 };  // Keeps track of which tiles have been checked
                    if (row == 0 || col == 0 || row == mapHeight - 1 || col == mapWidth - 1)
                    {
                        availableIndex.Remove(3);
                        if (row == mapHeight - 1)
                        {
                            availableIndex.Remove(0);
                        }
                    }

                    while (availableIndex.Count > 0)
                    {
                        selectedIndex = availableIndex[UnityEngine.Random.Range(0, availableIndex.Count)];
                        availableIndex.Remove(selectedIndex);
                        randomTile = availableTiles[selectedIndex];

                        tileScript = randomTile.GetComponent<Tile>();
                        tileScript.SetPosition(row, col);

                        if (row == 0 && col == 0)  // Corner check -> bottom left
                        {
                            map[row, col] = (SpriteRenderer)Instantiate(availableTiles[0], spawnPts[col].position, Quaternion.Euler(0, 0, 90));
                            tileScript = map[row, col].GetComponent<Tile>();
                            tileScript.SetPosition(row, col);
                            tileScript.SetRotation(0);
                            thisMapSaveData[row, col] = "0||90";

                            availableIndex = new List<int> { 0, 1, 2, 3 };
                            break;
                        }
                        else if (row == 0 && col == mapWidth - 1)  // Corner check -> bottom right
                        {
                            map[row, col] = (SpriteRenderer)Instantiate(availableTiles[0], spawnPts[col].position, Quaternion.Euler(0, 0, 180));
                            tileScript = map[row, col].GetComponent<Tile>();
                            tileScript.SetPosition(row, col);
                            tileScript.SetRotation(3);
                            thisMapSaveData[row, col] = "0||180";

                            availableIndex = new List<int> { 0, 1, 2, 3 };
                            break;
                        }
                        else if (row == mapHeight - 1 && col == 0)  // Corner check -> top left
                        {
                            pos = new Vector3(spawnPts[col].position.x, (spawnPts[col].position.y + tileSize * row), 0);
                            map[row, col] = (SpriteRenderer)Instantiate(availableTiles[0], pos, Quaternion.Euler(0, 0, 0));
                            tileScript = map[row, col].GetComponent<Tile>();
                            tileScript.SetPosition(row, col);
                            tileScript.SetRotation(1);
                            thisMapSaveData[row, col] = "0||0";

                            availableIndex = new List<int> { 0, 1, 2, 3 };
                            break;
                        }
                        else if (row == mapHeight - 1 && col == mapWidth - 1)  // Corner check -> top right
                        {
                            pos = new Vector3(spawnPts[col].position.x, spawnPts[col].position.y + tileSize * row, 0);
                            map[row, col] = (SpriteRenderer)Instantiate(availableTiles[0], pos, Quaternion.Euler(0, 0, -90));
                            tileScript = map[row, col].GetComponent<Tile>();
                            tileScript.SetPosition(row, col);
                            tileScript.SetRotation(2);
                            thisMapSaveData[row, col] = "0||-90";

                            availableIndex = new List<int> { 0, 1, 2, 3 };
                            break;
                        }
                        else if (row == 0)  // Wall check -> bottom
                        {
                            tileScript.SetRotation(0);

                            if (map[row, col - 1].GetComponent<Tile>().rotOpenings[3] == tileScript.rotOpenings[1])
                            {
                                pos = new Vector3(spawnPts[col].position.x, spawnPts[col].position.y + tileSize * row, 0);
                                map[row, col] = (SpriteRenderer)Instantiate(randomTile, pos, Quaternion.identity);
                                map[row, col].transform.rotation = Quaternion.Euler(0, 0, tileScript.GetRotation());
                                thisMapSaveData[row, col] = selectedIndex.ToString() + "||" + tileScript.GetRotation().ToString();

                                availableIndex = new List<int> { 0, 1, 2, 3 };
                                break;
                            }
                            else if (col != mapWidth - 2 && tileScript.tag == "corner")
                            {
                                tileScript.SetRotation(tileScript.GetRotation() + 90, false);

                                if (map[row, col - 1].GetComponent<Tile>().rotOpenings[3] == tileScript.rotOpenings[1])
                                {
                                    pos = new Vector3(spawnPts[col].position.x, spawnPts[col].position.y + tileSize * row, 0);
                                    map[row, col] = (SpriteRenderer)Instantiate(randomTile, pos, Quaternion.identity);
                                    map[row, col].transform.rotation = Quaternion.Euler(0, 0, tileScript.GetRotation());
                                    thisMapSaveData[row, col] = selectedIndex.ToString() + "||" + tileScript.GetRotation().ToString();

                                    availableIndex = new List<int> { 0, 1, 2, 3 };
                                    break;
                                }
                            }
                        }
                        else if (row == mapHeight - 1)  // Wall check -> top
                        {
                            tileScript.SetRotation(2);
                            if (map[row, col - 1].GetComponent<Tile>().rotOpenings[3] == tileScript.rotOpenings[1])
                            {
                                if (map[row - 1, col].GetComponent<Tile>().rotOpenings[2] == tileScript.rotOpenings[0])
                                {
                                    pos = new Vector3(spawnPts[col].position.x, spawnPts[col].position.y + tileSize * row, 0);
                                    map[row, col] = (SpriteRenderer)Instantiate(randomTile, pos, Quaternion.identity);
                                    map[row, col].transform.rotation = Quaternion.Euler(0, 0, tileScript.GetRotation());
                                    thisMapSaveData[row, col] = selectedIndex.ToString() + "||" + tileScript.GetRotation().ToString();

                                    availableIndex = new List<int> { 0, 1, 2, 3 };
                                    break;
                                }
                            }
                        }
                        else if (col == 0)  // Wall check -> left
                        {
                            tileScript.SetRotation(1);

                            if ((row != mapHeight - 2 || (row == mapHeight - 2 && tileScript.rotOpenings[2])) &&
                                map[row - 1, col].GetComponent<Tile>().rotOpenings[2] == tileScript.rotOpenings[0])
                            {
                                pos = new Vector3(spawnPts[col].position.x, spawnPts[col].position.y + tileSize * row, 0);
                                map[row, col] = (SpriteRenderer)Instantiate(randomTile, pos, Quaternion.identity);
                                map[row, col].transform.rotation = Quaternion.Euler(0, 0, tileScript.GetRotation());
                                thisMapSaveData[row, col] = selectedIndex.ToString() + "||" + tileScript.GetRotation().ToString();

                                availableIndex = new List<int> { 0, 1, 2, 3 };
                                break;
                            }
                            else if (tileScript.tag == "corner")
                            {
                                tileScript.SetRotation(tileScript.GetRotation() + 90, false);

                                if (map[row - 1, col].GetComponent<Tile>().rotOpenings[2] == tileScript.rotOpenings[0])
                                {
                                    pos = new Vector3(spawnPts[col].position.x, spawnPts[col].position.y + tileSize * row, 0);
                                    map[row, col] = (SpriteRenderer)Instantiate(randomTile, pos, Quaternion.identity);
                                    map[row, col].transform.rotation = Quaternion.Euler(0, 0, tileScript.GetRotation());
                                    thisMapSaveData[row, col] = selectedIndex.ToString() + "||" + tileScript.GetRotation().ToString();

                                    availableIndex = new List<int> { 0, 1, 2, 3 };
                                    break;
                                }
                            }

                        }
                        else if (col == mapWidth - 1)  // Wall check -> right
                        {
                            tileScript.SetRotation(3);
                            if (row != mapHeight - 2 || (row == mapHeight - 2 && tileScript.rotOpenings[2]))
                            {
                                //Debug.Log((row == mapSize - 2) + "  " + tileScript.rotOpenings[2]);
                                if (map[row - 1, col].GetComponent<Tile>().rotOpenings[2] == tileScript.rotOpenings[0])
                                {
                                    if (map[row, col - 1].GetComponent<Tile>().rotOpenings[3] == tileScript.rotOpenings[1])
                                    {
                                        pos = new Vector3(spawnPts[col].position.x, spawnPts[col].position.y + tileSize * row, 0);
                                        map[row, col] = (SpriteRenderer)Instantiate(randomTile, pos, Quaternion.identity);
                                        map[row, col].transform.rotation = Quaternion.Euler(0, 0, tileScript.GetRotation());
                                        thisMapSaveData[row, col] = selectedIndex.ToString() + "||" + tileScript.GetRotation().ToString();

                                        availableIndex = new List<int> { 0, 1, 2, 3 };
                                        break;
                                    }
                                }
                                else if (tileScript.tag == "corner")
                                {
                                    tileScript.SetRotation(tileScript.GetRotation() + 90, false);

                                    if (row != mapHeight - 2 || (row == mapHeight - 2 && tileScript.rotOpenings[2]))
                                    {
                                        if (map[row - 1, col].GetComponent<Tile>().rotOpenings[2] == tileScript.rotOpenings[0])
                                        {
                                            if (map[row, col - 1].GetComponent<Tile>().rotOpenings[3] == tileScript.rotOpenings[1])
                                            {
                                                pos = new Vector3(spawnPts[col].position.x, spawnPts[col].position.y + tileSize * row, 0);
                                                map[row, col] = (SpriteRenderer)Instantiate(randomTile, pos, Quaternion.identity);
                                                map[row, col].transform.rotation = Quaternion.Euler(0, 0, tileScript.GetRotation());
                                                thisMapSaveData[row, col] = selectedIndex.ToString() + "||" + tileScript.GetRotation().ToString();
                                                availableIndex = new List<int> { 0, 1, 2, 3 };
                                                break;
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        else  // Middle tile check
                        {
                            for (int rotate = 0; rotate < 4; rotate++)
                            {
                                tileScript.SetRotation(rotate * 90, false);
                                if (map[row - 1, col].GetComponent<Tile>().rotOpenings[2] == tileScript.rotOpenings[0])
                                {
                                    if (map[row, col - 1].GetComponent<Tile>().rotOpenings[3] == tileScript.rotOpenings[1])
                                    {
                                        if (col != mapWidth - 2 || tileScript.rotOpenings[3])
                                        {
                                            pos = new Vector3(spawnPts[col].position.x, spawnPts[col].position.y + tileSize * row, 0);
                                            map[row, col] = (SpriteRenderer)Instantiate(randomTile, pos, Quaternion.identity);
                                            map[row, col].transform.rotation = Quaternion.Euler(0, 0, tileScript.GetRotation());
                                            thisMapSaveData[row, col] = selectedIndex.ToString() + "||" + tileScript.GetRotation().ToString();

                                            availableIndex = new List<int> { 0, 1, 2, 3 };
                                            break;
                                        }
                                    }
                                }
                            }
                            if (map[row, col])
                                break;
                        }
                    }  
                }
            }
            // Check for closed paths
            SetCheckedTiles(0, 0);
        }
        while (!NoClosedPaths());

        // Make the map with no closed paths visible
        for (int row = 0; row < mapHeight; row++)
            for (int col = 0; col < mapWidth; col++)
            {
                map[row, col].enabled = true;
                yield return new WaitForSeconds(.1f);
            }

        // Put the current map in the dictionary of loaded maps
        currMapName = "default";
        if (loadedMaps.ContainsKey(currMapName))
            loadedMaps[currMapName] = map;
        else
            loadedMaps.Add(currMapName, map);
        foreach (Button b in saveLoadBtns)
        {
            b.interactable = true;
        }
		frog.SetActive(true);
        PickupsManager.pickupsManagerScript.InitSpawnFlys(map, mapHeight, mapWidth);
        yield return null;
    }
    #endregion
}


/// <summary>
/// This makes the objects to be stored
/// </summary>
[Serializable]
class SavedMaps
{
    public Dictionary<string, string[,]> savedMaps = new Dictionary<string, string[,]>();
}
