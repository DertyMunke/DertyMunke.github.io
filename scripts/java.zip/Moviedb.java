package parser;
import java.sql.*;
import java.util.ArrayList;

public class Moviedb {

	Connection conn;
	PreparedStatement addmovieProc;
	PreparedStatement addmovie;
	PreparedStatement checkmovie;
	PreparedStatement addstar;
	PreparedStatement checkstar;
	PreparedStatement starInMovie;
	PreparedStatement addgenre;
	PreparedStatement checkgenre;
	PreparedStatement genreInMovie;
	ResultSet rs;
	
	/**
	 *  Initializes the connection and the prepared statements for the movie database
	 */
	public Moviedb(String _url, String _user, String _pswrd)
	{
		try {
			Class.forName("com.mysql.jdbc.Driver").newInstance();
			
			//build a connection to database according to parameters
	    	conn = DriverManager.getConnection(_url, _user, _pswrd);
	    	addmovieProc = conn.prepareStatement("CALL add_movie(?, ?, ?, null, null, ?, ?, ?)");
	    	checkmovie = conn.prepareStatement("SELECT id FROM movies WHERE title = ?");
	    	addmovie = conn.prepareStatement(
	    			"INSERT INTO movies (title, year, director) VALUES (?, ?, ?)", Statement.RETURN_GENERATED_KEYS);
	    	checkstar = conn.prepareStatement("SELECT id FROM stars WHERE first_name = ? AND last_name = ?");
	    	addstar = conn.prepareStatement(
	    			"insert into stars (first_name, last_name) values (?, ?)", Statement.RETURN_GENERATED_KEYS);
	    	starInMovie = conn.prepareStatement("insert into stars_in_movies (star_id, movie_id) values (?, ?)");
	    	checkgenre = conn.prepareStatement("SELECT id FROM genres WHERE name = ?");
	    	addgenre = conn.prepareStatement("insert into genres (name) values (?)", Statement.RETURN_GENERATED_KEYS);
	    	genreInMovie = conn.prepareStatement("insert into genres_in_movies (genre_id, movie_id) values (?, ?)");
	    	
			if(!conn.isClosed())
                System.out.println("Connected to the Movie Database!\n");
			
		} catch (SQLException e) {
			System.out.println("MySQL Loggin Error\n");
			
		} catch (Exception e) {
			System.out.println("Unknown Connection Error\n");
		}
	}
	
	/**
	 *  Close the connection to the database
	 */
	public void CloseConnect()
	{
		try {
			if(conn != null)
				conn.close();
		} catch (SQLException e) {
			System.out.println("Error: Connection close error.");
		}
	}
	
	/**
	 *  Adds a new movie to the database
	 */
	public int addMovie(String title, int year, String director)
	{
		try {		
			
			checkmovie.setString(1, title);
			ResultSet rs1 = checkmovie.executeQuery();
			
			if(rs1.next())
			{
				return rs1.getInt(1);
			}
			else
			{
				addmovie.setString(1, title);
				addmovie.setInt(2, year);
				addmovie.setString(3, director);
				
				addmovie.executeUpdate();
				ResultSet rs2 = addmovie.getGeneratedKeys();
	            if(rs2.next()) 
	                return rs2.getInt(1);
			}
	
				
		}catch (SQLException e) {
			System.out.println("MySQL Error: Movie was not added to database.");
		}
		
		return 0;
	}
	
	/**
	 *  Adds a new star to the database
	 */
	public int addStar(String first, String last)
	{
		try {
			checkstar.setString(1, first);
			checkstar.setString(2, last);
			ResultSet rs1 = checkstar.executeQuery();
			
			if(rs1.next())
			{
				return rs1.getInt(1);
			}
			else
			{
				addstar.setString(1, first);
				addstar.setString(2, last);

				addstar.execute();
				ResultSet rs2 = addstar.getGeneratedKeys();
	            if(rs2.next()) 
	                return rs2.getInt(1);
			}
		
		}catch (SQLException e) {
			System.out.println("MySQL Error: Star was not added to database.");
		}
		
		return 0;
	}
	
	/**
	 *  Links the star with the movie in the database
	 */
	public int AddStarInMovie(int starid, int movieid)
	{
		try {
			starInMovie.setInt(1, starid);
			starInMovie.setInt(2, movieid);
			
			starInMovie.execute();
		
		}catch (SQLException e) {
			System.out.println("MySQL Error: Star in movie was not added to database.");
		}
		
		return 0;
	}
	
	/**
	 *  Adds a new genre to the database
	 */
	public int AddGenre(String name)
	{
		try {
			checkgenre.setString(1, name);
			ResultSet rs1 = checkgenre.executeQuery();
			
			if(rs1.next())
			{
				return rs1.getInt(1);
			}
			else
			{
				addgenre.setString(1, name);

				addgenre.execute();
				ResultSet rs2 = addgenre.getGeneratedKeys();
	            if(rs2.next()) 
	                return rs2.getInt(1);
			}
		
		}catch (SQLException e) {
			System.out.println("MySQL Error: Genre was not added to database.");
		}
		
		return 0;
	}
	
	/**
	 *  Adds links the genre to the movie 
	 */
	public void AddGenreInMovie(int genreid, int movieid)
	{
		try {
			genreInMovie.setInt(1, genreid);
			genreInMovie.setInt(2, movieid);
			
			genreInMovie.execute();
		
		}catch (SQLException e) {
			System.out.println("MySQL Error: Genre in movie was not added to database.");
		}
	}
	
	/**
	 *  To add a movie using the stored proceedure
	 */
	public void  addMovieProc(String title, int year, String director, String first, String last, String genre)
	{
		try 
		{ 			
			addmovieProc.setString(1, title);
			addmovieProc.setInt(2, year);
			addmovieProc.setString(3, director);
			addmovieProc.setString(4, first);
			addmovieProc.setString(5, last);
			addmovieProc.setString(6, genre);
			
			addmovieProc.executeUpdate();
		
		}catch (SQLException e) {
			System.out.println("MySQL Error: Movie was not added to database.");
		}
		
	}
}
