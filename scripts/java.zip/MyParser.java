package parser;

import java.io.IOException;
import java.util.*;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

public class MyParser{
	
	Hashtable<String, Film> films; // Movie title is the key
	Hashtable<String, Star> stars; // Stage name is the key
	
	Document mainsDom;
	Document castsDom;
	Document actorsDom;

	/**
	 *  Constructor initializes the tables
	 */
	public MyParser() {
		films = new Hashtable<String, Film>();
		stars = new Hashtable<String, Star>();
	}

	/**
	 *  Controls the order in which the files are parsed
	 */
	public void runMyParser() {

		// Parse the xml file and get the dom object
		parseXmlFile();

		// Get each film and create a film object for each 
		parseFilms();
		
		// Get each star and create a star object for each
		parseStars();

		// Get the stars in movies and update films hash
		parseCasts();
		
		// Iterate through the list and print the data
		printData();

	}

	/**
	 *  Initializes the files to be parsed
	 */
	private void parseXmlFile() {
		// get the factory
		DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();

		try {

			// Using factory get an instance of document builder
			DocumentBuilder db = dbf.newDocumentBuilder();

			// parse using builder to get DOM representation of the XML file
			mainsDom = db.parse("mains243.xml");
			castsDom = db.parse("casts124.xml");
			actorsDom = db.parse("actors63.xml");

		} catch (ParserConfigurationException pce) {
			pce.printStackTrace();
		} catch (SAXException se) {
			se.printStackTrace();
		} catch (IOException ioe) {
			ioe.printStackTrace();
		}
	}

	/**
	 *  Parses the movie casts file
	 */
	private void parseCasts()
	{
		// get the root elememt, nodelist and parse 
		Element docCasts = castsDom.getDocumentElement();
		NodeList castsNodes = docCasts.getElementsByTagName("filmc");
		
		String filmName = "first element";
		if (castsNodes != null && castsNodes.getLength() > 0) 
		{
			for (int i = 0; i < castsNodes.getLength(); i++) 
			{
				try
				{
					Element el = (Element)castsNodes.item(i);
					NodeList casts = el.getElementsByTagName("m");
					
					if (casts != null && casts.getLength() > 0) 
					{
						for (int j = 0; j < casts.getLength(); j++) 
						{
							try
							{			
								Element el2 = (Element)casts.item(j);
								String filmid = getTextValue(el2, "f");
								filmName = getTextValue(el2, "t");
								String actorName = getTextValue(el2, "a");
								
								if(films.containsKey(filmName))
								{
									if(films.get(filmName).getFilmid().equals(filmid))
										films.get(filmName).addStar(actorName);
								}
								//System.out.println(filmName + " " + actorName);
								
							}catch(Exception e){
								//System.out.println(e);
							}								
						}
					}					
				}catch(Exception e){
					//System.out.println(e);
				}
			}
			castsDom = null;
		}	
	}
	
	/**
	 *  Parses the movie stars file
	 */
	private void parseStars()
	{
		// get the root elememt, nodelist and parse 
		Element docEle = actorsDom.getDocumentElement();	
		NodeList actorNodes = docEle.getElementsByTagName("actor");
		
		String actorName = "first element";
		if (actorNodes != null && actorNodes.getLength() > 0) 
		{
			for (int i = 0; i < actorNodes.getLength(); i++) 
			{
				try
				{
					String firstName = "";
					String lastName = "";
					int dob = 0;
					
					Element el = (Element)actorNodes.item(i);
					actorName = getTextValue(el, "stagename");
					firstName = getTextValue(el, "firstname");
					lastName = getTextValue(el, "familyname");
					dob = getIntValue(el, "dob");
					
					if(firstName == "" && lastName == "")
					{
						List<String> myName = new ArrayList<String>(Arrays.asList(actorName.split(" ")));
						if(myName.size() > 1)
						{
							firstName = myName.get(0);
							lastName = myName.get(myName.size() - 1);
						}
						else
						{
							lastName = actorName;
						}
						
						//System.out.println(firstName + " " + lastName);
					}
					else if(lastName == "")
					{
						lastName = firstName;
						firstName = "";
					}
					
					Star newStar = new Star(actorName, firstName, lastName, dob);
					stars.put(actorName, newStar);
					
				}catch(Exception e){
					//System.out.println(e);
					System.out.println("Error: Actors reader error, during actor " + actorName + "'s movies");
				}
			}
			actorsDom = null;
		}
	}
	
	/**
	 *  Parses the films file
	 */
	private void parseFilms()
	{
		Element docEle = mainsDom.getDocumentElement();
		NodeList dirNames = docEle.getElementsByTagName("directorfilms");
		
		String dirname = "first";
		if (dirNames != null && dirNames.getLength() > 0) 
		{
			for (int i = 0; i < dirNames.getLength(); i++) 
			{
				try
				{
					Element el = (Element) dirNames.item(i);
					dirname = getTextValue(el, "dirname");
					if(dirname == null)
						dirname = getTextValue(el, "dirn");
					
					try
					{	
						NodeList myMovies = el.getElementsByTagName("film");
						if (dirname != null && myMovies.getLength() > 0)
						{
							for (int j = 0; j < myMovies.getLength(); j++) 
							{
								el = (Element) myMovies.item(j);
								String id = getTextValue(el, "fid");
								String mv = getTextValue(el, "t");
								int yr = getIntValue(el, "year");
								
								if(mv != null)
								{			
									Film newFilm = new Film(id, mv, yr, dirname);
									
									NodeList myGenres = el.getElementsByTagName("cats");
									for (int k = 0; k < myGenres.getLength(); k++) 
									{
										el = (Element) myMovies.item(j);	
										String genre = getTextValue(el, "cat");
										if(genre != null)
											newFilm.addGenre(genre);
									}
									
									if(!films.containsKey(mv))
										films.put(mv, newFilm);
									else
									{
										if(films.get(mv).getYear() < yr)
											films.put(mv, newFilm);
									}
								}
							}
						}
						
					}catch(Exception e){
						//System.out.println("Error: Movie reader error, during director " + dirname + "'s movies");
					}
				} catch(Exception e) {
					//System.out.println("Error: Director reader error, after " + dirname + " director");
				}
			}
			mainsDom = null;
		}
	}	

	/**
	 * I take a xml element and the tag name, look for the tag and get the text content 
	 */
	private String getTextValue(Element ele, String tagName) {
		String textVal = "";
		NodeList nl = ele.getElementsByTagName(tagName);
		
		try
		{
			if (nl != null && nl.getLength() > 0) {
				Element el = (Element) nl.item(0);
				textVal = el.getFirstChild().getNodeValue();
			}
		}catch (Exception e){
			textVal = "";
		}

		return textVal;
	}

	/**
	 * Calls getTextValue and returns a int value
	 */
	private int getIntValue(Element ele, String tagName) {
		// in production application you would catch the exception
		try
		{
			return  Integer.parseInt(getTextValue(ele, tagName));
		} catch(NumberFormatException e) {
			return  0;
		}
	}

	/**
	 * Iterate through the list and print the content to console
	 */
	private void printData() {

		System.out.println("No of Movies '" + films.size() + "'.");
		System.out.println("No of Stars '" + stars.size() + "'.");
		//System.out.println("No of stars in Pygmalion '" + films.get("French Without Tears").getActors() + "'.");	
	}

	/**
	 * Runs the program
	 */
	public static void main(String[] args)
	{	
    	String url = "jdbc:mysql://localhost:3306/moviedb";
    	String username = "testuser";
    	String password = "testpass";
    	String keyElem = "";
    	
    	// Connect to mysql
    	Moviedb mydb = new Moviedb(url, username, password);
    	
		// create an instance
		MyParser parse = new MyParser();
		parse.runMyParser();
		
		// Gets all of the film titles that were parsed
		Enumeration<String> keys = parse.films.keys();
		
		Film film = new Film();
		Star thisStar = new Star();
		int filmid = 0;
		int actorid = 0;
		int genreid = 0;

		// For each film
		while(keys.hasMoreElements())
		{
			keyElem = keys.nextElement();
			film = parse.films.get(keyElem);
			filmid = mydb.addMovie(film.getTitle(), film.getYear(), film.getDirector());
			
			// Get all of the actors in the film and link them
			if((film.getActors()).size() != 0)
			{
				actorid = 0;
				for(int i = 0; i < film.getActors().size(); i++)
				{
					if(parse.stars.containsKey(film.getActors().get(i)))
					{
						thisStar = parse.stars.get(film.getActors().get(i));
						actorid = mydb.addStar(thisStar.getFirstName(), thisStar.getLastName());
						if(actorid != 0)
							mydb.AddStarInMovie(actorid, filmid);
					}				
				}
			}
			
			// Get all of the genres in the film and link them
			if((film.getGenres()).size() != 0)
			{
				genreid = 0;
				for(int i = 0; i < film.getGenres().size(); i++)
				{
					genreid = mydb.AddGenre(film.getGenres().get(i));
					mydb.AddGenreInMovie(genreid, filmid);			
				}
			}
		
			parse.films.remove(keyElem);
		}
		
		// Close db connection
		mydb.CloseConnect();
	}
}
